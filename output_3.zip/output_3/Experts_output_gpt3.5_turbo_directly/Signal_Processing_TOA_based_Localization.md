2024-05-02 10:40:05.263386

## System Model
- **Problem Type:** Source localization in sensor array signal processing.
- **Problem Description:** Localizing a signal source using the time of arrival (TOA) measurements from multiple sensors.
- **System Model Parameters:**
  - $M$: Number of sensors.
  - $(x_i, y_i)$: Position coordinates of sensor $i$.
  - $t_i$: Time of arrival measured by sensor $i$.
- **System Model Formulations:**
  - Let $s$ be the coordinates of the signal source.
  - The distance from sensor $i$ to the source is $d_i = \sqrt{(x_i - s_x)^2 + (y_i - s_y)^2}$.
  - The signal arrival time at sensor $i$ is $t_i = t_s + \frac{d_i}{c}$, where $t_s$ is the time of emission and $c$ is the speed of signal propagation.

## Optimization Formulation
- **Optimization Type:** Non-linear optimization problem.
- **Optimization Parameters:**
  - $s_x, s_y$: Coordinates of the signal source.
  - $t_s$: Time of emission.
- **Optimization Variables:**
  - $s_x, s_y, t_s$: Decision variables.
- **Objective:** Minimize the sum of squared differences between predicted and measured TOA.
  - Minimize $f(s_x, s_y, t_s) = \sum_{i=1}^{M} (t_i - (t_s + \frac{d_i}{c}))^2$.
- **Constraints:** 
  - Physical constraints on source position and time of emission.

## Optimization Algorithm
- **Algorithm Type:** Gradient-based optimization method.
- **Algorithm Parameters:**
  - Learning rate $\alpha$.
  - Convergence threshold $\epsilon$.
- **Algorithm Steps:**
  1. Initialize $s_x, s_y, t_s$.
  2. Compute the gradient of the objective function w.r.t. $s_x, s_y, t_s$.
  3. Update variables: 
     $s_x = s_x - \alpha \frac{\partial f}{\partial s_x}$,
     $s_y = s_y - \alpha \frac{\partial f}{\partial s_y}$,
     $t_s = t_s - \alpha \frac{\partial f}{\partial t_s}$.
  4. Repeat steps 2 and 3 until convergence criteria are met.