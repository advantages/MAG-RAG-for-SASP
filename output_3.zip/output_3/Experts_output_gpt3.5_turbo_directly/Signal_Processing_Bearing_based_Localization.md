2024-05-02 10:40:05.263386

### System Model
- **Problem Type:** Source Localization using sensor array measurements with bearing angle information.
- **Problem Description:** Localizing a signal source using bearing angle measurements from a sensor array with sensors at different positions.
- **System Model Parameters:
  - $M$: Number of sensors
  - $(x_i, y_i)$: Position of sensor $i$
  - $\theta_i$: Measured angle by sensor $i$ with possible Gaussian noise
- **System Model Formulations:**
  - Bearing Angle Model: $\theta_i = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right) + \eta_i$ where $\eta_i$ represents the noise

### Optimization Formulation
- **Optimization Type:** Localization optimization problem
- **Optimization Parameters:**
  - Sensor positions $(x_i, y_i)$
  - Measured bearing angles $\theta_i$
- **Optimization Variables:**
  - Source position $(x_s, y_s)$
- **Objective:** Minimize the error between predicted and measured bearing angles.
- **Constraints:**
  - Non-linear constraint based on bearing angle measurements

### Optimization Algorithm
- **Algorithm Type:** Non-linear optimization algorithm like Gradient Descent
- **Algorithm Parameters:**
  - Learning rate
  - Convergence threshold
- **Algorithm Steps:**
  - Initialize source position $(x_s, y_s)$
  - Compute predicted bearing angles using source position
  - Compute error between predicted and measured bearing angles
  - Update source position using gradient descent to minimize error

By following this structured approach, we can effectively localize the signal source using sensor array measurements and bearing angle information.