2024-05-02 10:40:05.263386

### System Model
- **Problem Type:** Source Localization in Sensor Array Signal Processing
- **Problem Description:** The task is to estimate the position of a signal source in two-dimensional space using signal samples collected from multiple sensors in the sensor array.
- **System Model Parameters:** 
  - $M$: Number of sensors in the array
  - $x_s, y_s$: Coordinates of the source signal
  - $x_i, y_i$: Coordinates of sensor $i$
  - $d_i$: Distance between sensor $i$ and the source signal
  - $\theta_i$: Angle between sensor $i$ and the x-axis
- **System Model Formulations:** 
  - The signal received by sensor $i$ can be expressed as:
  $$r_i(t) = A\cos(2\pi f_ct_i + \phi_i)$$
  where $A$ is the amplitude, $f_c$ is the carrier frequency, $t_i$ is the time of arrival at sensor $i$, and $\phi_i$ is the phase shift.
  - The time of arrival difference between sensors can be related to the distance and angle as:
  $$\Delta t_{ij} = \frac{d_i - d_j}{c}$$
  where $c$ is the speed of light.
  - The distance and angle can be related as:
  $$d_i = \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}$$
  $$\tan(\theta_i) = \frac{y_s - y_i}{x_s - x_i}$$

### Optimization Formulation
- **Optimization Type:** Non-convex Optimization
- **Optimization Parameters:** 
  - $\{d_i, \theta_i\}$: Parameters to be optimized
  - $d_{\text{max}}$: Maximum allowable distance
- **Optimization Variables:** 
  - $d_i$: Distance between sensor $i$ and the source signal
  - $\theta_i$: Angle between sensor $i$ and the x-axis
- **Objective:** 
  Minimize the sum of squares of the differences between the theoretical and estimated time of arrivals:
  $$\min \sum_{i<j} (\Delta t_{ij} - \hat{\Delta t}_{ij})^2$$
- **Constraints:** 
  - $0 \leq d_i \leq d_{\text{max}}$
  - $-\pi \leq \theta_i \leq \pi$

### Optimization Algorithm
- **Algorithm Type:** Non-linear Least Squares (NLS) Algorithm
- **Algorithm Parameters:** 
  - Initial guess for $d_i$ and $\theta_i$
  - Tolerance for convergence
- **Algorithm Steps:** 
  1. Initialize $d_i$ and $\theta_i$
  2. Compute the estimated time of arrivals $\hat{\Delta t}_{ij}$
  3. Calculate the objective function
  4. Update $d_i$ and $\theta_i$ using the NLS algorithm
  5. Repeat steps 2-4 until convergence criterion is met

By following this structured approach, we can effectively estimate the position of the signal source using the sensor array data.