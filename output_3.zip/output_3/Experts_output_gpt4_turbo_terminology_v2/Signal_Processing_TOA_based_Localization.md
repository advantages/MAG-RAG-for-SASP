2024-06-10 22:41:54.670644

### System Model

- **Problem Type:** Source Localization using Time of Arrival (TOA) measurements.
- **Problem Description:** 
This signal processing problem involves pinpointing the origin of a signal based on the TOA measurements obtained from a dispersed array of sensors. Each sensor collects the TOA data when a signal, emitted from an unknown location, reaches them. The locations of these sensors are known, and the corresponding TOA of the signal to each sensor is used to infer the signal’s origin.
- **System Model Parameters:** 
  - $(x_i, y_i)$: Known coordinates of the $i$-th sensor.
  - $t_i$: Time of arrival of the signal at the $i$-th sensor.
  - $(x_s, y_s)$: Unknown coordinates of the signal source.
  - $c$: Speed of the signal propagation (often the speed of light/sound, depending on the signal type).
- **System Model Formulations:** 
Each sensor captures the signal at a different time based on the distance from the source. The distance ($d_i$) from the source to the $i$-th sensor can be modeled as:
  $$
  d_i = \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}
  $$
Using the TOA, the distance relation becomes,
  $$
  c \cdot t_i = \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2} \quad \forall i \in \{1, 2, \ldots, M\}
  $$

### Optimization Formulation

- **Optimization Type:** Nonlinear Least Squares Optimization.
- **Optimization Parameters:** 
  - Parameters: $(x_i, y_i), t_i$ for each sensor $i$.
  - Constants: Speed of signal propagation $c$.
- **Optimization Variables:** 
  - Decision variables: $(x_s, y_s)$, the coordinates of the signal source.
- **Objective:** 
Minimize the sum of squared residuals between the actual TOA measurements and the theoretical TOA based on the hypothesized source location:
  $$
  \min_{(x_s, y_s)} \sum_{i=1}^M \left(c \cdot t_i - \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}\right)^2
  $$
- **Constraints:** 
  - There are no explicit constraints beyond the requirement that the hypothesized source coordinates should result in non-negative times of arrival.

### Optimization Algorithm

- **Algorithm Type:** Levenberg-Marquardt Algorithm (a popular method for solving nonlinear least squares problems).
- **Algorithm Parameters:** 
  - Convergence Threshold: Small value indicating how close consecutive estimates of the source location should be before stopping.
  - Maximum Iterations: Upper limit on the number of iterations to prevent infinite loops in case convergence is slow or unachievable.
- **Algorithm Steps:**
  1. **Initialization:** Select an initial guess for the source coordinates, $(x_s^{(0)}, y_s^{(0)})$.
  2. **Iterative Update:** At each iteration $k$, update the source location by solving the linearized form of the least squares problem:
     $$
     \Delta \approx J^T J \Delta = -J^T r
     $$
     where $J$ is the Jacobian matrix of partial derivatives of the residuals with respect to $(x_s, y_s)$, and $r$ is the residual vector at iteration $k$.
  3. **Convergence Check:** Compute the difference between the source locations in successive iterations. If this difference is below the convergence threshold or if the maximum number of iterations is reached, stop the algorithm.
  4. **Output:** The estimated source coordinates $(x_s, y_s)$ that minimize the objective function.

This structured approach systematically addresses the framed problem, applying theoretical models and optimizing source localization using a robust scientific methodology.