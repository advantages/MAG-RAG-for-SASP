2024-05-07 11:30:19.898678

**System Model**

* **Problem Type:** Direction-of-Arrival (DoA) estimation for sensor array signal processing.
* **Problem Description:** Given a set of observations $\{\mathbf{y}_i\}_{i=1}^M$ and the estimated noise subspace eigenvectors $\hat{\mathbf{U}}_n$, estimate the DoAs $\boldsymbol{\theta}$ that lie in the signal subspace of $\mathbf{R}$.
* **System Model Parameters:**
	+ $\mathbf{a}(\boldsymbol{\theta})$: Steering vector corresponding to the DoA vector $\boldsymbol{\theta}$.
	+ $\hat{\mathbf{U}}_n$: Estimated noise subspace eigenvectors.
* **System Model Formulations:** None required, as this is a spectral search problem.

### Optimization Formulation

* **Optimization Type:** Spectral search optimization.
* **Optimization Parameters:**
	+ Search grid for $\boldsymbol{\theta}$.
	+ $\hat{\mathbf{U}}_n$: Estimated noise subspace eigenvectors.
* **Optimization Variables:** $\boldsymbol{\theta}$, the DoA vector to be estimated.
* **Objective:** Minimize the MUSIC cost function $P_{\text{MUSIC}}(\boldsymbol{\theta})$ or maximize the SSMUSIC cost function $P_{\text{SSMUSIC}}(\boldsymbol{\theta})$.
* **Constraints:**
	+ $\mathbf{a}(\boldsymbol{\theta})$: Steering vector corresponding to the DoA vector $\boldsymbol{\theta}$.

### Optimization Algorithm

* **Algorithm Type:** Spectral search algorithm.
* **Algorithm Parameters:**
	+ Search grid for $\boldsymbol{\theta}$.
	+ Learning rate (not specified).
* **Algorithm Steps:**
	1. Compute the sample covariance matrix $\hat{\mathbf{R}}$ from the observations $\{\mathbf{y}_i\}_{i=1}^M$.
	2. Perform eigendecomposition of $\hat{\mathbf{R}}$ to obtain $\{\hat{\lambda}_i\}_{i=1}^N$ and $\{\hat{\mathbf{u}}_i\}_{i=1}^N$.
	3. Construct the estimated noise subspace $\hat{\mathbf{U}}_n = [\hat{\mathbf{u}}_{K+1}, \hat{\mathbf{u}}_{K+2}, \ldots, \hat{\mathbf{u}}_N]$.
	4. For each value of $\boldsymbol{\theta}$ on the search grid:
		- Compute the steering vector $\mathbf{a}(\boldsymbol{\theta})$.
		- Evaluate the MUSIC cost function $P_{\text{MUSIC}}(\boldsymbol{\theta})$ or the SSMUSIC cost function $P_{\text{SSMUSIC}}(\boldsymbol{\theta})$.
	5. The estimated DoAs $\hat{\boldsymbol{\theta}}$ correspond to the $K$ deepest minima of $P_{\text{MUSIC}}(\boldsymbol{\theta})$ or the $K$ highest maxima of $P_{\text{SSMUSIC}}(\boldsymbol{\theta})$.