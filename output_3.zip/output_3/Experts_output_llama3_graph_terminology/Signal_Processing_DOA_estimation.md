2024-05-07 11:30:19.898678

Here is the rewritten text in the requested format:

### System Model
- **Problem Type:** Direction-of-arrival (DOA) estimation for multiple narrowband plane waves impinging on a sensor array
- **Problem Description:** Consider K uncorrelated narrowband plane waves impinging on an M-element uniform linear array with element spacing d. The complex-valued received signal y(n) is observed at n = 1, 2, ..., N time samples.
- **System Model Parameters:**
    - K: number of sources
    - M: number of sensors
    - d: element spacing
    - N: number of time samples
- **System Model Formulations:** Let x(k) be the k-th source signal and y(n) = Hx(n) + w(n), where H is the (M × K) mixing matrix, x(n) is the K-dimensional vector containing all signals at time n, and w(n) is the M-dimensional vector of additive white Gaussian noise.
### Optimization Formulation
- **Optimization Type:** First-order perturbation analysis
- **Optimization Parameters:**
    - ΔUo: perturbation in the orthogonal subspace basis vectors due to noise and sensor errors
    - ΔUs: perturbation in the signal subspace basis vectors due to noise and sensor errors
- **Optimization Variables:** θ(k): DOA estimate of the k-th source
- **Objective:** Minimize the mean-squared error (MSE) between the true and estimated DOAs, E[(Δθk)^2]
- **Constraints:**
    - The optimization variables θ(k) are bounded by physical constraints, such as |θ(k)| ≤ π/2.

### Optimization Algorithm
- **Algorithm Type:** First-order perturbation analysis
- **Algorithm Parameters:**
    - None required for this algorithm type.
- **Algorithm Steps:**
    1. Derive expressions for ΔUo and ΔUs in terms of the data perturbation matrix ΔY using a first-order perturbation expansion.
    2. Relate the subspace perturbations ΔUo and ΔUs to the perturbations in the DOA estimates Δθk.
    3. Derive expressions for the MSE E[(Δθk)^2] in terms of the subspace perturbations, noise, and sensor error variances.
    4. Specialize the MSE expressions for different algorithms by substituting the appropriate parameters.