2024-05-03 23:38:55.550574

### System Model
- **Problem Type:** Signal Detection and Spatial Localization using a Distributed Antenna Array with QPSK Signals.
- **Problem Description:** The task is to detect primary signals transmitted by an unknown emitter using a distributed array of $p$ antennas. These signals are described as having limited bandwidth and are modulated using Quadrature Phase Shift Keying (QPSK). The challenge involves appropriately processing and analyzing the signals captured by multiple antennas to confirm signal presence, estimate the direction of arrival (DOA), and potentially pinpoint the emitter's location.
- **System Model Parameters:**
  - $p$: number of antennas in the distributed array.
  - $s(t)$: transmitted QPSK signal.
  - $x_i(t)$: signal received at the $i$-th antenna, which is a mixture of $s(t)$ and noise $n_i(t)$.
  - $n_i(t)$: noise at the $i$-th antenna, assumed to be Gaussian and independent identically distributed (i.i.d).
  - $d_i(\theta)$: steering vector at the $i$-th antenna corresponding to an incoming signal from direction $\theta$.
  - $c$: speed of light.
  - $f$: carrier frequency of the signal.
  - $\lambda = c/f$: wavelength of the transmitted signal.
- **System Model Formulations:**
  $$ x_i(t) = a_id_i(\theta)s(t) + n_i(t), \quad i = 1, \ldots, p $$
  $$ \mathbf{x}(t) = \mathbf{A}\mathbf{D}(\theta)\mathbf{s}(t) + \mathbf{n}(t) $$
  Where $\mathbf{A}$ is a diagonal matrix containing the amplitudes $a_i$, $\mathbf{D}(\theta)$ is a diagonal matrix formulated by the steering vectors, $\mathbf{s}(t)$ is the signal vector, and $\mathbf{n}(t)$ is the noise vector.

### Optimization Formulation
- **Optimization Type:** Multi-objective Optimization under constraints.
- **Optimization Parameters:**
  - Signal-to-noise ratio (SNR) desired.
  - Power budget for signal reception.
- **Optimization Variables:**
  - $\theta$: DOA of the incoming signal.
  - $\mathbf{w}$: beamforming weights applied to the received signals at the antennas.
- **Objective:**
  $$ \text{maximize} \quad SNR = \frac{| \mathbf{w}^H \mathbf{A}\mathbf{D}(\theta)\mathbf{s}(t) |^2}{\mathbf{w}^H\mathbf{w}} $$
- **Constraints:**
  - $\sum_{i=1}^p |w_i|^2 \leq P$, P is the total power budget.
  - $\mathbf{w}^H\mathbf{n}(t) = 0$, ensuring that the weight vector is orthogonal to the noise subspace.

### Optimization Algorithm
- **Algorithm Type:** Gradient Descent with Backtracking Line Search
- **Algorithm Parameters:**
  - Initial estimates for $\mathbf{w}$ and $\theta$.
  - Learning Rate $\alpha$, decay factor $\beta$.
  - Convergence threshold $\epsilon$.
- **Algorithm Steps:**
  1. **Initialization**: Start with initial guesses for $\mathbf{w}$ and $\theta$.
  2. **Iterative Update**:
     - Compute gradient of the objective function with respect to $\mathbf{w}$ and $\theta$.
     - Update $\mathbf{w}$ and $\theta$ using gradient descent:
       $$ \mathbf{w}_{\text{new}} = \mathbf{w} - \alpha \nabla_{\mathbf{w}}(\text{objective}) $$
       $$ \theta_{\text{new}} = \theta - \alpha \nabla_{\theta}(\text{objective}) $$
     - Adjust $\alpha$ based on the improvement in the objective function using backtracking line search.
  3. **Convergence Check**: Repeat the iterative process until the change in the objective function is less than $\epsilon$.
  4. **Output**: Report the optimized values of $\theta$ and $\mathbf{w}$, and the maximum achieved SNR.

This structured approach ensures the problem is approached systematically, using advanced signal processing techniques to maximize signal detection and DOA estimation efficacy.