2024-05-03 23:38:55.550574

### System Model

- **Problem Type:** Source Localization using Time of Arrival (TOA) Measurements in Sensor Arrays.
- **Problem Description:** The task is to localize a signal source based on the time of arrival (TOA) measurements collected from multiple sensors positioned at known locations. Each sensor records the time at which a signal emitted from an unknown source is received. The challenge is compounded by factors such as sensor placement, signal propagation delay, and potential environmental effects that may introduce errors in timing measurements.
- **System Model Parameters:** 
  - $(x_i, y_i)$: The known coordinates of sensor $i$.
  - $t_i$: TOA measurement at sensor $i$, i.e., the time it takes for the signal to travel from the source to the sensor.
  - $(x_s, y_s)$: Unknown coordinates of the source to be estimated.
  - $c$: Speed of signal propagation (assumed constant and known).
- **System Model Formulations:** 
  - The equation governing the TOA from the source to the sensor is given by:
    $$
    t_i = \frac{\sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}}{c} + n_i
    $$
    where $n_i$ represents the measurement noise at sensor $i$.
  - Thus, the objective is to find $(x_s, y_s)$ that minimizes the error in the estimated TOA across all sensors.

### Optimization Formulation

- **Optimization Type:** Nonlinear Least Squares Optimization.
- **Optimization Parameters:** 
  - Speed of signal propagation $c$.
  - Sensors' coordinates $(x_i, y_i)$ for $i=1,2,\ldots,M$.
  - Measured TOAs $t_i$ for $i=1,2,\ldots,M$.
- **Optimization Variables:** 
  - Source coordinates $(x_s, y_s)$ to be estimated.
- **Objective:** 
  - Minimize the sum of squared residuals between the measured and calculated TOAs:
    $$
    \min_{(x_s, y_s)} \sum_{i=1}^M \left(t_i - \frac{\sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}}{c} \right)^2
    $$
- **Constraints:** 
  - Physical constraints: $(x_s, y_s)$ must lie within a feasible region if such limits are known a priori.

### Optimization Algorithm

- **Algorithm Type:** Gradient Descent (or a suitable variant like Levenberg-Marquardt for handling nonlinearities effectively).
- **Algorithm Parameters:** 
  - Learning rate (in case of gradient descent).
  - Convergence threshold $\epsilon$, i.e., the algorithm stops when the change in the objective function value is less than $\epsilon$ between iterations.
  - Maximum number of iterations to prevent infinite loops.
- **Algorithm Steps:** 
  1. **Initialization**: Start with an initial guess for $(x_s, y_s)$.
  2. **Iteration**: Update the source position estimate by moving against the gradient of the objective function:
       $$
       (x_s, y_s)^{new} = (x_s, y_s) - \eta \nabla \left( \sum_{i=1}^M \left(t_i - \frac{\sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}}{c} \right)^2 \right)
       $$
       where $\eta$ is the learning rate.
  3. **Convergence Check**: Repeat step 2 until the decrease in the objective function is below $\epsilon$ or the maximum iterations are reached.
  4. **Termination**: Output the estimated coordinates $(x_s, y_s)$ as the source location.

This structured approach provides a clear and systematic way to address the TOA-based source localization problem by using sensor measurements and optimization techniques.