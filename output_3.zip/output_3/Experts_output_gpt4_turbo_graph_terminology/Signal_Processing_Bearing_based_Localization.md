2024-05-06 23:15:24.108031

# System Model

- **Problem Type:** Angle of arrival (AOA) based source localization using sensor arrays.
- **Problem Description:** The task is to localize the position of a signal source based on the measured bearing angles from multiple sensors placed at known positions. Each sensor measures the angle from which the signal originates relative to some reference direction (often North or along the positive x-axis), and these measurements may be corrupted by Gaussian noise.
- **System Model Parameters:** 
  - **\(M\)**: Number of sensors.
  - **\((x_i, y_i)\)**: Known coordinates of sensor \(i\).
  - **\(\theta_i\)**: Measured bearing angle from sensor \(i\) to the signal source.
  - **\(\sigma_i^2\)**: Variance of the measurement noise affecting \(\theta_i\).
- **System Model Formulations:** 
  - Let \((x, y)\) be the unknown coordinates of the signal source. The true bearing angle from sensor \(i\) to the source \(\theta_{i,true}\) can be calculated by:
    \[
    \theta_{i,true} = \arctan2(y - y_i, x - x_i)
    \]
  - The observed bearing angle is then modeled as:
    \[
    \theta_i = \theta_{i,true} + n_i, \quad n_i \sim \mathcal{N}(0, \sigma_i^2)
    \]
  - Thus, the relationship between the observed angle \(\theta_i\), and the position \((x, y)\) of the source, is affected by the noise \(n_i\).

# Optimization Formulation

- **Optimization Type:** Non-linear least squares (NLS) problem.
- **Optimization Parameters:** 
  - **Observations**: \(\theta_i\) for \(i = 1, 2, \ldots, M\).
  - **Measurement Noise Variance**: \(\sigma_i^2\) for \(i = 1, 2, \ldots, M\).
- **Optimization Variables:** 
  - The unknown source coordinates \((x, y)\).
- **Objective:** 
  - Minimize the sum of squared residuals of the differences between the measured angles \(\theta_i\) and the predicted angles based on the source position:
    \[
    J(x, y) = \sum_{i=1}^{M} \left(\theta_i - \arctan2(y - y_i, x - x_i)\right)^2
    \]
- **Constraints:** 
  - No explicit constraints on \((x, y)\), but the solution must be real and feasible given the geometry of sensor placements.

# Optimization Algorithm

- **Algorithm Type:** Iterative re-weighted least squares (IRLS) suitable for dealing with possibly non-uniform measurement variances and ensuring robustness to outliers.
- **Algorithm Parameters:** 
  - **Initial Guess**: (\(x^0, y^0\)), typically chosen based on heuristic or prior information.
  - **Convergence Threshold**: \(\epsilon\), usually a small value close to machine precision to determine when the iterative process has sufficiently converged.
- **Algorithm Steps:** 
  1. **Initialization**: Start with an initial guess \((x^0, y^0)\).
  2. **Iterative Update**: For each iteration \(k\):
      - Compute the predicted angles \(\hat{\theta}_{i}^k = \arctan2(y^k - y_i, x^k - x_i)\).
      - Compute weights based on current residuals, where weights \(w_i^k = 1 / \sigma_i^2\) to account for different noise levels.
      - Update \((x, y)\) by solving the weighted least squares problem:
      \[
        (x^{k+1}, y^{k+1}) = \text{argmin}_{(x, y)} \sum_{i=1}^{M} w_i^k \left(\theta_i - \arctan2(y - y_i, x - x_i)\right)^2
      \]
  3. **Convergence Check**: Stop if \(\|(x^{k+1}, y^{k+1}) - (x^k, y^k)\| < \epsilon\).
  4. **Finalization**: Return the last computed values \((x^*, y^*)\) as the estimated source position.

This structure ensures that each aspect of the problem is dissected and addressed methodically, paving the way for a clear and detailed solution to the source localization challenge based on the bearing angles measured by an array of sensors.