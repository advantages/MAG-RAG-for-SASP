2024-05-06 23:15:24.108031

### System Model
- **Problem Type:** Time-of-Arrival (TOA) based source localization.
- **Problem Description:** The task is to determine the position of a signal source based on the time-of-arrival of a signal detected by multiple sensors fixed at known positions. This involves computing the distance from each sensor to the source using the speed of light and the TOA measurements, while accounting for potential errors such as signal noise and non-line-of-sight (NLOS) conditions.
- **System Model Parameters:**
  - $M$: Number of sensors.
  - $(x_i, y_i)$: Known Cartesian coordinates of sensor $i$.
  - $t_i$: Time-of-arrival of the signal at sensor $i$.
  - $c$: Speed of light, used to convert TOA measurements to distances.
  - $\mathbf{x} = [x, y]^T$: Unknown location of the signal source.
- **System Model Formulations:** 
   - The distance $d_i$ from the source to sensor $i$ is ideally $d_i = c t_i$. However, considering measurement noise and potential NLOS conditions:
   $$
   \hat{d}_i = c t_i = \sqrt{(x - x_i)^2 + (y - y_i)^2} + b_i + n_i
   $$
   where $b_i$ represents a potential NLOS error, and $n_i$ represents measurement noise.

### Optimization Formulation
- **Optimization Type:** Non-linear least squares (NLLS) minimization.
- **Optimization Parameters:**
  - $\mathbf{t} = [t_1, t_2, \ldots, t_M]^T$: Vector of TOA measurements.
  - $\mathbf{r} = [(x_1, y_1), (x_2, y_2), \ldots, (x_M, y_M)]^T$: Matrix of sensor locations.
  - Noise and NLOS biases ($b_i$, $n_i$) are implicitly considered in the distance calculations.
- **Optimization Variables:** $\mathbf{x} = [x, y]^T$, the Cartesian coordinates of the source location.
- **Objective:**
  $$
  \min_{\mathbf{x}} \sum_{i=1}^M \left( \sqrt{(x - x_i)^2 + (y - y_i)^2} - c t_i \right)^2
  $$
  The objective is to minimize the squared error between the computed distances from the estimated source location to each sensor and the distances derived from the TOA measurements.
- **Constraints:** There are no explicit constraints in this formulation. Implicit constraints include the physical plausibility of the source location relative to sensor positions.

### Optimization Algorithm
- **Algorithm Type:** Non-linear least squares using gradient-based optimization.
- **Algorithm Parameters:** 
  - Step size or learning rate, which may be dynamic.
  - Convergence threshold, $\epsilon$, to determine when the iterative process should stop.
- **Algorithm Steps:**
  1. **Initialization:** Start with an initial estimate for the source location $\mathbf{x}^{(0)} = [x^{(0)}, y^{(0)}]^T$.
  2. **Iterative Update:** At each iteration $k$, update the location estimate $\mathbf{x}^{(k)}$ using a gradient step:
     $$
     \mathbf{x}^{(k+1)} = \mathbf{x}^{(k)} - \alpha^{(k)} \nabla f(\mathbf{x}^{(k)})
     $$
     where $\alpha^{(k)}$ is the step size and $\nabla f(\mathbf{x}^{(k)})$ is the gradient of the objective function at $\mathbf{x}^{(k)}$.
  3. **Gradient Computation:** The gradient of the objective function, given by:
     $$
     \nabla f(\mathbf{x}) = -2 \sum_{i=1}^M \left(\sqrt{(x - x_i)^2 + (y - y_i)^2} - c t_i \right) \frac{(x - x_i, y - y_i)}{\sqrt{(x - x_i)^2 + (y - y_i)^2}}
     $$
  4. **Convergence Check:** Terminate the algorithm when the improvement of the objective function is less than a threshold $\epsilon$.
  5. **Output:** The algorithm outputs the estimated source location $\mathbf{x}^*$.

This systematic approach ensures a comprehensive solution to precisely locate the signal source using TOA measurements, accounting for realistic non-ideal conditions such as measurement noise and NLOS effects.