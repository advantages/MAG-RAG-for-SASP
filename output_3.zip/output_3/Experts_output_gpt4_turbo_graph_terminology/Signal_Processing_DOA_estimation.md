2024-05-06 23:15:24.108031

### System Model

- **Problem Type:** Direction of Arrival (DOA) Estimation in a Uniform Linear Array (ULA)
- **Problem Description:** The challenge is to estimate the angle of arrival, Θ, of a signal emitted from a source as it impinges on a ULA with *N* sensors and a specific array spacing, which is half the signal's wavelength. This type of signal processing problem is crucial for applications such as radar, sonar, and wireless communications where source localization is required.
- **System Model Parameters:**
  - *N* (Number of sensors in the ULA)
  - *θ* (Direction of Arrival of the signal)
  - *d* = λ/2 (Spacing between adjacent sensors, half of the wavelength λ)
  - *s(t)* (Signal emitted by the source)
  - *K* (Number of signal samples collected)
- **System Model Formulations:**
  - The signal received at the m-th sensor is given by:
    $$
    x_m(t) = s(t) \, e^{j 2\pi \frac{d}{\lambda} m \sin(\theta)} + n_m(t)
    $$
  - where \( n_m(t) \) is the noise at the m-th sensor.
  - The vector of signals at all sensors can be modeled as:
    $$
    \mathbf{x}(t) = \mathbf{a}(\theta) s(t) + \mathbf{n}(t)
    $$
  - where \(\mathbf{a}(\theta) = [1, e^{j\pi \sin(\theta)}, e^{j2\pi \sin(\theta)}, \dots, e^{j(N-1)\pi \sin(\theta)}]^T\) is the steering vector.

### Optimization Formulation

- **Optimization Type:** Subspace-based DOA estimation using ESPRIT (Estimation of Signal Parameters via Rotational Invariance Techniques).
- **Optimization Parameters:**
  - *R* (Covariance matrix of the array output)
  - Signal and noise subspace matrices derived from Eigenvalue Decomposition (EVD) of *R*.
- **Optimization Variables:** DOA parameter Θ
- **Objective:** Minimize the error in the estimated DOA by maximizing the alignment of the estimated signal subspace with the actual signal subspace.
- **Constraints:** The estimated DOA \(\theta\) should be within the physically feasible range \([-90^\circ, 90^\circ]\).

### Optimization Algorithm

- **Algorithm Type:** ESPRIT Algorithm for DOA Estimation
- **Algorithm Parameters:**
  - Number of estimated source signals.
- **Algorithm Steps:**
  1. **Estimate the Covariance Matrix:**
     $$
     \hat{R} = \frac{1}{K} \sum_{k=1}^K \mathbf{x}(k) \mathbf{x}(k)^H
     $$
     where \( \mathbf{x}(k) \) is the data vector at the k-th time sample.
  2. **Eigenvalue Decomposition:**
     Decompose \(\hat{R}\) to obtain the signal subspace \(\mathbf{U}_s\) and the noise subspace \(\mathbf{U}_n\).
  3. **Subspace Separation:**
     Partition \(\mathbf{U}_s\) into two submatrices \(\mathbf{U}_1\) and \(\mathbf{U}_2\) based on successive sensor elements.
  4. **Solve the ESPRIT Equation:**
     $$
     \phi = (\mathbf{U}_1^H \mathbf{U}_1)^{-1} \mathbf{U}_1^H \mathbf{U}_2
     $$
     Compute the eigenvalues of \(\phi\), which are related to \(e^{j\pi \sin(\theta)}\).
  5. **Estimate DOAs:**
     $$
     \theta = \arcsin\left(\frac{1}{\pi} \text{arg}(\text{eig}(\phi))\right)
     $$
  6. **Termination Criterion:**
     Loop through steps 1 to 5 until convergence or until the change in estimated Θ between iterations is below a pre-determined threshold.

By following these steps systematically, we can effectively estimate the source's DOA from the sampled signals at the uniform linear array. The accuracy of the DOA estimate will potentially increase with the number of snapshots \(K\), which can be empirically verified through simulations.