2024-05-06 23:15:24.108031

# System Model

## Problem Type
Direction-of-Arrival (DoA) estimation using a distributed sensor array in a two-dimensional plane.

## Problem Description
The primary challenge is to estimate the precise location of a continuously emitting signal source using a network of M spatially distributed sensors. Each sensor captures the signal emitted by the source and sends these measurements to a centralized data fusion center. The task involves accurately determining the position (\(x\), \(y\)) of the signal source based on the data collected by these sensors.

## System Model Parameters
- \( M \): Total number of sensors in the array.
- \( (x, y) \): Unknown coordinates of the signal source.
- \( (x_m, y_m) \): Known coordinates of the \(m\)-th sensor.
- \( d_{m} \): Distance from the \(m\)-th sensor to the signal source.
- \( t_{m} \): Time delay for the signal to travel from the source to the \(m\)-th sensor.
- \( c \): Speed of signal propagation (assumed to be known and constant).
- \( s(t) \): Signal emitted by the source.
- \( n_{m}(t) \): Noise at the \(m\)-th sensor.
- \( r_{m}(t) \): Signal received by the \(m\)-th sensor.

## System Model Formulations
The received signal at the \(m\)-th sensor can be modeled as:
\[ r_{m}(t) = s(t - t_{m}) + n_{m}(t), \]
where the time delay \( t_{m} \) is related to the distance \( d_{m} \) by \( t_{m} = \frac{d_{m}}{c} \).
The distance \( d_{m} \) from the signal source to the \(m\)-th sensor is given by:
\[ d_{m} = \sqrt{(x - x_{m})^{2} + (y - y_{m})^{2}}. \]

# Optimization Formulation

## Optimization Type
Non-linear least squares optimization problem.

## Optimization Parameters
- \( \vec{p} = [x, y] \): Coordinates of the signal source.
- \( \vec{p}_m = [x_m, y_m] \): Coordinates of the sensors.

## Optimization Variables
- \( \vec{\theta} = [x, y] \): Decision variables representing the estimated coordinates of the signal source.

## Objective
Minimize the sum of squared residuals between the estimated and actual time delays for all sensors:
\[ \text{Minimize } J(\vec{\theta}) = \sum_{m=1}^{M} \left( \hat{t}_m(\vec{\theta}) - t_{m} \right)^2, \]
where \( \hat{t}_m(\vec{\theta}) = \frac{\sqrt{(x - x_m)^2 + (y - y_m)^2}}{c} \).

## Constraints
The estimated position \( \vec{\theta} = [x, y] \) must be physically plausible within the domain defined by the environmental setup and sensor locations.

# Optimization Algorithm

## Algorithm Type
Iterative nonlinear optimization algorithm (Levenberg-Marquardt algorithm).

## Algorithm Parameters
- Convergence threshold \( \epsilon \).
- Maximum number of iterations \( N_{max} \).

## Algorithm Steps
1. **Initialization:** Start with an initial guess \( \vec{\theta}^{(0)} \) for the source coordinates.
2. **Iteration:** For each iteration \( k \):
   - Compute the Jacobian matrix \( \mathbf{J}_k \) of partial derivatives of the estimated time delays with respect to \( x \) and \( y \).
   - Update the estimate \( \vec{\theta}^{(k+1)} \) using the Levenberg-Marquardt update rule:
     \[ \vec{\theta}^{(k+1)} = \vec{\theta}^{(k)} - \left( \mathbf{J}_k^T \mathbf{J}_k + \lambda \mathbf{I} \right)^{-1} \mathbf{J}_k^T \mathbf{r}_k, \]
     where \( \mathbf{r}_k \) is the vector of residuals and \( \lambda \) is the damping factor.
3. **Check for convergence:** If \( \|\vec{\theta}^{(k+1)} - \vec{\theta}^{(k)}\| < \epsilon \) or \( k = N_{max} \), stop. Else, go to step 2.
4. **Output:** Return the estimated coordinates \( \vec{\theta} \).

This structured approach enables the accurate estimation of the signal source position using the data fusion center based on the measurements from the distributed sensor network.