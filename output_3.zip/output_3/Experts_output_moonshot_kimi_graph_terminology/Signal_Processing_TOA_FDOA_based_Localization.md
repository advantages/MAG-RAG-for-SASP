2024-05-07 00:50:15.845798

### System Model

#### Problem Type:
The problem at hand is a hybrid localization and signal parameter estimation issue within the domain of wireless sensor networks. Specifically, it involves estimating the position of a signal source using Time Difference of Arrival (TDOA) and Frequency Difference of Arrival (FDOA) measurements from multiple sensors.

#### Problem Description:
The challenge is to accurately determine the location of a signal source in a two-dimensional (2D) or three-dimensional (3D) space using TDOA and FDOA measurements from an array of M sensors positioned at known coordinates \((x_i, y_i)\) for TDOA and \((x_i, y_i, z_i)\) for FDOA, where \(i = 1, 2, \ldots, M\). Each sensor provides TDOA measurements, which are the differences in the arrival times of a signal at the sensor pair, and FDOA measurements, which are the differences in the frequencies of the received signals at the sensor pair. The goal is to leverage these measurements to triangulate the position of the signal source.

#### System Model Parameters:
- \(M\): Number of sensors in the array.
- \((x_i, y_i)\): 2D coordinates of the \(i\)-th sensor for TDOA measurements.
- \((x_i, y_i, z_i)\): 3D coordinates of the \(i\)-th sensor for FDOA measurements.
- \(TDOA_{ij}\): Time difference of arrival between the \(i\)-th and \(j\)-th sensors.
- \(FDOA_{ij}\): Frequency difference of arrival between the \(i\)-th and \(j\)-th sensors.
- \(c\): Speed of light in a vacuum.
- \(v\): Speed of the signal in the medium.
- \(\mathbf{p}_s = [x_s, y_s]^T\): 2D position vector of the signal source for TDOA.
- \(\mathbf{p}_s = [x_s, y_s, z_s]^T\): 3D position vector of the signal source for FDOA.

#### System Model Formulations:
The TDOA measurements can be modeled as:
\[ TDOA_{ij} = \frac{1}{c}\left(\|\mathbf{p}_s - \mathbf{p}_i\| - \|\mathbf{p}_s - \mathbf{p}_j\|\right) + n_{ij} \]
where \(n_{ij}\) represents measurement noise or error.

The FDOA measurements can be modeled as:
\[ FDOA_{ij} = \frac{v}{c}\left(\angle(\mathbf{p}_s - \mathbf{p}_i) - \angle(\mathbf{p}_s - \mathbf{p}_j)\right) + m_{ij} \]
where \(m_{ij}\) represents measurement noise or error, and \(\angle(\cdot)\) denotes the angle of arrival.

### Optimization Formulation

#### Optimization Type:
The optimization problem is a nonlinear least squares problem, where the objective is to minimize the error between the measured TDOA and FDOA values and the values predicted by the model based on the estimated source position.

#### Optimization Parameters:
- \(TDOA_{ij}, FDOA_{ij}\): Measured TDOA and FDOA values for all sensor pairs.
- \(n_{ij}, m_{ij}\): Measurement noise/error terms assumed to be Gaussian distributed.
- \(\mathbf{p}_s\): Position of the signal source to be estimated.

#### Optimization Variables:
- \(\mathbf{p}_s\): The position of the signal source, which is the decision variable in the optimization problem.

#### Objective:
The objective is to minimize the cost function \(J(\mathbf{p}_s)\), which is the sum of the squared differences between the measured and predicted TDOA and FDOA values:
\[ J(\mathbf{p}_s) = \sum_{i < j} \left(TDOA_{ij} - \frac{1}{c}\left(\|\mathbf{p}_s - \mathbf{p}_i\| - \|\mathbf{p}_s - \mathbf{p}_j\|\right)\right)^2 + \left(FDOA_{ij} - \frac{v}{c}\left(\angle(\mathbf{p}_s - \mathbf{p}_i) - \angle(\mathbf{p}_s - \mathbf{p}_j)