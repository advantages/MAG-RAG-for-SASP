2024-05-07 00:15:38.220721

### System Model

#### Problem Type:
The problem at hand is the estimation of the position of a signal source in a two-dimensional space using an array of sensors. This falls under the domain of signal processing, specifically source localization and direction-of-arrival (DOA) estimation.

#### Problem Description:
In the given scenario, there are \( M \) sensors located at distinct positions in a two-dimensional space, each equipped with a single antenna. A signal source positioned at coordinates \( (x, y) \) is continuously emitting signals. The sensors are capable of receiving these signals and uploading the received signal samples to a data fusion center. The challenge is for the fusion center to estimate the position of the signal source based on the received signal samples.

#### System Model Parameters:
- \( M \): The number of sensors in the array.
- \( (x, y) \): The two-dimensional coordinates of the signal source.
- \( A_m \): The position vector of the \( m^{th} \) sensor in the array.
- \( d_{m} \): The distance between the \( m^{th} \) sensor and the signal source.
- \( \theta_m \): The angle of arrival (AOA) of the signal at the \( m^{th} \) sensor.
- \( s(t) \): The emitted signal as a function of time.
- \( n_m(t) \): The noise component at the \( m^{th} \) sensor as a function of time.

#### System Model Formulations:
The signal received at the \( m^{th} \) sensor can be modeled as:
\[ r_m(t) = s(t - \frac{d_m}{c}) + n_m(t) \]
where \( c \) is the speed of the signal (propagation speed), and \( t \) is the time variable.

The array manifold vector \( \mathbf{a}(\theta_m) \) for the \( m^{th} \) sensor, which encapsulates the spatial signature of the signal, can be represented as:
\[ \mathbf{a}(\theta_m) = [1, e^{-j\frac{2\pi}{\lambda}A_m \cdot \sin(\theta_m)}, \ldots, e^{-j\frac{2\pi}{\lambda}(M-1)A_m \cdot \sin(\theta_m)}]^T \]
where \( \lambda \) is the wavelength of the signal.

### Optimization Formulation

#### Optimization Type:
The optimization problem is a DOA estimation problem, which can be approached using subspace-based methods such as MUSIC (Multiple Signal Classification) or ESPRIT (Estimation of Signal Parameters via Rotational Invariance Techniques).

#### Optimization Parameters:
- \( \mathbf{R} \): The covariance matrix of the received signals across all sensors.
- \( \mathbf{U}_s \): The signal subspace spanned by the signal eigenvectors of \( \mathbf{R} \).
- \( \mathbf{U}_n \): The noise subspace spanned by the noise eigenvectors of \( \mathbf{R} \).

#### Optimization Variables:
- \( \theta_1, \theta_2, \ldots, \theta_M \): The angles of arrival for each sensor.

#### Objective:
The objective is to minimize the error between the estimated and actual positions of the signal source. This can be formulated as minimizing a cost function \( J(\theta_1, \theta_2, \ldots, \theta_M) \) that quantifies the localization error.

#### Constraints:
- The angles \( \theta_m \) must be within the physical range of sensor detection, typically \( [0, \pi] \) or \( [-\pi/2, \pi/2] \) in radians.
- The estimated positions must adhere to the two-dimensional space constraints.

### Optimization Algorithm

#### Algorithm Type:
The chosen algorithm is the ESPRIT algorithm, which is well-suited for estimating the DOAs in a noise-robust manner without requiring peak search, which is a common issue in other methods like MUSIC.

#### Algorithm Parameters:
- \( \mathbf{R} \): The covariance matrix estimated from the received signals.
- \( P \): The number of signal sources (in this case, assumed to be 1).
- \( \mathbf{T} \): The Toeplitz matrix constructed from \( \mathbf{R} \).
- \( \mathbf{U}_s \) and \( \mathbf{U}_n \): The signal and noise subspace eigenvectors from the eigendecomposition of \( \mathbf{T} \).

#### Algorithm Steps:
1. Collect signal samples from all sensors and form the data matrix