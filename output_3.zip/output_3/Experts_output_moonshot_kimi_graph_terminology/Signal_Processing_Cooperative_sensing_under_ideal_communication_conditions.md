2024-05-07 00:15:38.220721

### System Model

#### Problem Type:
The problem at hand is the detection and estimation of the direction-of-arrival (DOA) of primary signals using a distributed antenna array in a sensor network.

#### Problem Description:
A sensor network consisting of \( p \) distributed antennas is deployed to detect primary signals emitted by a signal source located within the network's coverage area. The primary signals are QPSK modulated and contain segmental information. The objective is to develop an efficient strategy that leverages the distributed antenna array to detect the primary signals and estimate their DOA.

#### System Model Parameters:
- \( p \): Number of distributed antennas in the sensor network.
- \( M \): Number of multipath components for each signal.
- \( \theta_i \): Angle of arrival for the \( i \)-th signal.
- \( \lambda \): Wavelength of the transmitted signal.
- \( d \): Distance between adjacent antennas.
- \( \mathbf{s}(t) \): Vector representing the transmitted primary signal.
- \( \mathbf{a}(\theta_i) \): Steering vector corresponding to the angle \( \theta_i \).
- \( \mathbf{H} \): Channel matrix representing the multipath components and their respective steering vectors.

#### System Model Formulations:
The received signal at the sensor network can be represented as:
\[ \mathbf{Y} = \mathbf{H}\mathbf{s}(t) + \mathbf{N} \]
where \( \mathbf{Y} \) is the \( p \times 1 \) received signal vector, \( \mathbf{H} \) is the \( p \times M \) channel matrix, \( \mathbf{s}(t) \) is the \( M \times 1 \) transmitted signal vector, and \( \mathbf{N} \) is the \( p \times 1 \) noise vector.

### Optimization Formulation

#### Optimization Type:
The optimization problem is a DOA estimation problem that can be approached using subspace-based methods, such as MUSIC or ESPRIT, combined with a preprocessing step to enhance the estimation accuracy.

#### Optimization Parameters:
- \( P \): Total number of signals, including coherent and uncorrelated signals.
- \( L \): Number of coherent signals.
- \( \Delta\phi_l \): Phase difference of the \( l \)-th coherent signal with respect to a reference signal.

#### Optimization Variables:
- \( \theta_i \): The DOA of the \( i \)-th signal to be estimated.

#### Objective:
The objective is to accurately estimate the DOAs \( \theta_i \) of all primary signals.

#### Constraints:
- The physical constraint that the angle \( \theta_i \) must lie within the range \( [0, \pi] \) radians.
- The constraint that the estimated DOAs should be consistent with the actual directions from which the signals are arriving.

### Optimization Algorithm

#### Algorithm Type:
The proposed algorithm is a combination of the FB-PTMR preprocessing step and a subspace-based DOA estimation method such as MUSIC or ESPRIT.

#### Algorithm Parameters:
- \( N \): Number of snapshots used to estimate the sample covariance matrix (SCM).
- \( \epsilon \): Tolerance level for the DOA estimation accuracy.

#### Algorithm Steps:
1. Collect \( N \) snapshots of the received signal at the sensor network to form the SCM \( \hat{\mathbf{R}} \).
2. Construct partial Toeplitz matrices \( \mathbf{R}_m \) from half rows of \( \hat{\mathbf{R}} \) for \( m = 0, 1, \ldots, M \).
3. Obtain the equivalent data covariance matrix \( \tilde{\mathbf{R}} \) by summing the squared partial Toeplitz matrices.
4. Apply forward-backward averaging to \( \tilde{\mathbf{R}} \) to improve estimation performance, resulting in \( \bar{\mathbf{R}} \).
5. Perform eigen-decomposition on \( \bar{\mathbf{R}} \) to separate the signal and noise subspaces.
6. Apply a subspace-based DOA estimation method (e.g., MUSIC or ESPRIT) using the separated subspaces to estimate the DOAs \( \theta_i \).
7. Terminate the algorithm when the estimated DOAs converge to a stable solution or when a maximum number of iterations is reached.