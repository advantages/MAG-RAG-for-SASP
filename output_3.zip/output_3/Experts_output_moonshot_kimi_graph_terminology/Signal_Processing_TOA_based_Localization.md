2024-05-07 00:50:15.845798

### System Model

#### Problem Type:
The problem at hand is a Time-of-Arrival (TOA) based wireless localization issue, where the objective is to determine the position of a signal source using TOA measurements from multiple sensors.

#### Problem Description:
In a wireless sensor network, M sensors are deployed at known positions \((x_i, y_i)\), where \(i = 1, 2, \ldots, M\). These sensors are capable of measuring the time of arrival (TOA) of signals emitted by a source. The TOA measurement by sensor \(i\) is denoted as \(t_i\). The challenge is to estimate the location of the signal source by utilizing these TOA measurements, taking into account potential non-line-of-sight (NLOS) propagation effects which can introduce errors in the localization process.

#### System Model Parameters:
- \(M\): Number of sensors.
- \((x_i, y_i)\): Cartesian coordinates of the \(i\)-th sensor position.
- \(t_i\): Time of arrival measurement at the \(i\)-th sensor.
- \(c\): Speed of light.
- \(\mathbf{x}_s = [x_s, y_s]^T\): Position vector of the signal source.

#### System Model Formulations:
The relationship between the TOA measurements and the source position can be modeled as:
\[ t_i = \frac{1}{c} \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2} + \epsilon_i, \quad i = 1, 2, \ldots, M \]
where \(\epsilon_i\) represents the measurement error or bias, which could be due to NLOS propagation or other sources of error.

### Optimization Formulation

#### Optimization Type:
The problem is formulated as a nonlinear least squares (NLS) optimization problem, where the goal is to minimize the difference between the measured TOA values and the calculated TOA values based on the estimated source position.

#### Optimization Parameters:
- \(\hat{t}_i = \frac{1}{c} \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}\): Calculated TOA for the \(i\)-th sensor based on the source position.
- \(\epsilon_i\): Measurement error or bias for the \(i\)-th sensor.

#### Optimization Variables:
- \(\mathbf{x}_s = [x_s, y_s]^T\): The position of the signal source that needs to be estimated.

#### Objective:
The objective function to be minimized is the sum of the squared differences between the measured TOA values and the calculated TOA values:
\[ \min_{\mathbf{x}_s} \sum_{i=1}^{M} (t_i - \hat{t}_i)^2 \]

#### Constraints:
- \(x_s, y_s\) are real numbers, representing the Cartesian coordinates of the source position.
- If necessary, additional constraints can be included to limit the search space within a feasible region based on prior knowledge or network deployment.

### Optimization Algorithm

#### Algorithm Type:
A gradient-based optimization algorithm, such as the Gauss-Newton method or the Levenberg-Marquardt algorithm, is suitable for solving the NLS problem. These algorithms are iterative and make use of the first and second-order derivatives of the objective function to converge to an optimal solution.

#### Algorithm Parameters:
- Learning rate: Determines the step size in each iteration, which can be adapted during the optimization process.
- Convergence threshold: A small positive value that defines when the algorithm has converged, typically based on the change in the objective function or the parameter estimates.
- Maximum iterations: An upper limit on the number of iterations to prevent the algorithm from running indefinitely.

#### Algorithm Steps:
1. **Initialization**: Start with an initial estimate of the source position \(\mathbf{x}_s^{(0)}\), which can be the centroid of the sensor positions or another reasonable guess.
2. **Iteration**: For \(k = 0, 1, 2, \ldots\) until convergence:
   a. **Compute TOA residuals**: Calculate the difference between the measured TOA \(t_i\) and the calculated TOA \(\hat{t}_i\) based on the current estimate \(\mathbf{x}_s^{(k)}\).
   b. **Compute Jacobian matrix**: Determine the Jacobian matrix \(\mathbf{J}^{(k)}\) of the TOA residuals with respect to the source position at the current estimate.
   c. **Optimization update**: Update the source position estimate using the chosen gradient-based algorithm (e.g., Gauss-Newton or Levenberg-Marquardt):
      