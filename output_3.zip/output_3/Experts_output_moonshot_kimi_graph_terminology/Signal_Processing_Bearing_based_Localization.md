2024-05-07 00:15:38.220721

### System Model

#### Problem Type:
The problem at hand is a bearing-based source localization using sensor arrays. This falls under the domain of signal processing, specifically source localization and sensor array processing.

#### Problem Description:
The challenge involves localizing a signal source by utilizing bearing angle measurements from multiple sensors. The sensors are positioned at known locations, and each sensor provides a bearing measurement, which is the angle between its position and the signal source, potentially corrupted by additive Gaussian noise. The goal is to estimate the position of the signal source based on these bearing measurements.

#### System Model Parameters:
- \( M \): Number of sensors
- \( (x_i, y_i) \): Cartesian coordinates of the \( i \)-th sensor, for \( i = 1, 2, \ldots, M \)
- \( \theta_i \): Bearing angle measurement from the \( i \)-th sensor

#### System Model Formulations:
The relationship between the sensor positions and the bearing measurements can be modeled as:
\[ \theta_i = \arctan\left(\frac{y_s - y_i}{x_s - x_i}\right) + \epsilon_i \]
where \( (x_s, y_s) \) are the unknown Cartesian coordinates of the signal source, and \( \epsilon_i \sim \mathcal{N}(0, \sigma_i^2) \) represents the additive Gaussian noise affecting the \( i \)-th sensor's measurement.

### Optimization Formulation

#### Optimization Type:
The problem is formulated as a nonlinear least squares (NLS) problem, which is a common approach for source localization based on bearing measurements.

#### Optimization Parameters:
- \( \mathbf{X} = [x_1, y_1, x_2, y_2, \ldots, x_M, y_M]^T \): Vector of known sensor positions
- \( \mathbf{\Theta} = [\theta_1, \theta_2, \ldots, \theta_M]^T \): Vector of bearing measurements
- \( \mathbf{\epsilon} = [\epsilon_1, \epsilon_2, \ldots, \epsilon_M]^T \): Vector of measurement noise
- \( \sigma_i^2 \): Variance of the Gaussian noise for the \( i \)-th sensor

#### Optimization Variables:
- \( \mathbf{p}_s = [x_s, y_s]^T \): Cartesian coordinates of the signal source

#### Objective:
The objective is to minimize the sum of the squared differences between the measured bearing angles and the calculated bearing angles based on the estimated source position:
\[ \min_{\mathbf{p}_s} \left\| \mathbf{\Theta} - \mathbf{B}(\mathbf{p}_s) \right\|^2 \]
where \( \mathbf{B}(\mathbf{p}_s) \) is the vector of calculated bearing angles from the estimated source position \( \mathbf{p}_s \) to all sensors.

#### Constraints:
- The source position \( \mathbf{p}_s \) must be within the sensor array's coverage area.

### Optimization Algorithm

#### Algorithm Type:
The chosen algorithm is the Gauss-Newton method, which is an iterative algorithm suitable for solving nonlinear least squares problems. It is chosen for its effectiveness in source localization problems with nonlinear measurement models.

#### Algorithm Parameters:
- \( \delta \): A small threshold to determine convergence (e.g., \( \delta = 10^{-6} \) )
- \( \maxiter \): Maximum number of iterations to prevent infinite loops (e.g., \( maxiter = 100 \) )

#### Algorithm Steps:
1. **Initialization**: Set an initial estimate for the source position \( \mathbf{p}_s^{(0)} \), which could be the center of the sensor array or any other reasonable starting point.
2. **Iterative Optimization**:
   1. For \( k = 1, 2, \ldots, maxiter \) (iteration index):
       1. Compute the Jacobian matrix \( \mathbf{J}(\mathbf{p}_s^{(k-1)}) \) of the bearing angle measurements with respect to the source position at the current estimate \( \mathbf{p}_s^{(k-1)} \) .
       2. Solve the linear least squares problem in the normal equation form:
           \[ \mathbf{J}(\mathbf{p}_s^{(k-1)})^T \mathbf{J}(\mathbf{p}_s^{(k-1)}) \Delta \mathbf{p}_s = \mathbf{J}(\mathbf{p}_s^{(