2024-05-07 00:15:38.220721

### System Model

#### Problem Type:
The problem at hand is a direction-of-arrival (DOA) estimation for signals impinging on a uniform linear array (ULA) of sensors. This falls within the domain of array signal processing and specifically deals with the localization of signal sources in spatial dimensions.

#### Problem Description:
The challenge involves estimating the angle \( \var{Theta} \) of a signal source that is continuously emitting signals. The ULA consists of \( \var{N} \) array elements with a spacing of half a wavelength. The signal is sampled \( \var{K} \) times, providing segmental information that is used for estimation. The goal is to quickly and accurately estimate the angle \( \var{Theta} \) using the sampled data.

#### System Model Parameters:
- \( N \): Number of array elements in the ULA.
- \( d \): Spacing between array elements, equal to \( \frac{\lambda}{2} \), where \( \lambda \) is the wavelength of the signal.
- \( \var{Theta} \): Angle of the signal source relative to the array.
- \( K \): Number of sampled signals encapsulating segmental information.
- \( x_m(t) \): Signal received at the \( m \)-th array element at time \( t \).
- \( s_k(t) \): Complex envelope of the \( k \)-th signal.
- \( \alpha_k \): Amplitude fading factor of the \( k \)-th signal.
- \( \phi_k \): Phase difference of the \( k \)-th signal relative to the reference sensor.

#### System Model Formulations:
The signal at the \( m \)-th sensor can be represented as:
\[ x_m(t) = \sum_{k=1}^{K} s_k(t) \alpha_k e^{j\frac{2\pi}{\lambda}m d \sin(\var{Theta}) + j\phi_k} + n_m(t) \]
where \( n_m(t) \) is the additive white noise at the \( m \)-th sensor.

The array output vector \( \mathbf{x}(t) \) and the signal vector \( \mathbf{s}(t) \) are given by:
\[ \mathbf{x}(t) = \mathbf{A}(\var{Theta})\mathbf{s}(t) + \mathbf{n}(t) \]
\[ \mathbf{A}(\var{Theta}) = [\mathbf{a}(\var{Theta}_1), \mathbf{a}(\var{Theta}_2), \ldots, \mathbf{a}(\var{Theta}_K)] \]
where \( \mathbf{a}(\var{Theta}_k) \) is the steering vector for the \( k \)-th signal.

### Optimization Formulation

#### Optimization Type:
The optimization problem is of the subspace-based DOA estimation variety, specifically utilizing an ESPRIT-like algorithm for coherent signal sources.

#### Optimization Parameters:
- \( \mathbf{R} \): Covariance matrix of the array output.
- \( \mathbf{T} \): Toeplitz matrix reconstructed from \( \mathbf{R} \).
- \( \mathbf{U}_s \): Signal subspace eigenvectors of \( \mathbf{T} \).
- \( \mathbf{U}_n \): Noise subspace eigenvectors of \( \mathbf{T} \).

#### Optimization Variables:
The decision variables are the DOAs \( \var{Theta}_1, \var{Theta}_2, \ldots, \var{Theta}_K \) of the signal sources.

#### Objective:
The objective is to estimate the DOAs \( \var{Theta}_1, \var{Theta}_2, \ldots, \var{Theta}_K \) from the signal subspace eigenvectors \( \mathbf{U}_s \) with high accuracy and efficiency.

#### Constraints:
The DOAs must be within the physical range of the ULA's orientation and the propagation environment. Additionally, the optimization should consider the coherence of the signals and the rank of the Toeplitz matrix.

### Optimization Algorithm

#### Algorithm Type:
The algorithm type selected is the Improved ESPRIT algorithm, which is well-suited for estimating DOAs in the presence of coherent signals without the need for peak searching.

#### Algorithm Parameters:
- \( \mathbf{U}_1 \): Submatrix of \( \mathbf{U}_s \) formed by the first \( (M-1) \) rows.
- \( \mathbf{U}_2 \): Submatrix of \( \mathbf{U}_s \) formed