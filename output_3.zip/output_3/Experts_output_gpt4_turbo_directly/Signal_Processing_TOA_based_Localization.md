2024-05-02 10:43:24.214204

### System Model

- **Problem Type:** Signal Source Localization via Time of Arrival (TOA) measurements.
- **Problem Description:** The challenge involves determining the position of a signal source based on the TOA measurements collected by multiple sensors distributed at known positions. Each sensor records the time at which a signal, propagated from the source, reaches it. The differences in these times are due to the varied distances from the source to each sensor.
- **System Model Parameters:** 
  - $M$: Number of sensors.
  - $(x_i, y_i)$: The known coordinates of sensor $i$.
  - $t_i$: TOA measurement at sensor $i$.
  - $(x, y)$: Coordinates of the signal source, which are to be estimated.
  - $c$: Speed of the signal propagation, assumed constant.
- **System Model Formulations:** 
  - The distance $d_i$ from the source to sensor $i$ is given by
    $$
    d_i = \sqrt{(x - x_i)^2 + (y - y_i)^2}
    $$
  - The TOA $t_i$ relates to the distance $d_i$ by 
    $$
    d_i = c \cdot t_i
    $$
  - Combining these, we get
    $$
    t_i = \frac{1}{c} \sqrt{(x - x_i)^2 + (y - y_i)^2}
    $$
  - The objective is to solve for $(x, y)$ such that these equations hold for all sensors.

### Optimization Formulation

- **Optimization Type:** Non-linear least squares optimization.
- **Optimization Parameters:** 
  - $c$: Known speed of signal propagation.
- **Optimization Variables:** 
  - $(x, y)$: The coordinates of the signal source to be estimated.
- **Objective:** 
  - Minimize the sum of squared differences between the measured TOAs and the calculated TOAs based on $(x, y)$:
    $$
    \text{Minimize} \quad f(x, y) = \sum_{i=1}^M \left( t_i - \frac{1}{c} \sqrt{(x - x_i)^2 + (y - y_i)^2} \right)^2
    $$
- **Constraints:** 
  - No specific constraints beyond the necessity for $(x, y)$ to provide non-negative valid real numbers under the square root operations.

### Optimization Algorithm

- **Algorithm Type:** Gradient Descent or any suitable iterative numerical method.
- **Algorithm Parameters:** 
  - Learning rate $\alpha$.
  - Maximum number of iterations.
  - Convergence threshold $\epsilon$.
- **Algorithm Steps:**
  - **Initialization**: Start with an initial guess $(x^{(0)}, y^{(0)})$.
  - **Iterative Update**: Update the position estimate at each iteration $k$ as follows:
    $$
    \begin{align*}
    x^{(k+1)} &:= x^{(k)} - \alpha \frac{\partial f}{\partial x}\bigg|_{x=x^{(k)}, y=y^{(k)}} \\
    y^{(k+1)} &:= y^{(k)} - \alpha \frac{\partial f}{\partial y}\bigg|_{x=x^{(k)}, y=y^{(k)}}
    \end{align*}
    $$
  - **Termination Criteria**: Stop if the change in the function value is below $\epsilon$ or the maximum number of iterations is reached.
  - **Output**: The coordinates $(x, y)$ that minimize the objective function.

This structured framework provides a clear pathway to localizing a signal source using TOA measurements from multiple sensors, leveraging mathematical formulations and optimization techniques suitable for solving non-linear systems. This approach allows for practical implementation in real-world signal processing scenarios.