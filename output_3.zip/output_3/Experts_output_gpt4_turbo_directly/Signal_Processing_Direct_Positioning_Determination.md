2024-05-02 10:43:24.214204

### System Model

- **Problem Type:** Source Localization in Sensor Networks.
- **Problem Description:** The problem involves localizing a signal source in a two-dimensional space using data collected by a network of sensors. These sensors detect the signal emitted by the source, and by analyzing the time difference or strength of the received signal at different locations, the position of the signal source can be estimated. 
- **System Model Parameters:**
  - $M$: the number of sensors.
  - $(x_i, y_i), i=1,2,...,M$: the known positions of the sensors in a 2D plane.
  - $(x, y)$: unknown position of the signal source.
  - $d_i$: the distance from the signal source to the $i^{th}$ sensor.
  - $s(t)$: the signal emitted by the source.
  - $r_i(t)$: the signal received by the $i^{th}$ sensor, which includes the effect of signal travel time and possible noise.
- **System Model Formulations:**
  - The signal received by the $i^{th}$ sensor can be modelled as:
    $$ r_i(t) = s(t - \tau_i) + n_i(t) $$
  where $\tau_i = \frac{d_i}{c}$ is the time delay for the signal to travel the distance $d_i$ at speed $c$, and $n_i(t)$ represents noise.
  - The distance $d_i$ from the sensor to the source is given by:
    $$ d_i = \sqrt{(x-x_i)^2 + (y-y_i)^2} $$
  - The estimation of $\tau_i$ will be used for locating the source, based on the minimization of discrepancies between the predicted and actual time delays.

### Optimization Formulation

- **Optimization Type:** Nonlinear Least Squares Optimization.
- **Optimization Parameters:**
  - Distances $d_i$ to each sensor.
  - Time delays $\tau_i$.
  - Speed of signal transmission $c$.
- **Optimization Variables:**
  - Source location $(x, y)$.
- **Objective:**
  - Minimize the objective function:
    $$ \min_{x, y} \sum_{i=1}^M \left[ \left( \frac{\sqrt{(x-x_i)^2 + (y-y_i)^2}}{c} - \hat{\tau}_i \right)^2 \right] $$
  where $\hat{\tau}_i$ is the estimated time delay derived from the received signals.
- **Constraints:**
  - Signal propagation speed $c$ is constant and known.
  - The sensors' positions $(x_i, y_i)$ are fixed and known.

### Optimization Algorithm

- **Algorithm Type:** Gradient Descent.
- **Algorithm Parameters:**
  - Learning rate $\alpha$.
  - Convergence threshold $\epsilon$.
  - Maximum number of iterations $N_{\text{max}}$.
- **Algorithm Steps:**
  1. **Initialization:** Start with an initial guess $(x^{(0)}, y^{(0)})$.
  2. **Iterative Update:** For each iteration $k$:
     - Compute the gradient of the objective function:
       $$ \nabla J = \left[ \frac{\partial J}{\partial x}, \frac{\partial J}{\partial y} \right] $$
     - Update the position:
       $$ x^{(k+1)} = x^{(k)} - \alpha \frac{\partial J}{\partial x} $$
       $$ y^{(k+1)} = y^{(k)} - \alpha \frac{\partial J}{\partial y} $$
     - Check for convergence:
       $$ \text{if } \| \nabla J \| < \epsilon \text{ or } k > N_{\text{max}}, \text{ stop the iteration.} $$
  3. **Termination:** Output the final estimated source location $(x^{(k)}, y^{(k)})$ as the solution.

This structured methodology ensures a rigorous and systematic approach to solving the signal source localization problem using sensor networks.