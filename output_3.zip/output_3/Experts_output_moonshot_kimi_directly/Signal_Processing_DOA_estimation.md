2024-05-02 12:44:55.059539

### System Model

#### Problem Type:
The problem at hand is a direction-of-arrival (DOA) estimation problem within the domain of array signal processing. Specifically, it involves estimating the angle \( \Theta \) of a signal source using a uniform linear array (ULA) of sensors.

#### Problem Description:
In this scenario, a ULA consisting of \( N \) elements is used to detect a signal emitted from a source at an unknown angle \( \Theta \). The array elements are spaced at half a wavelength, which is a specific configuration that can simplify the signal model. The signal is sampled \( K \) times, providing a snapshot of the signal at each element. The goal is to estimate the angle \( \Theta \) from these snapshots.

#### System Model Parameters:
- \( N \): Number of array elements
- \( d \): Spacing between array elements (given as half a wavelength, \( d = \frac{\lambda}{2} \), where \( \lambda \) is the wavelength of the signal)
- \( \Theta \): Angle of the signal source relative to the array
- \( K \): Number of sampled signals
- \( \lambda \): Wavelength of the emitted signal

#### System Model Formulations:
The signal received at the \( n \)-th element of the array can be modeled as:
\[ s_n(t) = s(t - n \cdot d \cdot \cos(\Theta)) \]
where \( s(t) \) is the emitted signal and \( t \) is time.

The array manifold vector \( \mathbf{a}(\Theta) \) for a ULA is given by:
\[ \mathbf{a}(\Theta) = [1, e^{-j \frac{2\pi}{\lambda} d \cos(\Theta)}, \ldots, e^{-j \frac{2\pi}{\lambda} (N-1) d \cos(\Theta)}]^T \]

The received signal vector \( \mathbf{s}(t) \) at all \( N \) elements can be expressed as:
\[ \mathbf{s}(t) = \mathbf{a}(\Theta) s(t) + \mathbf{n}(t) \]
where \( \mathbf{n}(t) \) is the noise vector.

For \( K \) snapshots, we have the matrix equation:
\[ \mathbf{S} = \mathbf{A}\mathbf{s} + \mathbf{N} \]
where \( \mathbf{S} \) is the \( N \times K \) matrix of received signals, \( \mathbf{A} \) is the \( N \times 1 \) array manifold vector, \( \mathbf{s} \) is the \( 1 \times K \) vector of the source signal, and \( \mathbf{N} \) is the \( N \times K \) noise matrix.

### Optimization Formulation

#### Optimization Type:
The optimization problem is a parameter estimation problem, specifically, an angle estimation problem. We will use a least squares approach to estimate the angle \( \Theta \) that minimizes the error between the measured signal snapshots and the model predictions.

#### Optimization Parameters:
- \( \mathbf{S} \): The \( N \times K \) matrix of received signal snapshots.
- \( \mathbf{A}(\Theta) \): The array manifold vector as a function of the angle \( \Theta \).

#### Optimization Variables:
- \( \Theta \): The angle of the signal source to be estimated.

#### Objective:
The objective is to minimize the least squares error between the measured signals and the signals predicted by the model:
\[ \min_{\Theta} \lVert \mathbf{S} - \mathbf{A}(\Theta)\mathbf{s} \rVert^2_F \]
where \( \lVert \cdot \rVert_F \) is the Frobenius norm.

#### Constraints:
- \( \Theta \) must be within the range of angles detectable by the array, typically \( [0, \pi] \) or \( [-\pi/2, \pi/2] \) in radians.

### Optimization Algorithm

#### Algorithm Type:
The algorithm chosen is the least squares estimation method, which is a standard approach for solving parameter estimation problems in signal processing. It is computationally efficient and well-suited for the problem's linear nature.

#### Algorithm Parameters:
- Tolerance for convergence: A small positive value, e.g., \( 10^{-5} \).
- Maximum number of iterations: A predefined limit to prevent infinite loops, e.g., 1000.

#### Algorithm Steps:
1. **Initialization**: Set an initial estimate