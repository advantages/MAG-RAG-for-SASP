2024-06-05 10:38:54.117475

### System Model
- **Problem Type:** Direction-of-Arrival (DOA) Estimation using a Uniform Linear Array (ULA)
- **Problem Description:** The fundamental task in this scenario is to determine the angle from which a signal is arriving at a sensor array. A single narrowband source continuously emits a signal impinging on a uniform linear array of sensors from an angle \(\theta\). The array has \(N\) elements spaced \(d = \frac{\lambda}{2}\) apart, where \(\lambda\) is the wavelength of the signal.
- **System
Model Parameters:**
  - \(N\): Number of sensors in the ULA
  - \(d = \frac{\lambda}{2}\): Inter-sensor spacing, half of the wavelength
  - \(\theta\): Unknown DOA of the signal source
  - \(K\): Number of sampled signals
  - \(s(t)\): Signal emitted by the source
  - \(n_m(t)\): Additive white Gaussian noise at the \(m\)-th sensor
  - \(\lambda\): Wavelength of the signal
- **System Model Formulations:** 
  - The received signal at the \(m\)-th sensor can be modeled as:
    \[
    x_m(t) = s(t) e^{j \pi m \sin(\theta)} + n_m(t)
    \]
  - The entire sensor array's output can be expressed as:
    \[
    \mathbf{x}(t) = \mathbf{a}(\theta)s(t) + \mathbf{n}(t)
    \]
  - Where \(\mathbf{a}(\theta)\) is the steering vector:
    \[
    \mathbf{a}(\theta) = [1, e^{j \pi \sin(\theta)}, \ldots, e^{j \pi (N-1) \sin(\theta)}]^T
    \]

### Optimization Formulation
- **Optimization Type:** Subspace-based method (ESPRIT algorithm)
- **Optimization Parameters:**
  - \(\mathbf{R}\): Sample covariance matrix of the array output, \(\mathbf{R} = \frac{1}{K} \sum_{t=1}^K \mathbf{x}(t) \mathbf{x}^H(t)\)
  - \(\sigma_n^2\): Noise power
- **Optimization Variables:** \(\theta\), the angle of arrival
- **Objective:** Maximize the signal subspace correlation to estimate \(\theta\)
- **Constraints:** \(\theta\) must be real and physically feasible (typically \(\theta \in [-\frac{\pi}{2}, \frac{\pi}{2}]\))

### Optimization Algorithm
- **Algorithm Type:** ESPRIT (Estimation of Signal Parameters via Rotational Invariance Techniques)
- **Algorithm Parameters:**
  - Decomposition of covariance matrix \(\mathbf{R}\) to extract signal and noise subspaces
- **Algorithm Steps:**
  1. Compute the sample covariance matrix \(\mathbf{R}\) using the collected samples.
  2. Perform eigenvalue decomposition on \(\mathbf{R}\) to obtain eigenvectors \(\mathbf{U}_s\) (signal subspace) and \(\mathbf{U}_n\) (noise subspace).
  3. Select the two largest eigenvectors to form \(\mathbf{U}_s\).
  4. Partition \(\mathbf{U}_s\) into two submatrices \(\mathbf{U}_1\) and \(\mathbf{U}_2\) corresponding to the first \(N-1\) and last \(N-1\) sensors respectively.
  5. Solve the following least squares problem to get the matrix \(\Psi\):
     \[
     \boldsymbol{\Psi} = (\mathbf{U}_1^H\mathbf{U}_1)^{-1}\mathbf{U}_1^H\mathbf{U}_2
     \]
  6. Compute the eigenvalues of \(\Psi\), from which the DOAs can be estimated:
     \[
     \theta = \sin^{-1}\left(\frac{\angle \lambda}{\pi}\right)
     \]
  7. Output \(\theta\) as the estimated DOA.

The success of this method depends critically on the number of samples \(K\) and the signal-to-noise ratio (SNR), both of which influence the accuracy of the covariance matrix estimation and subsequent DOA estimation. For simulation, the parameter \(K\) can be varied to assess its impact on the accuracy of the estimated DOA. The method assumes a single source but can be extended to multiple sources with modifications, such
as ensuring orthogonality between different signal subspace estimations.