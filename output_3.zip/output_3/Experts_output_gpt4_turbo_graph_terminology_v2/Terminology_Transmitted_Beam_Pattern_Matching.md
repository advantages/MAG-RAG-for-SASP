2024-06-05 10:38:54.117475

./output_202405/Extractor_output/sonnet_final/all_output_list_V2/extractor_Constant_Modulus_MIMO_Radar_Waveform_Design_With_Minimum_Peak_Sidelobe_Transmit_Beampattern.md      0.5548996542645854
./output_202405/Extractor_output/sonnet_final/all_output_list_V2/extractor_Constant_Modulus_Waveform_Design_for_MIMO_Radar_Transmit_Beampattern.md      0.4770826953493873
./output_202405/Extractor_output/sonnet_final/all_output_list_V2/extractor_MIMO_Radar_Waveform_Design_for_Multipath_Exploitation.md      0.4557157685345306
