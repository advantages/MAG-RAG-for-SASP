2024-06-05 10:38:54.117475

### System Model

- **Problem Type:** Time of Arrival (TOA) Based Source Localization
- **Problem Description:** The task is to localize a signal source using the time of arrival measurements recorded by multiple sensors positioned at known coordinates. Each sensor detects the signal emitted from an unknown source position and records the time at which this signal is received. The objective is to use these TOA measurements, which are influenced by the distances between the source and sensors, to accurately determine the source's location.
- **System Model Parameters:** 
  - \( p \in \mathbb{R}^2 \): Location of the source.
  - \( q = [q_1, q_2, \dots, q_M] \in \mathbb{R}^{2 \times M} \): Locations of \( M \) sensors.
  - \( t_0 \): Time at which the source emits the signal.
  - \( \nu \): Propagation speed of the signal.
  - \( d_i(p, q) = \|p - q_i\| \): Euclidean distance between the source and the \( i \)-th sensor.
  - \( \epsilon_i \): Measurement noise at the \( i \)-th sensor, modeled as zero-mean Gaussian noise with variance \( \sigma^2 \).
  - \( \hat{t}_i = t_0 + \frac{d_i(p, q)}{\nu} + \epsilon_i \): Measured TOA at the \( i \)-th sensor.
- **System Model Formulations:** 
  - Known sensor coordinates and TOA data allow the formulation of a non-linear set of equations pertaining to the unknown source location and event time:
  $$
  \|\hat{t}_i - t_0\| = \frac{\|p - q_i\|}{\nu} + \epsilon_i, \quad i = 1, 2, \ldots, M
  $$
  This formulation treats the speed of signal propagation as a known constant, whereby the distance is derived from the travel time of the signal minus the noise factor.

### Optimization Formulation

- **Optimization Type:** Non-linear Least Squares Problem
- **Optimization Parameters:** 
  - Propagation speed \( \nu \)
  - Sensor coordinates \( q_i \)
  - Measurement noise variance \( \sigma^2 \)
- **Optimization Variables:** 
  - Source location \( p \)
  - Event time \( t_0 \)
- **Objective:** 
  - Minimize the residual sum of squares between the observed TOAs and the model-predicted TOAs:
  $$
  \text{minimize} \sum_{i=1}^M \left( \hat{t}_i - t_0 - \frac{\|p - q_i\|}{\nu} \right)^2
  $$
- **Constraints:** 
  - No explicit constraints other than the non-negativity of the propagation time, which is inherently satisfied by the physical nature of the problem.

### Optimization Algorithm

- **Algorithm Type:** Levenberg-Marquardt Algorithm (a method for non-linear least squares problems)
- **Algorithm Parameters:** 
  - Convergence tolerance
  - Maximum number of iterations
  - Initial guess for \( p \) and \( t_0 \)
- **Algorithm Steps:** 
  1. **Initialize** parameters with initial guesses for \( p \) and \( t_0 \).
  2. **Iterate** until convergence criteria are met:
      - Compute the Jacobian matrix of partial derivatives with respect to \( p \) and \( t_0 \) for the objective function.
      - Update \( p \) and \( t_0 \) by solving the approximate linear system formed at each iteration.
  3. **Check** for convergence: If the change in the objective function or parameter values falls below a specified tolerance, terminate the algorithm.
  4. **Output** the estimated source coordinates \( p \) and emission time \( t_0 \).

This structured process ensures the methodical solution to the TOA-based source localization problem, leveraging optimization and numerical methods suited to the inherent non-linear nature of the problem domain.