2024-06-05 10:38:54.117475

## System Model

### Problem Type
The sensor array signal processing issue at hand is Direction-of-Arrival (DOA) estimation using a distributed antenna array tasked with detecting primary signals from multiple sources. This categorization falls within the domain of sensor array signal processing problems.

### Problem Description
In this scenario, a network of distributed antennas (sensor array) is employed to detect the presence of primary signals transmitted by an emitter located anywhere in space. These signals are subject to transmission characteristics such as bandwidth limitations and QPSK modulation. The primary focus is to use this distributed antenna setup to effectively and accurately determine the direction(s) from which the signals originate, referred to as the DOA estimation.

### System Model Parameters
- **\( p \)**: Number of distributed antennas.
- **\( \theta_i \)**: Direction of arrival of the \( i \)-th signal.
- **\( s(t) \)**: Signal emitted by the source at time \( t \), expected to be a QPSK modulated signal.
- **\( n(t) \)**: Additive white Gaussian noise at the antennas.
- **\( d \)**: Distance between consecutive antennas, typically half the wavelength \( \lambda/2 \).
- **\( \lambda \)**: Wavelength of the carrier frequency.

### System Model Formulations
The signals received at the antennas can be modeled by the equation:
$$
\mathbf{x}(t) = \mathbf{A}(\theta) \mathbf{s}(t) + \mathbf{n}(t)
$$
where:
- **\( \mathbf{x}(t) \)**: Received signal vector at the antennas.
- **\( \mathbf{A}(\theta) \)**: Array steering matrix, depending on DOA \( \theta \) and the antenna arrangement.
- **\( \mathbf{s}(t) \)**: Signal vector from the emitter.
- **\( \mathbf{n}(t) \)**: Noise vector at the antennas.

Array steering matrix \(\mathbf{A}(\theta)\) is defined as:
$$
\mathbf{A}(\theta) = \begin{bmatrix}
e^{-j\frac{2\pi}{\lambda}0d\sin(\theta_1)} & ... & e^{-j\frac{2\pi}{\lambda}0d\sin(\theta_p)} \\
\vdots & \ddots & \vdots \\
e^{-j\frac{2\pi}{\lambda}(p-1)d\sin(\theta_1)} & ... & e^{-j\frac{2\pi}{\lambda}(p-1)d\sin(\theta_p)}
\end{bmatrix}
$$

## Optimization Formulation

### Optimization Type
This is a multi-variable optimization type, specifically focusing on subspace-based method for DOA estimation. The chosen methodology is the estimation of angles based on the signal subspace derived from the received signal covariances.

### Optimization Parameters
- Parameters derived are the number of antennas \( p \) and the sensor array geometry defined by \( d \) and \( \lambda \).
- Noise characteristics included in the optimization as it affects covariance estimation.

### Optimization Variables
- The primary optimization variables are the DOA estimates \( \theta \) for the detected signals.

### Objective
The objective is to accurately estimate the DOA \( \theta \) that maximizes the likelihood or minimizes the error between the estimated signal directions and the actual signal directions received by the array.

### Constraints
- Geometric constraints of the sensor array.
- Physical constraints of the signal such as bandwidth and modulation scheme.

## Optimization Algorithm

### Algorithm Type
The chosen optimization algorithm is the ESPRIT algorithm which is suitable for estimating the parameters of a wavefield received by an array of sensors.

### Algorithm Parameters 
- Number of expected sources \( q \).
- Number of sensors \( p \).
- Spatial smoothing to ensure uncorrelated signal sources in covariance estimation if sources are coherent.

### Algorithm Steps
1. **Signal Covariance Matrix Calculation**: Compute the sample covariance matrix of the received signal.
2. **Eigenvalue Decomposition**: Perform eigenvalue decomposition on the covariance matrix to extract signal and noise subspaces.
3. **Estimate DOA**: Use the ESPRIT algorithm to estimate the directions \( \theta \) from the eigenvectors corresponding to the signal subspace.
4. **Refinement and Thresholding**: Refine estimates using techniques such as MUSIC (Multiple Signal Classification) for peak searching in the spectral domain to resolve closely spaced sources.
5. **Termination**: Repeat the estimation process with varying model parameters (like number of sources) until the consistency criterion on the DOA estimates is met.

By adhering to these stages, the set objective of accurate DOA estimation can be effectively achieved, leading to efficient utilization of the sensor network for primary signal detection.