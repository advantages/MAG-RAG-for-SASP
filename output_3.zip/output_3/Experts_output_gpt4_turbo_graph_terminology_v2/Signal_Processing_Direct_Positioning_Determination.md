2024-06-05 10:38:54.117475

### System Model

#### Problem Type:
This pertains to a two-dimensional static signal source localization problem using Time-of-Arrival (TOA) measurements from multiple sensors.

#### Problem Description:
A signal source emits signals continuously from an unknown position \((x, y)\) in a 2D space. Multiple sensors, located at known positions, receive these signals. The duration it takes for the signal to travel from the source to each sensor (TOA) is measured. The objective is to estimate the position of the signal source based on these TOA measurements.

#### System Model Parameters:
- \( (x, y) \): The unknown position of the signal source.
- \( r_i = [x_i, y_i]^T \): Known position of the \(i^{th}\) sensor.
- \( c \): Known signal propagation speed.
- \( t_i \): True TOA of the signal from the source to the \(i^{th}\) sensor.
- \( \tilde{t}_i \): Observed (noisy) TOA measurement at the \(i^{th}\) sensor.
- \( \eta_i \sim \mathcal{N}(0, \sigma^2_i) \): Measurement noise, assumed to be Gaussian.

#### System Model Formulations:
For each sensor \(i\), the true TOA \(t_i\) is given by the Euclidean distance between the source and sensor divided by the speed of signal propagation:
$$ t_i = \frac{\| [x, y]^T - r_i \|}{c} $$
The observed TOA \(\tilde{t}_i\) is modeled as:
$$ \tilde{t}_i = t_i + \eta_i $$

### Optimization Formulation

#### Optimization Type:
This is a parameter estimation problem, specifically a nonlinear least squares optimization, given the nonlinear dependency of TOA on the source position.

#### Optimization Parameters:
- \( c \): Signal propagation speed.
- \( \sigma^2_i \): Variance of the noise in the TOA measurement at each sensor.

#### Optimization Variables:
- \( x, y \): Coordinates of the signal source which are to be estimated.

#### Objective:
Minimize the sum of the squared differences between the observed and calculated TOAs, effectively minimizing the impact of measurement noise:
$$ \min_{x, y} \sum_{i=1}^M \left(\tilde{t}_i - \frac{\| [x, y]^T - r_i \|}{c}\right)^2 $$

#### Constraints:
There are no explicit constraints beyond those implicit in the measurable ranges of TOA and the geometric configuration of the sensors.

### Optimization Algorithm

#### Algorithm Type:
A gradient descent based iterative algorithm, such as the Gauss-Newton algorithm for nonlinear least squares problems, is appropriate here. This method is well-suited due to its efficiency in solving problems where the objective functions are sums of squares.

#### Algorithm Parameters:
- Convergence criterion: Typically, a small threshold value for the gradient or the change in error between iterations.
- Maximum number of iterations: To prevent endless looping in cases where convergence is slow.

#### Algorithm Steps:
1. Initialize \(x^{(0)}\) and \(y^{(0)}\) (possibly using a centroid of sensor locations as a heuristic).
2. Compute the objective function \(F(x, y) = \sum_{i=1}^M \left(\tilde{t}_i - \frac{\| [x, y]^T - r_i \|}{c}\right)^2\).
3. Calculate the gradient \(\nabla F(x, y)\) and update the position:
   $$ x^{(k+1)} = x^{(k)} - \alpha \frac{\partial F}{\partial x}, \quad y^{(k+1)} = y^{(k)} - \alpha \frac{\partial F}{\partial y} $$
   where \(\alpha\) is the step size.
4. Check the convergence criterion. If not met, go to step 2.
5. Output the final estimates \(x^{(final)}\), \(y^{(final)}\) as the coordinates of the source.

This structured approach will efficiently address the signal source localization problem using TOA measurements from multiple sensors in a 2D space.