2024-06-05 10:38:54.117475

### System Model

- **Problem Type:** Angle-of-Arrival (AOA) Based Source Localization
- **Problem Description:** The challenge involves estimating the position of a source by using the angle measurements from multiple sensors. Each sensor can measure the direction from which a signal is received. The goal is to accurately determine the source’s location, even when the angle measurements are perturbed by noise.
- **System Model Parameters:** 
  - $M$: Number of sensors.
  - $(x_i, y_i), i = 1, 2, ..., M$: Positions of the sensors.
  - $\theta_i$: True bearing angle from the $i^\text{th}$ sensor to the signal source.
  - $\hat{\theta}_i$: Measured bearing angle by the $i^\text{th}$ sensor, potentially affected by Gaussian noise.
  - $(x_s, y_s)$: Unknown coordinates of the source.
  - $\epsilon_i \sim \mathcal{N}(0, \sigma_i^2)$: Measurement noise at the $i^\text{th}$ sensor.
- **System Model Formulations:** 
  - True AOA model: $$\theta_i = \arctan\frac{y_s - y_i}{x_s - x_i}$$
  - Observed AOA model with noise: $$\hat{\theta}_i = \theta_i + \epsilon_i$$ 
  - Noise vector: $$\boldsymbol{\epsilon} = [\epsilon_1, \epsilon_2, \ldots, \epsilon_M]^T$$

### Optimization Formulation

- **Optimization Type:** Nonlinear Least Squares Estimation
- **Optimization Parameters:** 
  - $\boldsymbol{\theta} = [\theta_1, \theta_2, \ldots, \theta_M]^T$: vector of true AOAs.
  - $\hat{\boldsymbol{\theta}} = [\hat{\theta}_1, \hat{\theta}_2, \ldots, \hat{\theta}_M]^T$: vector of measured AOAs.
  - $\boldsymbol{\sigma}^2 = [\sigma_1^2, \sigma_2^2, \ldots, \sigma_M^2]$: vector of noise variances.
- **Optimization Variables:** 
  - $(x_s, y_s)$: Source coordinates, which are to be estimated.
- **Objective:** Minimize the sum of squared differences between the observed and calculated bearing angles, weighted by the inverse of the noise variance:
  $$
  \min_{x_s, y_s} \sum_{i=1}^M \frac{1}{\sigma_i^2} \left(\hat{\theta}_i - \arctan\frac{y_s - y_i}{x_s - x_i}\right)^2
  $$
- **Constraints:** None explicitly defined; implicit constraints may include the physical boundaries or operational ranges within which sensors and sources operate.

### Optimization Algorithm

- **Algorithm Type:** Gradient Descent
- **Algorithm Parameters:** 
  - Learning rate $\eta$: a crucial parameter to balance convergence speed and stability.
  - Convergence threshold $\epsilon$: determines when to stop the algorithm if the improvement in objective function is marginal.
  - Maximum iterations $N$: protects against infinite looping in non-convergent cases.
- **Algorithm Steps:**
  1. **Initialize** $(x_s, y_s)$, perhaps based on an average position of sensors or a random guess.
  2. **Repeat** for $k = 1, 2, \ldots, N$:
     - Evaluate the gradient of the objective function w.r.t. $(x_s, y_s)$.
     - **Update source position**:
       $$
       (x_s^{(k+1)}, y_s^{(k+1)}) = (x_s^{(k)}, y_s^{(k)}) - \eta \nabla J(x_s^{(k)}, y_s^{(k)}),
       $$
       where $J$ is the objective function.
     - **Check for convergence**:
       If $|J(x_s^{(k+1)}, y_s^{(k+1)}) - J(x_s^{(k)}, y_s^{(k)})| < \epsilon$, break the loop.
  3. **Output** the estimated position $(x_s, y_s)$ as the source location.

This structured approach treats the noisy AOA measurements through a nonlinear optimization framework, utilizing gradient descent to iteratively refine the source position estimate until the change in the loss function is sufficiently small.