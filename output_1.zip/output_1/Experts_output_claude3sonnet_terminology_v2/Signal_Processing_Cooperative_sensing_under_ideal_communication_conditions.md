2024-06-05 09:47:49.016126

### System Model

- **Problem Type:** Distributed Spectrum Sensing and Primary Signal Detection in Cognitive Radio Networks

- **Problem Description:** The problem involves a sensor network comprising $p$ distributed antennas tasked with detecting the presence of primary signals transmitted by a signal emitter located within the coverage area. The transmitted primary signal has limited bandwidth, such as a QPSK modulated signal, carrying segmental information. The objective is to develop an efficient strategy that leverages the distributed antenna array to maximize the utility of the antennas for sensing and detecting these primary signals.

- **System Model Parameters:**
  - $p$: Number of distributed antennas in the sensor network
  - $\mathbf{r}_i$: Position vector of the $i$-th antenna, $i = 1, 2, \dots, p$
  - $\mathbf{r}_s$: Position vector of the primary signal emitter
  - $s(t)$: Transmitted primary signal waveform
  - $f_c$: Carrier frequency of the primary signal
  - $B$: Bandwidth of the primary signal
  - $\sigma_n^2$: Noise variance at the antennas

- **System Model Formulations:**
  - Received signal at the $i$-th antenna:
    $$
    x_i(t) = \alpha_i s(t - \tau_i) e^{j2\pi f_c (t - \tau_i)} + n_i(t)
    $$
    where $\alpha_i$ is the complex channel gain, $\tau_i = \|\mathbf{r}_s - \mathbf{r}_i\|/c$ is the propagation delay, $c$ is the speed of light, and $n_i(t)$ is the additive white Gaussian noise (AWGN) at the $i$-th antenna.

  - Hypothesis testing for primary signal detection:
    $$
    \begin{aligned}
    \mathcal{H}_0: & \quad x_i(t) = n_i(t) \quad &\text{(Primary signal absent)} \\
    \mathcal{H}_1: & \quad x_i(t) = \alpha_i s(t - \tau_i) e^{j2\pi f_c (t - \tau_i)} + n_i(t) \quad &\text{(Primary signal present)}
    \end{aligned}
    $$

  - Cooperative spectrum sensing: The distributed antennas can exchange their local sensing information to make a global decision on the presence or absence of the primary signal.

### Optimization Formulation

- **Optimization Type:** Convex optimization, specifically semidefinite programming (SDP)

- **Optimization Parameters:**
  - $\gamma$: Target probability of detection
  - $\beta$: Maximum tolerable probability of false alarm
  - $\sigma_n^2$: Noise variance at the antennas
  - $\mathbf{R}_s$: Spatial correlation matrix of the primary signal

- **Optimization Variables:**
  - $\mathbf{w}$: Weight vector for the linear combination of antenna observations

- **Objective:** Minimize the total transmitted power of the distributed antennas while satisfying the target detection performance:
  $$
  \begin{aligned}
  \min_{\mathbf{w}} \quad & \|\mathbf{w}\|_2^2 \\
  \end{aligned}
  $$

- **Constraints:**
  - Probability of detection constraint:
    $$
    \mathbf{w}^H \mathbf{R}_s \mathbf{w} \geq \gamma
    $$
  - Probability of false alarm constraint:
    $$
    \mathbf{w}^H \mathbf{w} \leq \beta
    $$

### Optimization Algorithm

- **Algorithm Type:** Semidefinite programming (SDP) with interior-point method

- **Algorithm Parameters:**
  - $\epsilon$: Convergence tolerance
  - $\kappa$: Barrier parameter
  - $t_\text{max}$: Maximum number of iterations

- **Algorithm Steps:**
  1. Initialize the weight vector $\mathbf{w}^{(0)}$ and set $t = 0$.
  2. Compute the objective function value $f(\mathbf{w}^{(t)}) = \|\mathbf{w}^{(t)}\|_2^2$.
  3. Compute the barrier function:
    $$
    \phi(\mathbf{w}^{(t)}) = f(\mathbf{w}^{(t)}) - \kappa \left( \log(\gamma - \mathbf{w}^{(t)H} \mathbf{R}_s \mathbf{w}^{(t)}) + \log(\beta - \mathbf{w}^{(t)H} \mathbf{w}^{(t)}) \right)
    $$
  4. Compute the gradient and Hessian of the barrier function:
    $$
    \begin{aligned}
    \nabla \phi(\mathbf{w}^{(t)}) &= 2\mathbf{w}^{(t)} + \kappa \left( \frac{\mathbf{R}_s \mathbf{w}^{(t)}}{\gamma - \mathbf{w}^{(t)H} \mathbf{R}_s \mathbf{w}^{(t)}} + \frac{2\mathbf{w}^{(t)}}{\beta - \mathbf{w}^{(t)H} \mathbf{w}^{(t)}} \right) \\
    \nabla^2 \phi(\mathbf{w}^{(t)}) &= 2\mathbf{I} + \kappa \left( \frac{\mathbf{R}_s}{\gamma - \mathbf{w}^{(t)H} \mathbf{R}_s \mathbf{w}^{(t)}} + \frac{2\mathbf{I}}{\beta - \mathbf{w}^{(t)H} \mathbf{w}^{(t)}} \right)
    \end{aligned}
    $$
  5. Update the weight vector using Newton's method:
    $$
    \mathbf{w}^{(t+1)} = \mathbf{w}^{(t)} - \left( \nabla^2 \phi(\mathbf{w}^{(t)}) \right)^{-1} \nabla \phi(\mathbf{w}^{(t)})
    $$
  6. If $\|\mathbf{w}^{(t+1)} - \mathbf{w}^{(t)}\| < \epsilon$ or $t > t_\text{max}$, terminate the algorithm. Otherwise, set $t = t + 1$ and go to step 2.

The interior-point method iteratively updates the weight vector $\mathbf{w}$ while ensuring that the probability of detection and false alarm constraints are satisfied. The barrier function incorporates the constraints into the objective, and Newton's method is used to find the optimal solution by minimizing the barrier function. The algorithm terminates when the change in the weight vector is smaller than the convergence tolerance or the maximum number of iterations is reached.