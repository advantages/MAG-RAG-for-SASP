2024-06-05 09:47:49.016126

### System Model
- **Problem Type:** This is an angle-of-arrival (AOA) based localization problem where the goal is to estimate the location of a signal source using bearing angle measurements from multiple sensors.

- **Problem Description:** Given a set of $M$ sensors located at known positions $(x_i, y_i)$, where $i = 1, 2, \ldots, M$, each sensor can measure the bearing angle $\theta_i$ of a signal source corrupted by additive Gaussian noise. The objective is to estimate the location $(x_0, y_0)$ of the signal source by combining the noisy bearing angle measurements from all sensors.

- **System Model Parameters:**
  - $M$: Number of sensors
  - $(x_i, y_i)$: Coordinates of the $i$-th sensor, for $i = 1, 2, \ldots, M$
  - $\theta_i$: Measured bearing angle at the $i$-th sensor, for $i = 1, 2, \ldots, M$
  - $(x_0, y_0)$: Unknown location coordinates of the signal source
  - $\sigma_i^2$: Variance of the additive Gaussian noise in the bearing angle measurement at the $i$-th sensor

- **System Model Formulations:**
  - The bearing angle $\theta_i$ measured at the $i$-th sensor is related to the unknown source location $(x_0, y_0)$ as:
    $$\theta_i = \tan^{-1}\left(\frac{y_0 - y_i}{x_0 - x_i}\right) + n_i$$
    where $n_i$ is the additive Gaussian noise with zero mean and variance $\sigma_i^2$.

  - The goal is to estimate $(x_0, y_0)$ by minimizing the weighted squared error between the measured bearing angles $\theta_i$ and the predicted bearing angles based on the estimated source location.

### Optimization Formulation
- **Optimization Type:** This is a non-linear least-squares optimization problem, where the objective is to minimize the sum of squared residuals between the measured and predicted bearing angles, weighted by the inverse of the measurement noise variances.

- **Optimization Parameters:**
  - $M$: Number of sensors
  - $(x_i, y_i)$: Coordinates of the $i$-th sensor, for $i = 1, 2, \ldots, M$
  - $\theta_i$: Measured bearing angle at the $i$-th sensor, for $i = 1, 2, \ldots, M$
  - $\sigma_i^2$: Variance of the additive Gaussian noise in the bearing angle measurement at the $i$-th sensor

- **Optimization Variables:**
  - $(x_0, y_0)$: Unknown location coordinates of the signal source

- **Objective:** The objective is to minimize the weighted sum of squared residuals between the measured bearing angles $\theta_i$ and the predicted bearing angles based on the estimated source location $(x_0, y_0)$:
  $$\min_{x_0, y_0} \sum_{i=1}^M \frac{1}{\sigma_i^2} \left[\theta_i - \tan^{-1}\left(\frac{y_0 - y_i}{x_0 - x_i}\right)\right]^2$$

- **Constraints:**
  - There are no explicit constraints on the optimization variables $(x_0, y_0)$, as the signal source can be located anywhere in the 2D plane.

### Optimization Algorithm
- **Algorithm Type:** Due to the non-linear nature of the objective function, a suitable algorithm for this problem is the Gauss-Newton method, which is an iterative method for solving non-linear least-squares problems.

- **Algorithm Parameters:**
  - $\epsilon$: Convergence threshold for the algorithm
  - $k_{\max}$: Maximum number of iterations

- **Algorithm Steps:**
  1. Initialize the algorithm with an initial guess $(x_0^{(0)}, y_0^{(0)})$ for the source location.
  2. For iteration $k = 0, 1, 2, \ldots, k_{\max}$:
     1. Compute the residual vector $\mathbf{r}^{(k)}$, where the $i$-th element is given by:
        $$r_i^{(k)} = \sqrt{\frac{1}{\sigma_i^2}} \left[\theta_i - \tan^{-1}\left(\frac{y_0^{(k)} - y_i}{x_0^{(k)} - x_i}\right)\right]$$
     2. Compute the Jacobian matrix $\mathbf{J}^{(k)}$, where the $(i, 1)$-th and $(i, 2)$-th elements are given by:
        $$J_{i1}^{(k)} = -\sqrt{\frac{1}{\sigma_i^2}} \frac{y_i - y_0^{(k)}}{(x_0^{(k)} - x_i)^2 + (y_0^{(k)} - y_i)^2}$$
        $$J_{i2}^{(k)} = \sqrt{\frac{1}{\sigma_i^2}} \frac{x_i - x_0^{(k)}}{(x_0^{(k)} - x_i)^2 + (y_0^{(k)} - y_i)^2}$$
     3. Solve the normal equations $\mathbf{J}^{(k)^T}\mathbf{J}^{(k)}\Delta\mathbf{x}^{(k)} = \mathbf{J}^{(k)^T}\mathbf{r}^{(k)}$ for $\Delta\mathbf{x}^{(k)} = [\Delta x_0^{(k)}, \Delta y_0^{(k)}]^T$ using QR decomposition or Cholesky factorization.
     4. Update the source location estimate: $x_0^{(k+1)} = x_0^{(k)} + \Delta x_0^{(k)}$, $y_0^{(k+1)} = y_0^{(k)} + \Delta y_0^{(k)}$.
     5. If $\|\Delta\mathbf{x}^{(k)}\| < \epsilon$, terminate the algorithm and return $(x_0^{(k+1)}, y_0^{(k+1)})$ as the estimated source location.
  3. If the maximum number of iterations $k_{\max}$ is reached without convergence, terminate the algorithm and return the last estimated source location $(x_0^{(k_{\max})}, y_0^{(k_{\max})})$.

This algorithm iteratively updates the source location estimate by minimizing the weighted sum of squared residuals between the measured and predicted bearing angles, using the Gauss-Newton method. The convergence criterion is based on the step size $\|\Delta\mathbf{x}^{(k)}\|$ being smaller than a specified threshold $\epsilon$. If the algorithm does not converge within the maximum number of iterations $k_{\max}$, the last estimated source location is returned.