2024-06-05 09:47:49.016126

### System Model

- **Problem Type:** This is a direction-of-arrival (DOA) estimation problem in the domain of array signal processing. The objective is to estimate the angle of arrival $\Theta$ of a far-field narrowband source impinging on a uniform linear array (ULA) of sensors.

- **Problem Description:** Given a ULA with $N$ omnidirectional sensors spaced at half-wavelength ($\lambda/2$) intervals, a far-field narrowband signal source is continuously emitting signals from an unknown angle $\Theta$ relative to the array. The received signal at each sensor is a delayed and attenuated version of the transmitted signal, with the delay determined by the DOA and the array geometry. The goal is to estimate the DOA angle $\Theta$ accurately and efficiently from $K$ samples of the received signal at each sensor.

- **System Model Parameters:**
  - $N$: Number of sensors in the ULA
  - $\lambda$: Wavelength of the narrowband signal
  - $d = \lambda/2$: Inter-sensor spacing in the ULA
  - $\Theta$: Unknown direction-of-arrival (DOA) angle of the signal source
  - $s(t)$: Transmitted signal from the source
  - $x_n(t)$: Received signal at the $n$-th sensor, $n = 0, 1, \ldots, N-1$
  - $K$: Number of signal samples available for processing

- **System Model Formulations:**
  - The received signal at the $n$-th sensor can be expressed as:
    $$x_n(t) = \alpha s(t - n\tau) + w_n(t)$$
    where $\alpha$ is the signal amplitude, $\tau = d\sin(\Theta)/c$ is the time delay between adjacent sensors, $c$ is the speed of propagation, and $w_n(t)$ is the additive noise at the $n$-th sensor.

  - The received signal vector at the array can be written as:
    $$\mathbf{x}(t) = \alpha \mathbf{a}(\Theta) s(t) + \mathbf{w}(t)$$
    where $\mathbf{x}(t) = [x_0(t), x_1(t), \ldots, x_{N-1}(t)]^T$ is the received signal vector, $\mathbf{a}(\Theta) = [1, e^{j\omega_0\tau}, \ldots, e^{j\omega_0(N-1)\tau}]^T$ is the array steering vector, $\omega_0 = 2\pi/\lambda$ is the signal frequency, and $\mathbf{w}(t)$ is the noise vector.

### Optimization Formulation

- **Optimization Type:** This is a non-linear optimization problem, specifically a spectral estimation problem, where the goal is to find the DOA angle $\Theta$ that maximizes the output power of a spatial filter (beamformer) applied to the received signal vector.

- **Optimization Parameters:** The optimization parameters include the number of sensors $N$, the signal wavelength $\lambda$, and the number of signal samples $K$.

- **Optimization Variables:** The optimization variable is the DOA angle $\Theta$.

- **Objective:** The objective is to maximize the output power of the spatial filter (beamformer) with respect to the DOA angle $\Theta$, which is equivalent to maximizing the signal-to-noise ratio (SNR) of the received signal.

- **Constraints:** The DOA angle $\Theta$ is constrained to the range $[-\pi/2, \pi/2]$ radians, corresponding to the visible region of the ULA.

### Optimization Algorithm

- **Algorithm Type:** To solve the DOA estimation problem, a subspace-based algorithm such as MUSIC (MUltiple SIgnal Classification) or ESPRIT (Estimation of Signal Parameters via Rotational Invariance Techniques) can be used. These algorithms exploit the eigenstructure of the received signal covariance matrix to separate the signal and noise subspaces, and then estimate the DOA based on the orthogonality between the signal and noise subspaces.

- **Algorithm Parameters:** The main algorithm parameters include the number of signal sources (assumed to be one in this case), the dimension of the signal subspace (determined by the number of sources), and the number of signal samples $K$ used to estimate the signal covariance matrix.

- **Algorithm Steps:**
  1. Estimate the sample covariance matrix $\mathbf{R}_{xx}$ of the received signal vector $\mathbf{x}(t)$ using $K$ samples:
     $$\mathbf{R}_{xx} = \frac{1}{K} \sum_{k=1}^K \mathbf{x}(k) \mathbf{x}^H(k)$$
  2. Perform eigendecomposition of $\mathbf{R}_{xx}$ to obtain the eigenvalues $\lambda_i$ and corresponding eigenvectors $\mathbf{e}_i$, sorted in descending order.
  3. Partition the eigenvectors into signal and noise subspaces based on the multiplicity of the eigenvalues. Let $\mathbf{E}_s$ be the signal subspace matrix containing the eigenvectors corresponding to the $M$ largest eigenvalues, and $\mathbf{E}_n$ be the noise subspace matrix containing the remaining eigenvectors.
  4. For the MUSIC algorithm:
     - Compute the MUSIC spatial spectrum:
       $$P_{\text{MUSIC}}(\Theta) = \frac{1}{\mathbf{a}^H(\Theta)\mathbf{E}_n\mathbf{E}_n^H\mathbf{a}(\Theta)}$$
     - Estimate the DOA $\hat{\Theta}$ as the angle that maximizes the MUSIC spectrum:
       $$\hat{\Theta} = \arg\max_\Theta P_{\text{MUSIC}}(\Theta)$$
  5. For the ESPRIT algorithm:
     - Partition the signal subspace matrix $\mathbf{E}_s$ into two submatrices $\mathbf{E}_1$ and $\mathbf{E}_2$, containing the first and last $N-1$ rows, respectively.
     - Compute the ESPRIT operator $\Psi = (\mathbf{E}_2^H\mathbf{E}_2)^{-1}\mathbf{E}_2^H\mathbf{E}_1$.
     - Estimate the DOA $\hat{\Theta}$ from the eigenvalues $\lambda_i$ of $\Psi$ as:
       $$\hat{\Theta} = \angle(\lambda_i)/\omega_0 d$$
     where $\angle(\cdot)$ denotes the phase angle.
  6. Terminate the algorithm after estimating the DOA $\hat{\Theta}$.

To compare the estimation accuracy for different values of $K$, you can simulate the algorithm for various values of $K$ and compute the root-mean-square error (RMSE) between the estimated DOA $\hat{\Theta}$ and the true DOA $\Theta$. The RMSE can be averaged over multiple Monte Carlo trials to obtain a reliable estimate of the algorithm's performance.

The provided structured response covers the system model, optimization formulation, and optimization algorithm for the DOA estimation problem using subspace-based techniques. The simulation code in MATLAB or Python can be developed based on the outlined algorithm steps and performance evaluation methodology.