2024-06-05 09:47:49.016126

#### Terminological Description:
The scene describes a uniform linear array (ULA) of $N$ sensors with half-wavelength spacing, receiving signals from a continuous source at an angle $\Theta$ relative to the array. The problem involves estimating the direction-of-arrival (DOA) angle $\Theta$ from $K$ samples of the received signal. The key terminologies include uniform linear array, array signal processing, direction-of-arrival estimation, spectral estimation, subspace decomposition, and computational complexity analysis.

#### Relevant Examples:
1. Paper_15: extractor_ESPRIT--A_subspace_rotation_approach_to_estimation_of_parameters_of_cisoids_in_noise.md
2. Paper_30: extractor_Multiple_emitter_location_and_signal_parameter_estimation.md
3. Paper_61: extractor_Unified_analysis_for_DOA_estimation_algorithms_in_array_signal_processing.md