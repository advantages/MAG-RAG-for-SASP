2024-06-05 10:00:55.507270

### System Model
- **Problem Type:** Source localization using time-of-arrival (TOA) measurements from a sensor array.
- **Problem Description:** The goal is to localize a signal source by utilizing the time-of-arrival (TOA) measurements obtained from an array of sensors positioned at known locations. The TOA measurements represent the propagation time of the signal from the source to each sensor, which is proportional to the distance between the source and the respective sensor. By exploiting the geometric relationships between the sensor positions and the source location, the objective is to estimate the coordinates of the signal source.
- **System Model Parameters:**
    - $M$: Number of sensors in the array
    - $\mathbf{x}_i = (x_i, y_i)$: Position coordinates of the $i$-th sensor, $i = 1, 2, \ldots, M$
    - $\mathbf{x}_s = (x_s, y_s)$: Unknown position coordinates of the signal source
    - $t_i$: Time-of-arrival measurement at the $i$-th sensor
    - $c$: Speed of the signal propagation (e.g., speed of light for electromagnetic signals)
- **System Model Formulations:**
    - The distance between the signal source and the $i$-th sensor is given by: $d_i = \sqrt{(x_i - x_s)^2 + (y_i - y_s)^2}$
    - The TOA measurement at the $i$-th sensor is related to the distance as: $t_i = \frac{d_i}{c} + n_i$, where $n_i$ is the measurement noise.
    - The objective is to estimate $\mathbf{x}_s$ from the known sensor positions $\mathbf{x}_i$ and the TOA measurements $t_i$.

### Optimization Formulation
- **Optimization Type:** Non-linear least-squares optimization problem.
- **Optimization Parameters:**
    - $\mathbf{x}_i$: Known sensor positions
    - $t_i$: TOA measurements at each sensor
    - $c$: Speed of signal propagation
- **Optimization Variables:** $\mathbf{x}_s = (x_s, y_s)$: Unknown signal source position.
- **Objective:** Minimize the sum of squared residuals between the measured TOA values and the theoretical TOA values based on the estimated source position:
    $$\min_{\mathbf{x}_s} \sum_{i=1}^{M} \left( t_i - \frac{\sqrt{(x_i - x_s)^2 + (y_i - y_s)^2}}{c} \right)^2$$
- **Constraints:** No explicit constraints on the source position variables $\mathbf{x}_s$.

### Optimization Algorithm
- **Algorithm Type:** Non-linear least-squares optimization algorithms, such as the Gauss-Newton method or the Levenberg-Marquardt algorithm.
- **Algorithm Parameters:**
    - Initial guess for the source position $\mathbf{x}_s^{(0)}$
    - Convergence tolerance $\epsilon$
    - Maximum number of iterations $N_{\max}$
- **Algorithm Steps:**
    1. Initialize the source position estimate $\mathbf{x}_s^{(0)}$ with an initial guess.
    2. For iteration $k = 0, 1, 2, \ldots, N_{\max}$:
        a. Compute the residual vector $\mathbf{r}^{(k)} = [r_1^{(k)}, r_2^{(k)}, \ldots, r_M^{(k)}]$, where $r_i^{(k)} = t_i - \frac{\sqrt{(x_i - x_s^{(k)})^2 + (y_i - y_s^{(k)})^2}}{c}$.
        b. Compute the Jacobian matrix $\mathbf{J}^{(k)}$, where $J_{ij}^{(k)} = \frac{\partial r_i^{(k)}}{\partial x_j}$.
        c. Solve the normal equations $(\mathbf{J}^{(k)})^T \mathbf{J}^{(k)} \Delta \mathbf{x}_s^{(k)} = -(\mathbf{J}^{(k)})^T \mathbf{r}^{(k)}$ for $\Delta \mathbf{x}_s^{(k)}$.
        d. Update the source position estimate: $\mathbf{x}_s^{(k+1)} = \mathbf{x}_s^{(k)} + \Delta \mathbf{x}_s^{(k)}$.
        e. If $\|\Delta \mathbf{x}_s^{(k)}\| < \epsilon$ or $k = N_{\max}$, terminate the algorithm.
    3. The final estimate of the signal source position is $\mathbf{x}_s^{(k+1)}$.

By following this structured approach, we have formulated the signal processing problem for source localization using TOA measurements from a sensor array. The system model captures the geometric relationships between the source and sensors, while the optimization formulation minimizes the residuals between measured and theoretical TOA values. The optimization algorithm provides a iterative method for estimating the source position by solving the non-linear least-squares problem.