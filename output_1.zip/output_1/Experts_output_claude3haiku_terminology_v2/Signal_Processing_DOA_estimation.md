2024-05-30 23:24:45.800408

### System Model

**Problem Type**: Direction-of-Arrival (DOA) Estimation using a Uniform Linear Array (ULA) sensor array.

**Problem Description**: The signal processing problem involves estimating the angle of arrival (or direction-of-arrival) $\Theta$ of a signal source using a uniform linear array of $N$ sensors. The signal source continuously emits a signal, and the array receives $K$ samples of the signal. The objective is to accurately and quickly estimate the angle $\Theta$ of the signal source relative to the array.

**System Model Parameters**:
- $N$: Number of array elements in the uniform linear array
- $\Theta$: Angle of the signal source relative to the array (the parameter to be estimated)
- $K$: Number of signal samples received by the array
- $d$: Spacing between array elements, assumed to be half a wavelength ($d = \lambda/2$)

**System Model Formulations**:
Let $\mathbf{x}(k)$ be the $N \times 1$ complex-valued vector representing the signal samples received by the array at the $k$-th time instant, where $k = 1, 2, \dots, K$. The array output can be modeled as:

$\mathbf{x}(k) = \mathbf{a}(\Theta) s(k) + \mathbf{n}(k)$

where:
- $\mathbf{a}(\Theta)$ is the $N \times 1$ steering vector, which is a function of the angle $\Theta$, and is given by:
$\mathbf{a}(\Theta) = [1, e^{-j\frac{2\pi}{\lambda}d\sin(\Theta)}, \dots, e^{-j(N-1)\frac{2\pi}{\lambda}d\sin(\Theta)}]^T$
- $s(k)$ is the complex-valued signal emitted by the source at the $k$-th time instant
- $\mathbf{n}(k)$ is the $N \times 1$ complex-valued noise vector, assumed to be zero-mean and white

### Optimization Formulation

**Optimization Type**: The DOA estimation problem can be formulated as an optimization problem to find the most accurate estimate of the angle $\Theta$.

**Optimization Parameters**:
- $N$: Number of array elements
- $K$: Number of signal samples
- $\lambda$: Wavelength of the signal

**Optimization Variables**:
- $\Theta$: The angle of the signal source, which is the parameter to be estimated.

**Objective**:
The objective is to find the value of $\Theta$ that maximizes the likelihood of the observed signal samples $\{\mathbf{x}(k)\}_{k=1}^K$. This can be expressed as the following optimization problem:

$\hat{\Theta} = \arg\max_{\Theta} \prod_{k=1}^K p(\mathbf{x}(k)|\Theta)$

where $p(\mathbf{x}(k)|\Theta)$ is the probability density function of the array output $\mathbf{x}(k)$ given the angle $\Theta$.

**Constraints**:
The optimization variable $\Theta$ is typically constrained to the range $[0, \pi]$ or $[-\pi/2, \pi/2]$, depending on the array geometry and the coordinate system used.

### Optimization Algorithm

**Algorithm Type**: The Maximum Likelihood Estimation (MLE) approach is a suitable algorithm for solving the DOA estimation problem. MLE provides an optimal solution in the sense of achieving the Cramér-Rao lower bound (CRLB) on the variance of the estimated parameter $\Theta$.

**Algorithm Parameters**:
- Convergence tolerance: The algorithm should terminate when the change in the estimated $\Theta$ between iterations is less than a predefined tolerance value.
- Maximum number of iterations: To ensure the algorithm converges within a reasonable time, a maximum number of iterations can be specified as a stopping criterion.

**Algorithm Steps**:
1. Initialize the estimate of $\Theta$ to a reasonable value, e.g., $\Theta_0 = 0$.
2. Compute the steering vector $\mathbf{a}(\Theta_0)$ using the current estimate of $\Theta$.
3. Compute the likelihood function $\prod_{k=1}^K p(\mathbf{x}(k)|\Theta_0)$ based on the signal model.
4. Update the estimate of $\Theta$ by maximizing the likelihood function:
   $\Theta_{n+1} = \arg\max_{\Theta} \prod_{k=1}^K p(\mathbf{x}(k)|\Theta)$
5. Check the convergence criterion:
   - If the change in $\Theta$ between iterations is less than the tolerance, terminate the algorithm and return the final estimate $\hat{\Theta}$.
   - Otherwise, increment the iteration counter and go to step 2.

The performance of the DOA estimation algorithm can be evaluated by comparing the accuracy of the estimated angle $\hat{\Theta}$ for different values of the number of samples $K$. The estimation accuracy can be measured using metrics such as the root-mean-square error (RMSE) between the true angle $\Theta$ and the estimated angle $\hat{\Theta}$.