2024-05-30 23:24:45.800408

### System Model

**Problem Type:** The given problem is a signal estimation problem in the context of a wideband multiple-input multiple-output (MIMO) radar system.

**Problem Description:** The objective is to design a beamforming weight vector that maximizes the signal-to-interference-plus-noise ratio (SINR) at the beamformer output. The system consists of a uniform linear array (ULA) with $N$ elements spaced at half-wavelength intervals. There is a signal source emitting a signal at an angle $\Theta$ in the presence of $P$ interference sources emitting signals from angles $\Phi_p$, where $p=1,2,\dots,P$.

**System Model Parameters:**
- $N$: Number of array elements in the uniform linear array
- $\Theta$: Angle of the desired signal source
- $\Phi_p$: Angles of the $P$ interference sources, where $p=1,2,\dots,P$
- $\mathbf{a}(\theta)$: Array steering vector for angle $\theta$, defined as $\mathbf{a}(\theta) = [1, e^{j\pi\sin\theta}, \dots, e^{j(N-1)\pi\sin\theta}]^T$
- $\mathbf{s}$: Complex-valued signal from the desired source
- $\mathbf{i}_p$: Complex-valued signal from the $p$-th interference source
- $\mathbf{n}$: Complex-valued additive white Gaussian noise (AWGN) vector

**System Model Formulations:**
The received signal at the array can be expressed as:
$$\mathbf{x} = \mathbf{a}(\Theta)\mathbf{s} + \sum_{p=1}^P \mathbf{a}(\Phi_p)\mathbf{i}_p + \mathbf{n}$$

The beamformer output is given by:
$$y = \mathbf{w}^H\mathbf{x}$$

where $\mathbf{w}$ is the complex-valued beamforming weight vector.

### Optimization Formulation

**Optimization Type:** The problem is formulated as a non-convex optimization problem, which will be solved using the Successive Alternating Direction Method of Multipliers (S-ADMM) algorithm.

**Optimization Parameters:**
- $N$: Number of array elements
- $\Theta$: Angle of the desired signal source
- $\Phi_p$: Angles of the $P$ interference sources
- $\sigma_s^2$: Variance of the desired signal
- $\sigma_i^2$: Variance of the interference signals
- $\sigma_n^2$: Variance of the additive white Gaussian noise

**Optimization Variables:**
The optimization variable is the complex-valued beamforming weight vector $\mathbf{w} = [w_1, w_2, \dots, w_N]^T$.

**Objective:**
The objective is to maximize the signal-to-interference-plus-noise ratio (SINR) at the beamformer output, which is given by:
$$\text{SINR} = \frac{\sigma_s^2|\mathbf{w}^H\mathbf{a}(\Theta)|^2}{\sigma_i^2\sum_{p=1}^P |\mathbf{w}^H\mathbf{a}(\Phi_p)|^2 + \sigma_n^2\|\mathbf{w}\|^2}$$

**Constraints:**
1. Modulus constraint: $|w_n| = 1, \forall n=1,2,\dots,N$
2. Power constraint: $\|\mathbf{w}\|^2 = N$

### Optimization Algorithm

**Algorithm Type:** The Successive Alternating Direction Method of Multipliers (S-ADMM) algorithm is employed to solve the non-convex optimization problem.

**Algorithm Parameters:**
- Number of iterations: $K$
- Penalty parameter: $\rho$
- Termination tolerance: $\epsilon$

**Algorithm Steps:**
1. Initialize the beamforming weight vector $\mathbf{w}^{(0)}$ randomly, subject to the modulus constraint.
2. For $k = 1, 2, \dots, K$:
   a. Update the beamforming weights $\mathbf{w}^{(k)}$ by solving the following subproblem:
   $$\mathbf{w}^{(k)} = \arg\max_{\mathbf{w}} \frac{\sigma_s^2|\mathbf{w}^H\mathbf{a}(\Theta)|^2}{\sigma_i^2\sum_{p=1}^P |\mathbf{w}^H\mathbf{a}(\Phi_p)|^2 + \sigma_n^2\|\mathbf{w}\|^2} + \rho\left\|\mathbf{w} - \mathbf{z}^{(k-1)} + \frac{\boldsymbol{\lambda}^{(k-1)}}{\rho}\right\|^2$$
   subject to the modulus constraint $|w_n| = 1, \forall n=1,2,\dots,N$.
   b. Update the auxiliary variable $\mathbf{z}^{(k)}$ by projecting $\mathbf{w}^{(k)}$ onto the power constraint:
   $$\mathbf{z}^{(k)} = \frac{\mathbf{w}^{(k)}}{\|\mathbf{w}^{(k)}\|} \sqrt{N}$$
   c. Update the Lagrange multiplier $\boldsymbol{\lambda}^{(k)}$:
   $$\boldsymbol{\lambda}^{(k)} = \boldsymbol{\lambda}^{(k-1)} + \rho(\mathbf{w}^{(k)} - \mathbf{z}^{(k)})$$
3. Terminate the algorithm when the change in the objective function or the norm of the residual $\|\mathbf{w}^{(k)} - \mathbf{z}^{(k)}\|$ is less than the tolerance $\epsilon$.

The optimal beamforming weight vector is given by the final iteration $\mathbf{w}^{(K)}$.