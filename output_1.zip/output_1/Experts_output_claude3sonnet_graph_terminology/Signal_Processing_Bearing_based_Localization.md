2024-05-06 23:53:11.586611

### System Model
- **Problem Type:** Localization of a signal source using bearing angle measurements from multiple sensors.
- **Problem Description:** Given a set of M sensors located at known positions (x_i, y_i), where i = 1, 2, ..., M, the objective is to estimate the unknown location of a signal source based on the bearing angle measurements from each sensor. The measured bearing angle at sensor i is denoted as θ_i, which may be corrupted by additive Gaussian noise.
- **System Model Parameters:**
    - M: Number of sensors
    - (x_i, y_i): Coordinates of the i-th sensor location, for i = 1, 2, ..., M
    - θ_i: Measured bearing angle at the i-th sensor, for i = 1, 2, ..., M
    - (x_s, y_s): Unknown coordinates of the signal source
    - σ_i: Standard deviation of the Gaussian noise in the bearing angle measurement at the i-th sensor
- **System Model Formulations:**
    - The true bearing angle of the signal source relative to the i-th sensor is given by:
    
    $$ \theta_i^{\text{true}} = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right) $$
    
    - The measured bearing angle at the i-th sensor is modeled as:
    
    $$ \theta_i = \theta_i^{\text{true}} + n_i $$
    
    where $n_i \sim \mathcal{N}(0, \sigma_i^2)$ is the additive Gaussian noise.

### Optimization Formulation
- **Optimization Type:** Non-linear least squares optimization
- **Optimization Parameters:**
    - M: Number of sensors
    - (x_i, y_i): Coordinates of the i-th sensor location, for i = 1, 2, ..., M
    - θ_i: Measured bearing angle at the i-th sensor, for i = 1, 2, ..., M
    - σ_i: Standard deviation of the Gaussian noise in the bearing angle measurement at the i-th sensor
- **Optimization Variables:** (x_s, y_s): Unknown coordinates of the signal source
- **Objective:** Minimize the sum of squared residuals between the measured and predicted bearing angles:
    
    $$ \min_{x_s, y_s} \sum_{i=1}^{M} \left( \theta_i - \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right) \right)^2 $$
    
- **Constraints:** None

### Optimization Algorithm
- **Algorithm Type:** Gauss-Newton algorithm
- **Algorithm Parameters:**
    - ε: Convergence threshold for the algorithm
    - k_max: Maximum number of iterations
- **Algorithm Steps:**
    1. Initialize the source location estimate (x_s^0, y_s^0) with an initial guess.
    2. For k = 0, 1, 2, ..., k_max:
        1. Compute the residual vector r^k = [r_1^k, r_2^k, ..., r_M^k]^T, where r_i^k = θ_i - tan^(-1)((y_s^k - y_i) / (x_s^k - x_i)).
        2. Compute the Jacobian matrix J^k, where the (i, 1)th and (i, 2)th elements are:
            
            $$ J_{i,1}^k = \frac{y_i - y_s^k}{(x_s^k - x_i)^2 + (y_s^k - y_i)^2} $$
            
            $$ J_{i,2}^k = \frac{x_s^k - x_i}{(x_s^k - x_i)^2 + (y_s^k - y_i)^2} $$
            
        3. Compute the update step Δx^k by solving the normal equations:
            
            $$ (J^{k})^T J^k \Delta x^k = -(J^{k})^T r^k $$
            
        4. Update the source location estimate:
            
            $$ x_s^{k+1} = x_s^k + \Delta x^k_1 $$
            
            $$ y_s^{k+1} = y_s^k + \Delta x^k_2 $$
            
        5. If ||Δx^k|| < ε, terminate the algorithm and return (x_s^{k+1}, y_s^{k+1}) as the estimated source location.
    3. If the maximum number of iterations k_max is reached, terminate the algorithm and return the final estimate (x_s^{k_max+1}, y_s^{k_max+1}).

The Gauss-Newton algorithm is an iterative method that linearizes the non-linear objective function at the current estimate and solves for the update step that minimizes the linearized residuals. This process is repeated until convergence or the maximum number of iterations is reached. The algorithm is suitable for this problem as it can handle the non-linear relationship between the source location and the bearing angle measurements.