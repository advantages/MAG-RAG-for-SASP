2024-05-06 23:53:11.586611

### System Model
- **Problem Type:** Direction-of-Arrival (DoA) estimation of narrowband far-field signals impinging on a uniform linear array (ULA) of sensors.
- **Problem Description:** Given a uniform linear array containing $N$ array elements with an array spacing of half a wavelength, there exists a signal source in space that continuously emits a signal from an angle $\Theta$ relative to the array. The number of sampled signals is $K$, which encapsulates segmental information. The objective is to quickly and accurately estimate the angle of the signal source $\Theta$.
- **System Model Parameters:**
  - $N$: Number of array elements in the ULA
  - $\lambda$: Wavelength of the impinging signal
  - $d$: Array element spacing, where $d = \lambda/2$
  - $\Theta$: Angle of the signal source relative to the array
  - $K$: Number of sampled signals
  - $x_n(t)$: Signal received at the $n$-th array element at time $t$
  - $s(t)$: Signal waveform emitted by the source at time $t$
  - $n_n(t)$: Additive white Gaussian noise at the $n$-th array element at time $t$
- **System Model Formulations:**
  The signal received at the $n$-th array element can be expressed as:
  
  $$x_n(t) = s(t) \exp\left(j\frac{2\pi}{\lambda}nd\sin(\Theta)\right) + n_n(t)$$
  
  Defining the steering vector $\mathbf{a}(\Theta) = \left[1, \exp\left(j\frac{2\pi}{\lambda}d\sin(\Theta)\right), \ldots, \exp\left(j\frac{2\pi}{\lambda}(N-1)d\sin(\Theta)\right)\right]^T$, the array output vector $\mathbf{x}(t) = \left[x_0(t), x_1(t), \ldots, x_{N-1}(t)\right]^T$ can be modeled as:
  
  $$\mathbf{x}(t) = s(t)\mathbf{a}(\Theta) + \mathbf{n}(t)$$
  
  where $\mathbf{n}(t) = \left[n_0(t), n_1(t), \ldots, n_{N-1}(t)\right]^T$ is the noise vector.

### Optimization Formulation
- **Optimization Type:** Subspace-based DoA estimation.
- **Optimization Parameters:**
  - $\mathbf{R}$: Covariance matrix of the array output, $\mathbf{R} = \mathbb{E}\left[\mathbf{x}(t)\mathbf{x}^H(t)\right]$
  - $\sigma_n^2$: Noise power
  - $\mathbf{U}_s$: Signal subspace eigenvectors of $\mathbf{R}$
  - $\mathbf{U}_n$: Noise subspace eigenvectors of $\mathbf{R}$
- **Optimization Variables:** The DoA $\Theta$.
- **Objective:** Minimize the projection of the steering vector $\mathbf{a}(\Theta)$ onto the noise subspace $\mathbf{U}_n$, i.e., minimize $\|\mathbf{U}_n^H\mathbf{a}(\Theta)\|^2$.
- **Constraints:** $-\pi/2 \leq \Theta \leq \pi/2$, where $\Theta$ is the angle of the signal source relative to the array.

### Optimization Algorithm
- **Algorithm Type:** MUSIC (MUltiple SIgnal Classification) algorithm.
- **Algorithm Parameters:**
  - $M$: Number of snapshots used to estimate the covariance matrix $\mathbf{R}$
  - $K$: Number of signals to be estimated
- **Algorithm Steps:**
  1. Collect $M$ snapshots of the array output $\mathbf{x}(t)$ and construct the data matrix $\mathbf{X} = \left[\mathbf{x}(1), \mathbf{x}(2), \ldots, \mathbf{x}(M)\right]$.
  2. Estimate the covariance matrix $\mathbf{R}$ as $\mathbf{R} = \frac{1}{M}\mathbf{X}\mathbf{X}^H$.
  3. Perform eigenvalue decomposition of $\mathbf{R}$ to obtain the signal subspace eigenvectors $\mathbf{U}_s$ and noise subspace eigenvectors $\mathbf{U}_n$.
  4. Define the MUSIC spatial spectrum as $P_{\text{MUSIC}}(\Theta) = \frac{1}{\mathbf{a}^H(\Theta)\mathbf{U}_n\mathbf{U}_n^H\mathbf{a}(\Theta)}$.
  5. Find the $K$ largest peaks of $P_{\text{MUSIC}}(\Theta)$, and the corresponding angles are the estimated DoAs $\hat{\Theta}_1, \hat{\Theta}_2, \ldots, \hat{\Theta}_K$.
  6. Terminate the algorithm when $K$ DoAs have been estimated.

To compare the estimation accuracy for different values of $K$, the algorithm can be run multiple times with varying $K$ values, and the mean squared error (MSE) between the estimated DoAs and the true DoA $\Theta$ can be computed for each case. The MSE is given by:

$$\text{MSE}(\hat{\Theta}) = \frac{1}{K}\sum_{k=1}^K (\hat{\Theta}_k - \Theta)^2$$

The MSE can be plotted against different values of $K$ to analyze the estimation accuracy as a function of the number of sampled signals.