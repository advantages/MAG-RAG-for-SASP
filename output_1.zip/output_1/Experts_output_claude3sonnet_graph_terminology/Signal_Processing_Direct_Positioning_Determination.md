2024-05-06 23:53:11.586611

### System Model
- **Problem Type:** Source localization and direction-of-arrival (DoA) estimation for multiple narrowband far-field sources impinging on a sensor array.
- **Problem Description:** The problem involves estimating the spatial locations or directions-of-arrival (DoAs) of multiple narrowband far-field signal sources using an array of sensors. The sensors receive a superposition of the emitted signals from the sources, corrupted by additive noise. The objective is to accurately estimate the DoAs or spatial coordinates of the sources based on the received signal measurements at the sensor array.
- **System Model Parameters:**
  - $M$: Number of sensors in the array
  - $K$: Number of signal sources
  - $\mathbf{x}(t) \in \mathbb{C}^{M \times 1}$: Received signal vector at the sensor array at time $t$
  - $\mathbf{s}(t) \in \mathbb{C}^{K \times 1}$: Signal waveform vector from the $K$ sources at time $t$
  - $\mathbf{n}(t) \in \mathbb{C}^{M \times 1}$: Additive noise vector at the sensor array at time $t$
  - $\mathbf{A}(\boldsymbol{\theta}) \in \mathbb{C}^{M \times K}$: Array manifold or steering matrix, where $\boldsymbol{\theta} = [\theta_1, \theta_2, \ldots, \theta_K]^T$ are the DoAs or spatial coordinates of the sources
  - $\sigma_n^2$: Noise variance
- **System Model Formulations:**
  - Received signal model:
    $$\mathbf{x}(t) = \mathbf{A}(\boldsymbol{\theta})\mathbf{s}(t) + \mathbf{n}(t)$$
  - Array manifold or steering matrix:
    $$\mathbf{A}(\boldsymbol{\theta}) = [\mathbf{a}(\theta_1), \mathbf{a}(\theta_2), \ldots, \mathbf{a}(\theta_K)]$$
    where $\mathbf{a}(\theta_k) \in \mathbb{C}^{M \times 1}$ is the steering vector for the $k$-th source, which depends on the array geometry and the DoA or spatial coordinates $\theta_k$.
  - Noise model: $\mathbf{n}(t) \sim \mathcal{CN}(\mathbf{0}, \sigma_n^2\mathbf{I}_M)$, where $\mathcal{CN}$ denotes the complex Gaussian distribution.

### Optimization Formulation
- **Optimization Type:** Nonlinear least-squares optimization over the array manifold.
- **Optimization Parameters:**
  - $\mathbf{R}_x = \mathbb{E}[\mathbf{x}(t)\mathbf{x}^H(t)]$: Covariance matrix of the received signal
  - $\mathbf{R}_s = \mathbb{E}[\mathbf{s}(t)\mathbf{s}^H(t)]$: Covariance matrix of the signal waveforms
  - $\hat{\mathbf{R}}_x = \frac{1}{T} \sum_{t=1}^T \mathbf{x}(t)\mathbf{x}^H(t)$: Sample covariance matrix estimated from $T$ snapshots
  - $\{\lambda_i, \mathbf{u}_i\}_{i=1}^M$: Eigenvalues and eigenvectors of $\mathbf{R}_x$
- **Optimization Variables:** $\boldsymbol{\theta} = [\theta_1, \theta_2, \ldots, \theta_K]^T$: DoAs or spatial coordinates of the $K$ sources.
- **Objective:** The objective function aims to minimize the discrepancy between the sample covariance matrix $\hat{\mathbf{R}}_x$ and the theoretical covariance matrix $\mathbf{R}_x = \mathbf{A}(\boldsymbol{\theta})\mathbf{R}_s\mathbf{A}^H(\boldsymbol{\theta}) + \sigma_n^2\mathbf{I}_M$. A commonly used objective function is:
  $$J(\boldsymbol{\theta}) = \left\|\hat{\mathbf{R}}_x - \mathbf{A}(\boldsymbol{\theta})\mathbf{R}_s\mathbf{A}^H(\boldsymbol{\theta}) - \sigma_n^2\mathbf{I}_M\right\|_F^2$$
  where $\|\cdot\|_F$ denotes the Frobenius norm.
- **Constraints:** The DoAs or spatial coordinates $\boldsymbol{\theta}$ should lie within the physical limits imposed by the array geometry and signal propagation environment.

### Optimization Algorithm
- **Algorithm Type:** Subspace-based methods, such as MUSIC (MUltiple SIgnal Classification) or ESPRIT (Estimation of Signal Parameters via Rotational Invariance Techniques).
- **Algorithm Parameters:**
  - $\mathbf{U}_s$: Signal subspace eigenvectors corresponding to the $K$ largest eigenvalues of $\mathbf{R}_x$
  - $\mathbf{U}_n$: Noise subspace eigenvectors corresponding to the $(M-K)$ smallest eigenvalues of $\mathbf{R}_x$
  - $\mathbf{A}(\boldsymbol{\theta})$: Array manifold or steering matrix as a function of $\boldsymbol{\theta}$
- **Algorithm Steps:**
  1. Estimate the sample covariance matrix $\hat{\mathbf{R}}_x$ from the received signal snapshots.
  2. Perform eigendecomposition of $\hat{\mathbf{R}}_x$ to obtain the eigenvalues $\{\lambda_i\}_{i=1}^M$ and eigenvectors $\{\mathbf{u}_i\}_{i=1}^M$.
  3. Partition the eigenvectors into signal subspace $\mathbf{U}_s$ and noise subspace $\mathbf{U}_n$.
  4. **MUSIC Algorithm:**
     - For each potential DoA or spatial coordinate $\boldsymbol{\theta}$, compute the MUSIC spatial spectrum:
       $$P_{\text{MUSIC}}(\boldsymbol{\theta}) = \frac{1}{\mathbf{a}^H(\boldsymbol{\theta})\mathbf{U}_n\mathbf{U}_n^H\mathbf{a}(\boldsymbol{\theta})}$$
     - The $K$ largest peaks of $P_{\text{MUSIC}}(\boldsymbol{\theta})$ correspond to the estimated DoAs or spatial coordinates $\hat{\boldsymbol{\theta}}$.
  5. **ESPRIT Algorithm:**
     - Exploit the rotational invariance property of the signal subspace to estimate $\hat{\boldsymbol{\theta}}$ without spectral search.
     - Refer to the specific ESPRIT algorithm steps in the literature for the detailed implementation.
  6. Optionally, refine the DoA estimates using nonlinear least-squares optimization or other post-processing techniques.

The MUSIC and ESPRIT algorithms are popular subspace-based methods for DoA estimation and source localization. MUSIC involves a spectral search over the array manifold, while ESPRIT exploits the rotational invariance property of the signal subspace to estimate the DoAs without spectral search. Both algorithms rely on the eigendecomposition of the sample covariance matrix and the partitioning of the signal and noise subspaces.