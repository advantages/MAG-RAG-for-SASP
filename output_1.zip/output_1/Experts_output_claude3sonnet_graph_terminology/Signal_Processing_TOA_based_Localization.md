2024-05-06 23:53:11.586611

### System Model
- **Problem Type:** Time-of-arrival (TOA) based source localization using a sensor array.
- **Problem Description:** Given a set of $M$ sensors at known positions $(\var{x_i}, \var{y_i})$, $i=1,2,\ldots,M$, and the corresponding TOA measurements $\var{t_i}$ of a signal source, the objective is to estimate the unknown location of the source.
- **System Model Parameters:**
    - $M$: Number of sensors
    - $(\var{x_i}, \var{y_i})$: Known position of the $i$-th sensor
    - $\var{t_i}$: Measured TOA of the signal at the $i$-th sensor
    - $\var{c}$: Speed of propagation (e.g., speed of light for electromagnetic signals)
    - $(\var{x}, \var{y})$: Unknown location of the signal source
- **System Model Formulations:**
    - The measured TOA $\var{t_i}$ at the $i$-th sensor is related to the source location $(\var{x}, \var{y})$ by:
        $$\var{t_i} = \frac{1}{\var{c}}\sqrt{(\var{x} - \var{x_i})^2 + (\var{y} - \var{y_i})^2} + \var{n_i}$$
        where $\var{n_i}$ is the measurement noise at the $i$-th sensor.
    - Alternatively, the distance $\var{d_i}$ between the source and the $i$-th sensor can be expressed as:
        $$\var{d_i} = \var{ct_i} = \sqrt{(\var{x} - \var{x_i})^2 + (\var{y} - \var{y_i})^2} + \var{n_i}$$

### Optimization Formulation
- **Optimization Type:** Non-linear least squares optimization.
- **Optimization Parameters:**
    - $\mathbf{t} = [\var{t_1}, \var{t_2}, \ldots, \var{t_M}]^T$: Vector of measured TOAs
    - $\mathbf{X} = [\var{x_1}, \var{y_1}, \var{x_2}, \var{y_2}, \ldots, \var{x_M}, \var{y_M}]^T$: Vector of known sensor positions
    - $\mathbf{n} = [\var{n_1}, \var{n_2}, \ldots, \var{n_M}]^T$: Vector of measurement noise
    - $\mathbf{R} = \mathbb{E}[\mathbf{n}\mathbf{n}^T]$: Covariance matrix of the measurement noise
- **Optimization Variables:** $(\var{x}, \var{y})$: Location of the signal source.
- **Objective:** Minimize the non-linear least squares cost function:
    $$J(\var{x}, \var{y}) = (\mathbf{t} - \mathbf{f}(\var{x}, \var{y}))^T \mathbf{R}^{-1} (\mathbf{t} - \mathbf{f}(\var{x}, \var{y}))$$
    where $\mathbf{f}(\var{x}, \var{y}) = [\frac{1}{\var{c}}\sqrt{(\var{x} - \var{x_1})^2 + (\var{y} - \var{y_1})^2}, \ldots, \frac{1}{\var{c}}\sqrt{(\var{x} - \var{x_M})^2 + (\var{y} - \var{y_M})^2}]^T$.
- **Constraints:** None.

### Optimization Algorithm
- **Algorithm Type:** Gauss-Newton or Levenberg-Marquardt iterative algorithm.
- **Algorithm Parameters:**
    - $\mathbf{J}(\var{x}, \var{y})$: Jacobian matrix of $\mathbf{f}(\var{x}, \var{y})$
    - $\lambda$: Damping factor (for Levenberg-Marquardt)
    - $\epsilon$: Convergence tolerance
    - $(\var{x}^{(0)}, \var{y}^{(0)})$: Initial estimate of the source location
- **Algorithm Steps:**
    1. Initialize $(\var{x}^{(0)}, \var{y}^{(0)})$, $\lambda$, and $k=0$.
    2. Compute the residual $\mathbf{r}^{(k)} = \mathbf{t} - \mathbf{f}(\var{x}^{(k)}, \var{y}^{(k)})$.
    3. Compute the Jacobian matrix $\mathbf{J}^{(k)} = \mathbf{J}(\var{x}^{(k)}, \var{y}^{(k)})$.
    4. Solve the normal equations $(\mathbf{J}^{(k)T} \mathbf{R}^{-1} \mathbf{J}^{(k)} + \lambda \mathbf{I})\Delta\mathbf{p} = \mathbf{J}^{(k)T} \mathbf{R}^{-1} \mathbf{r}^{(k)}$ for $\Delta\mathbf{p}$.
    5. Update the source location estimate $(\var{x}^{(k+1)}, \var{y}^{(k+1)}) = (\var{x}^{(k)}, \var{y}^{(k)}) + \Delta\mathbf{p}$.
    6. If $\|\mathbf{r}^{(k+1)}\| < \epsilon$, terminate and return $(\var{x}^{(k+1)}, \var{y}^{(k+1)})$ as the estimated source location.
    7. Otherwise, update $\lambda$ and $k = k + 1$, and go to step 2.

The Jacobian matrix $\mathbf{J}(\var{x}, \var{y})$ is given by:

$$\mathbf{J}(\var{x}, \var{y}) = \begin{bmatrix}
\frac{\var{x} - \var{x_1}}{c\sqrt{(\var{x} - \var{x_1})^2 + (\var{y} - \var{y_1})^2}} & \frac{\var{y} - \var{y_1}}{c\sqrt{(\var{x} - \var{x_1})^2 + (\var{y} - \var{y_1})^2}} \\
\vdots & \vdots \\
\frac{\var{x} - \var{x_M}}{c\sqrt{(\var{x} - \var{x_M})^2 + (\var{y} - \var{y_M})^2}} & \frac{\var{y} - \var{y_M}}{c\sqrt{(\var{x} - \var{x_M})^2 + (\var{y} - \var{y_M})^2}}
\end{bmatrix}$$

The damping factor $\lambda$ is updated at each iteration based on the reduction in the cost function. If the cost function decreases, $\lambda$ is reduced; otherwise, it is increased.