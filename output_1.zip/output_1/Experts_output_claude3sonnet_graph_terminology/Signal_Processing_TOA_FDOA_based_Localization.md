2024-05-06 23:53:11.586611

### System Model
- **Problem Type:** Localization of a signal source using a sensor array with time difference of arrival (TDOA) and frequency difference of arrival (FDOA) measurements.
- **Problem Description:** Given an array of $M$ sensors at known positions $(\var{x_i},\var{y_i})$, $i=1,2,\ldots,M$, where each sensor can measure the TDOA and FDOA of a signal source, the objective is to estimate the location of the signal source by jointly processing the TDOA and FDOA measurements.
- **System Model Parameters:**
    - $M$: Number of sensors
    - $(\var{x_i},\var{y_i})$: Position of the $i$-th sensor in a 2D coordinate system
    - $(\var{x_s},\var{y_s})$: Unknown position of the signal source
    - $c$: Speed of propagation (e.g., speed of light)
    - $f_c$: Carrier frequency of the transmitted signal
    - $v_s$: Velocity of the signal source (if moving)
    - $\tau_{i1}$: TDOA measurement between the $i$-th sensor and a reference sensor (e.g., sensor 1)
    - $\nu_{i1}$: FDOA measurement between the $i$-th sensor and a reference sensor
    - $n_{\tau_i}$: TDOA measurement noise for the $i$-th sensor
    - $n_{\nu_i}$: FDOA measurement noise for the $i$-th sensor
- **System Model Formulations:** The TDOA measurement $\tau_{i1}$ between the $i$-th sensor and the reference sensor can be expressed as:

$$\tau_{i1} = \frac{1}{c}\left(\sqrt{(\var{x_s}-\var{x_i})^2 + (\var{y_s}-\var{y_i})^2} - \sqrt{(\var{x_s}-\var{x_1})^2 + (\var{y_s}-\var{y_1})^2}\right) + n_{\tau_i}$$

Similarly, the FDOA measurement $\nu_{i1}$ can be expressed as:

$$\nu_{i1} = \frac{f_c}{c}\left(\frac{\var{v_s}\cdot(\var{x_i}-\var{x_s})}{\sqrt{(\var{x_s}-\var{x_i})^2 + (\var{y_s}-\var{y_i})^2}} - \frac{\var{v_s}\cdot(\var{x_1}-\var{x_s})}{\sqrt{(\var{x_s}-\var{x_1})^2 + (\var{y_s}-\var{y_1})^2}}\right) + n_{\nu_i}$$

Where $\var{v_s} = [v_x, v_y]^T$ is the velocity vector of the moving signal source.

### Optimization Formulation
- **Optimization Type:** Non-linear least squares optimization or maximum likelihood estimation.
- **Optimization Parameters:**
    - $\boldsymbol{\tau} = [\tau_{21}, \tau_{31}, \ldots, \tau_{M1}]^T$: Vector of TDOA measurements
    - $\boldsymbol{\nu} = [\nu_{21}, \nu_{31}, \ldots, \nu_{M1}]^T$: Vector of FDOA measurements
    - $\mathbf{X} = [(\var{x_1}, \var{y_1}), (\var{x_2}, \var{y_2}), \ldots, (\var{x_M}, \var{y_M})]$: Matrix of known sensor positions
    - $\mathbf{Q}_{\tau}$: Covariance matrix of TDOA measurement noise
    - $\mathbf{Q}_{\nu}$: Covariance matrix of FDOA measurement noise
- **Optimization Variables:** $\boldsymbol{\theta} = [\var{x_s}, \var{y_s}, v_x, v_y]^T$: Vector of unknown source position and velocity.
- **Objective:** Minimize the weighted sum of squared residuals for both TDOA and FDOA measurements:

$$J(\boldsymbol{\theta}) = (\boldsymbol{\tau} - \mathbf{h}_{\tau}(\boldsymbol{\theta}))^T \mathbf{Q}_{\tau}^{-1} (\boldsymbol{\tau} - \mathbf{h}_{\tau}(\boldsymbol{\theta})) + (\boldsymbol{\nu} - \mathbf{h}_{\nu}(\boldsymbol{\theta}))^T \mathbf{Q}_{\nu}^{-1} (\boldsymbol{\nu} - \mathbf{h}_{\nu}(\boldsymbol{\theta}))$$

Where $\mathbf{h}_{\tau}(\boldsymbol{\theta})$ and $\mathbf{h}_{\nu}(\boldsymbol{\theta})$ are vectors of TDOA and FDOA model functions, respectively, evaluated at the current estimate of $\boldsymbol{\theta}$.

- **Constraints:** The source position $(\var{x_s}, \var{y_s})$ must lie within the region of interest, and the velocity components $v_x$ and $v_y$ should be within reasonable bounds.

### Optimization Algorithm
- **Algorithm Type:** Gauss-Newton or Levenberg-Marquardt iterative non-linear least squares optimization algorithm.
- **Algorithm Parameters:**
    - $\boldsymbol{\theta}_0$: Initial estimate of the source position and velocity
    - $\epsilon$: Convergence threshold for the change in the objective function or the parameter updates
    - $\lambda$: Levenberg-Marquardt damping parameter (for numerical stability)
    - $\alpha$: Step size for the Levenberg-Marquardt algorithm
- **Algorithm Steps:**
    1. Initialize the algorithm with an initial estimate $\boldsymbol{\theta}_0$ for the source position and velocity.
    2. Compute the residual vectors $\mathbf{r}_{\tau} = \boldsymbol{\tau} - \mathbf{h}_{\tau}(\boldsymbol{\theta}_0)$ and $\mathbf{r}_{\nu} = \boldsymbol{\nu} - \mathbf{h}_{\nu}(\boldsymbol{\theta}_0)$.
    3. Evaluate the Jacobian matrices $\mathbf{J}_{\tau}$ and $\mathbf{J}_{\nu}$ of the TDOA and FDOA model functions with respect to $\boldsymbol{\theta}$ at the current estimate $\boldsymbol{\theta}_0$.
    4. Form the combined Jacobian matrix $\mathbf{J} = [\mathbf{J}_{\tau}^T, \mathbf{J}_{\nu}^T]^T$ and the combined residual vector $\mathbf{r} = [\mathbf{r}_{\tau}^T, \mathbf{r}_{\nu}^T]^T$.
    5. Compute the Gauss-Newton update step $\Delta\boldsymbol{\theta}$ by solving the normal equation:

       $$\Delta\boldsymbol{\theta} = -(\mathbf{J}^T \mathbf{W} \mathbf{J} + \lambda \mathbf{I})^{-1} \mathbf{J}^T \mathbf{W} \mathbf{r}$$

       Where $\mathbf{W} = \text{diag}(\mathbf{Q}_{\tau}^{-1}, \mathbf{Q}_{\nu}^{-1})$ is the combined weight matrix, and $\lambda$ is the Levenberg-Marquardt damping parameter.

    6. Update the parameter estimate: $\boldsymbol{\theta}_\text{new} = \boldsymbol{\theta}_0 + \alpha \Delta\boldsymbol{\theta}$, where $\alpha$ is the step size.
    7. Evaluate the objective function $J(\boldsymbol{\theta}_\text{new})$ at the updated estimate.
    8. If the objective function decreases, accept the update: $\boldsymbol{\theta}_0 \leftarrow \boldsymbol{\theta}_\text{new}$. Otherwise, reject the update and decrease the damping parameter $\lambda$.
    9. Check the convergence criterion: if $\|J(\boldsymbol{\theta}_\text{new}) - J(\boldsymbol{\theta}_0)\| < \epsilon$ or $\|\Delta\boldsymbol{\theta}\| < \epsilon$, terminate the algorithm and return the final estimate $\boldsymbol{\theta}_\text{new}$. Otherwise, go to step 3 and repeat the process.

The algorithm iteratively refines the source position and velocity estimates by minimizing the weighted sum of squared residuals for both TDOA and FDOA measurements. The Levenberg-Marquardt damping parameter $\lambda$ is adjusted adaptively to ensure numerical stability and convergence.