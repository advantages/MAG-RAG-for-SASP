2024-05-06 23:53:11.586611

### System Model
- **Problem Type:** Direction-of-arrival (DOA) estimation of coherent signals in array signal processing.
- **Problem Description:** Consider a uniform linear array (ULA) with $2M+1$ isotropic sensors receiving $P$ far-field narrowband signals from directions $\theta_i, i=1,2,...,P$. The first $L$ signals are fully coherent, while the remaining $P-L$ signals are uncorrelated and independent of the first ones. The coherent signals exhibit phase differences $\Delta\phi_l$ with respect to a reference signal.
- **System Model Parameters:** 
    - $M$: Number of sensors on each side of the ULA
    - $P$: Total number of signals
    - $L$: Number of coherent signals
    - $\theta_i$: Direction-of-arrival of the $i$-th signal
    - $s_l(t) = \beta_l s_1(t) = \rho_l e^{j\Delta\phi_l} s_1(t)$: $l$-th coherent signal, where $\beta_l = \rho_l e^{j\Delta\phi_l}$ is the complex amplitude factor with $\rho_l$ being the amplitude fading factor and $\Delta\phi_l$ the phase difference relative to the reference signal $s_1(t)$
    - $\lambda$: Carrier wavelength
    - $d = \lambda/2$: Sensor spacing
    - $n_m(t)$: Additive white noise at the $m$-th sensor
- **System Model Formulations:**
    - $\mathbf{x}(t) = \mathbf{A}\mathbf{s}(t) + \mathbf{n}(t)$: Received signal vector
    - $\mathbf{x}(t) = [x_{-M}(t), \dots, x_0(t), \dots, x_M(t)]^T$
    - $\mathbf{s}(t) = [s_1(t), \dots, s_P(t)]^T$: Source signal vector
    - $\mathbf{n}(t) = [n_{-M}(t), \dots, n_0(t), \dots, n_M(t)]^T$: Noise vector
    - $\mathbf{A} = [\mathbf{a}(\theta_1), \dots, \mathbf{a}(\theta_P)]$: Array steering matrix
    - $\mathbf{a}(\theta_i) = [e^{j(2\pi/\lambda)Md\sin\theta_i}, \dots, 1, \dots, e^{-j(2\pi/\lambda)Md\sin\theta_i}]^T$: Steering vector for the $i$-th signal

### Optimization Formulation
- **Optimization Type:** Subspace-based DOA estimation methods, such as MUSIC, root-MUSIC, or ESPRIT, combined with the proposed FB-PTMR preprocessing technique.
- **Optimization Parameters:** The parameters derived from the system model, including the number of signals $P$, number of coherent signals $L$, signal directions $\theta_i$, phase differences $\Delta\phi_l$, and other array parameters like $M$ and $\lambda$.
- **Optimization Variables:** The directions-of-arrival $\theta_i$ of the signals.
- **Objective:** Estimate the DOAs $\theta_i$ of all $P$ signals, including the coherent and uncorrelated signals.
- **Constraints:** The constraints are inherent in the system model, such as the ULA geometry, signal coherence, and phase differences.

### Optimization Algorithm
- **Algorithm Type:** The proposed FB-PTMR algorithm, which is a preprocessing step for subspace-based DOA estimation methods like MUSIC, root-MUSIC, or ESPRIT.
- **Algorithm Parameters:** The number of sensors $2M+1$ and the number of snapshots $N$ used to estimate the sample covariance matrix (SCM).
- **Algorithm Steps:**
    1. Calculate the SCM $\hat{\mathbf{R}} = \frac{1}{N}\sum_{t=1}^{N}\mathbf{x}(t)\mathbf{x}^H(t)$.
    2. Construct partial Toeplitz matrices $\mathbf{R}_m$ by exploiting half rows of $\hat{\mathbf{R}}$ from $m=0$ to $M$:
       $\mathbf{R}_m = \begin{bmatrix}
         r(m,0) & r(m,1) & \cdots & r(m,M) \\
         r(m,-1) & r(m,0) & \cdots & r(m,M-1) \\
         \vdots & \vdots & \ddots & \vdots \\
         r(m,-M) & r(m,-M+1) & \cdots & r(m,0)
       \end{bmatrix}$
    3. Obtain the equivalent data covariance matrix $\tilde{\mathbf{R}}$ by summing the squared partial Toeplitz matrices:
       $\tilde{\mathbf{R}} = \sum_{m=0}^{M}\mathbf{R}_m\mathbf{R}_m^H = \tilde{\mathbf{A}}\tilde{\mathbf{R}}_S\tilde{\mathbf{A}}^H$
    4. Apply forward-backward averaging to improve the estimation performance:
       $\bar{\mathbf{R}} = \tilde{\mathbf{R}} + \mathbf{J}\tilde{\mathbf{R}}^*\mathbf{J}$
    5. Perform eigen-decomposition on $\bar{\mathbf{R}}$ and apply subspace-based methods like MUSIC, root-MUSIC, or ESPRIT to estimate the DOAs $\theta_i$.
    6. The algorithm terminates when the DOA estimates satisfy the specified criteria or a maximum number of iterations is reached.