2024-05-06 23:39:22.926194

### System Model

#### Problem Type
The problem can be categorized as a beamforming design problem for a colocated MIMO radar system.

#### Problem Description
The goal is to design the transmitted beamforming weights for a colocated MIMO radar system with $N$ array elements and an array spacing of half a wavelength. The desired objective is to match the amplitude of the expected radiation beam pattern in various directions in space, while the phase information is not provided.

#### System Model Parameters
- $N$: Number of array elements in the uniform linear array
- $\bar{d}$: Array spacing, which is set to half a wavelength
- $\theta$: Angular direction in space
- $a(\theta)$: $N \times 1$ steering vector, where $a_n(\theta) = e^{j2\pi f_0 \tau_n(\theta)}$, $\tau_n(\theta) = \frac{(n-1)\bar{d}\sin(\theta)}{\bar{v}}$, and $\bar{v}$ is the speed of propagation
- $A(\theta) = I_N \otimes a(\theta) \in \mathbb{C}^{N \times N}$, where $\otimes$ denotes the Kronecker product
- $x$: $N \times 1$ beamforming weight vector to be designed

#### System Model Formulations
The transmit beampattern at the angular location $\theta$ is given by:
$$P(\theta) = x^H A(\theta) A^H(\theta) x$$

The beamforming weight vector $x$ is subject to the constant modulus (CM) constraint:
$$|x_n| = \xi, \quad n = 1, \dots, N$$
where $\xi > 0$ is the modulus of the beamforming vector $x$.

The expected radiation beam pattern is provided in various directions in space, and it takes real values without phase information.

### Optimization Formulation

#### Optimization Type
The problem can be formulated as a constrained optimization problem to design the transmit beamforming weights that match the amplitude of the expected radiation beam pattern, while satisfying the constant modulus constraint.

#### Optimization Parameters
- $\Theta$: Mainlobe angle region, composed of $M$ angle grids $\{\theta_m\}_{m=1}^M$
- $\Omega$: Sidelobe angle region, composed of $S$ angle grids $\{\vartheta_s\}_{s=1}^S$
- $d$: Desired mainlobe level
- $\epsilon_r$: Mainlobe ripple term

#### Optimization Variables
- $x$: $N \times 1$ beamforming weight vector
- $\xi$: Modulus of the beamforming vector $x$

#### Objective
There are two optimization formulations proposed in the reference papers:

1. Without Beampattern Mask Design (WBM-Design):
   $$\max_{x} \frac{\min_{\theta_m \in \Theta} \|A^H(\theta_m)x\|_2}{\max_{\vartheta_s \in \Omega} \|A^H(\vartheta_s)x\|_2}$$
   This maximizes the ratio of the minimum mainlobe level to the peak sidelobe level.

2. With Ripple Constraints Design (WRC-Design):
   $$\min_{x, \xi} \max_{\vartheta_s \in \Omega} \|A^H(\vartheta_s)x\|_2$$
   This minimizes the peak sidelobe level.

#### Constraints
1. Constant modulus constraint:
   $$|x_n| = \xi, \quad n = 1, \dots, N$$

2. Mainlobe ripple constraint (for WRC-Design only):
   $$d - \epsilon_r \leq \|A^H(\theta_m)x\|_2 \leq d + \epsilon_r, \quad \theta_m \in \Theta$$

### Optimization Algorithm

#### Algorithm Type
The authors propose two ADMM-based algorithms to solve the proposed optimization formulations:

1. Algorithm for WBM-Design
2. Algorithm for WRC-Design

#### Algorithm Parameters
1. WBM-Design:
   - $\rho$: Step size
   - $T_0$: Maximum number of iterations
   - $\tilde{\iota}$: Iteration stop tolerance

2. WRC-Design:
   - $\beta$: Step size
   - $\tilde{\iota}$: Iteration stop tolerance
   - $T_0$: Maximum number of iterations

#### Algorithm Steps

1. Algorithm for WBM-Design:
   a. Initialize auxiliary variables and dual variables.
   b. While the stopping criterion is not met:
      i. Obtain the updated beamforming vector $x^{t+1}$ using Algorithm 1 (details provided in the paper).
      ii. Update the auxiliary variables and dual variables.
      iii. Increment the iteration counter.
   c. Output the MIMO radar waveform vector $x$.

2. Algorithm for WRC-Design:
   a. Initialize auxiliary variables and dual variables.
   b. While the stopping criterion is not met:
      i. Obtain the updated beamforming vector $x^{t+1}$ and modulus $\xi^{t+1}$ using Algorithm 3 (details provided in the paper).
      ii. Update the auxiliary variables and dual variables.
      iii. Increment the iteration counter.
   c. Output the MIMO radar probing signal $x$.

The authors provide the detailed steps for the ADMM-based algorithms in the reference papers, which include the derivation of the closed-form updates for the optimization variables and auxiliary variables.