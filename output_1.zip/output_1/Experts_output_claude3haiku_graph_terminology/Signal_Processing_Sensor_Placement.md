2024-05-06 23:39:22.926194

### System Model
- **Problem Type:** Optimal sensor placement for angle of arrival (AoA) based source localization.
- **Problem Description:** Given $M$ sensors that can measure the angle of arrival (AoA) of a single signal source, the objective is to optimally place the sensors in the space such that the AoA-based localization accuracy over $\bar{K}$ regions of interest (ROIs) is minimized.
- **System Model Parameters:**
    - $M$: Number of sensors
    - $\bar{K}$: Number of regions of interest (ROIs) where the target may appear
    - $\mathbf{r}_i \in \mathbb{R}^n$: Position of the $i$-th sensor, $i=1,\ldots,M$, where $n$ is the dimension of the problem (2 for 2D, 3 for 3D)
    - $\theta_i$: Angle of arrival (AoA) measurement at the $i$-th sensor
    - $\mathbf{p}_k \in \mathbb{R}^n$: Grid point within the $k$-th ROI, $k=1,\ldots,\bar{K}$
- **System Model Formulations:**
    The AoA measurement at the $i$-th sensor can be modeled as:
    $$\theta_i = \arctan\left(\frac{\mathbf{p}_k - \mathbf{r}_i}{\|\mathbf{p}_k - \mathbf{r}_i\|_2}\right) + n_i$$
    where $n_i$ represents the measurement noise at the $i$-th sensor.

### Optimization Formulation
- **Optimization Type:** The optimization problem aims to find the optimal placement of the $M$ sensors to minimize the AoA-based localization accuracy over the $\bar{K}$ ROIs. This can be formulated as a non-convex optimization problem.
- **Optimization Parameters:**
    - $K$: Number of grid points $\{\mathbf{p}_k\}_{k=1}^K$ sampled within the ROIs
    - $\mathbf{h}_{k,i} = \frac{\mathbf{p}_k - \mathbf{r}_i}{\|\mathbf{p}_k - \mathbf{r}_i\|_2}$: Unit vector from the $i$-th sensor to the $k$-th grid point
    - $\sigma_i^2$: Variance of the AoA measurement noise at the $i$-th sensor
    - $\mathbf{R}_i$: Feasible deployment region for the $i$-th sensor
- **Optimization Variables:**
    - $\mathbf{r}_i \in \mathbb{R}^n$: Position of the $i$-th sensor, $i=1,\ldots,M$
- **Objective:**
    The objective is to minimize the AoA-based localization accuracy, which can be formulated in terms of the Cramér-Rao lower bound (CRLB). This can be expressed as either the average or the worst-case CRLB over the $K$ grid points:
    - Average A-optimal: $\min_{\mathbf{r}_i \in \mathbf{R}_i} \frac{1}{K} \sum_{k=1}^K \text{Tr}\left(\left(\mathbf{H}_k^\top \mathbf{R}^{-1} \mathbf{H}_k\right)^{-1}\right)$
    - Worst-case A-optimal: $\min_{\mathbf{r}_i \in \mathbf{R}_i} \max_{k \in \{1, \ldots, K\}} \text{Tr}\left(\left(\mathbf{H}_k^\top \mathbf{R}^{-1} \mathbf{H}_k\right)^{-1}\right)$
    where $\mathbf{H}_k = [\mathbf{h}_{k,1}, \mathbf{h}_{k,2}, \ldots, \mathbf{h}_{k,M}]^\top$ and $\mathbf{R} = \text{diag}(\sigma_1^2, \sigma_2^2, \ldots, \sigma_M^2)$.
- **Constraints:**
    - $\mathbf{r}_i \in \mathbf{R}_i, \quad i=1,\ldots,M$: Sensor positions must lie within their respective feasible deployment regions.

### Optimization Algorithm
- **Algorithm Type:** Block majorization-minimization (MM) algorithm
- **Algorithm Parameters:**
    - $\tilde{\mathbf{A}}_{k,i}^t = \sum_{h=1, h\neq i} \sigma_h^{-2} \mathbf{h}_{k,h} \mathbf{h}_{k,h}^\top$
    - $\alpha_{k,i}^t = \text{Tr}\left(\left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-1}\right)$
    - $\mathbf{A}_{k,i}^t = \sigma_i^{-2} \alpha_{k,i}^t \left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-2}$
    - $\mathbf{B}_{k,i}^t = \sigma_i^{-2} \left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-1}$
    - $\mathbf{D}_{k,i}^t = \mathbf{I}_n + \mathbf{B}_{k,i}^t$
- **Algorithm Steps:**
    1. Initialize sensor positions $\mathbf{r}_i^0 \in \mathbf{R}_i$, $i=1,\ldots,M$
    2. For $t=0,1,2,\ldots$
        1. For $i=1,\ldots,M$
            1. Compute $\tilde{\mathbf{A}}_{k,i}^t$, $\alpha_{k,i}^t$, $\mathbf{A}_{k,i}^t$, $\mathbf{B}_{k,i}^t$, $\mathbf{D}_{k,i}^t$
            2. Construct a surrogate function for the average A-optimal objective
            3. Solve the corresponding convex optimization problem to update $\mathbf{r}_i^{t+1}$
        2. End
    3. Until convergence
    4. Return $\mathbf{r}_i^*$, $i=1,\ldots,M$

The algorithm monotonically decreases the objective function and converges to a stationary point under mild technical conditions, as proven in the referenced paper.