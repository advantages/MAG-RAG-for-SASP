2024-05-06 23:39:22.926194

### System Model

- **Problem Type:** Wideband multiple-input multiple-output (MIMO) radar waveform design

- **Problem Description:** The problem involves designing wideband MIMO radar waveforms to approximate a desired beampattern and achieve prescribed space-frequency nulling in a space-frequency region of interest, while considering modulus, power, and energy constraints on the probing waveforms.

- **System Model Parameters:**
    - $N$: Number of transmit antennas in the MIMO radar system
    - $d$: Array inter-element spacing
    - $f_c$: Carrier frequency
    - $B$: Bandwidth of the baseband signal
    - $s_n(t)$: Baseband signal of the $n$-th antenna
    - $M$: Number of samples of the baseband signal
    - $T_s = 1/B$: Sampling interval
    - $y_n(k) = \frac{1}{\sqrt{M}}\sum_{m=1}^{M}s_n(m)e^{-j2\pi(m-1)\bar{k}/M}$: Discrete Fourier Transform (DFT) of $\{s_n(m)\}_{m=1}^{M}$, where $\bar{k} = -(M/2) + k - 1, k \in \mathcal{M} = \{1, \ldots, M\}$
    - $\mathbf{y}(k) = [y_1(k), y_2(k), \ldots, y_N(k)]^T$
    - $\mathbf{a}_{\theta,f_k} = \frac{1}{\sqrt{N}}[1, e^{j2\pi(f_k+f_c)d\cos\theta/c}, \ldots, e^{j2\pi(f_k+f_c)(N-1)d\cos\theta/c}]^T$
    - $P_{\theta,f_k} = |\mathbf{a}_{\theta,f_k}^H\mathbf{y}(k)|^2$: Discrete space-frequency beampattern at angle $\theta$ and range $R_0$
    - $\Theta_1$: Discrete space-frequency cell set for beampattern approximation
    - $\Theta_2$: Discrete space-frequency cell set for nulling

- **System Model Formulations:**
    - $\mathbf{y}(k) = \mathbf{H}_k\mathbf{s}$, where $\mathbf{s} = \text{vec}([
 \mathbf{s}_1^T, \mathbf{s}_2^T, \ldots, \mathbf{s}_N^T]^T)$, $\mathbf{s}_n = [s_n(1), \ldots, s_n(M)]^T$, and $\mathbf{H}_k = \mathbf{a}_k^T \otimes \mathbf{I}_N$ with $\mathbf{a}_k = \frac{1}{\sqrt{M}}[1, e^{-j2\pi\bar{k}/M}, \ldots, e^{-j2\pi(M-1)\bar{k}/M}]^T$
    - The objective function to be minimized: $$f_0(\mathbf{s}) = (1-\gamma)\sum_{(\theta_l,f_k)\in\Theta_1}[d_0^{l,k} - |\mathbf{a}_{\theta_l,f_k}^H\mathbf{H}_k\mathbf{s}|]^2 + \gamma\sum_{(\tilde{\theta}_l,\tilde{f}_k)\in\Theta_2}|\mathbf{a}_{\tilde{\theta}_l,\tilde{f}_k}^H\mathbf{H}_{\tilde{k}}\mathbf{s}|^2$$
    where $\gamma \in [0,1]$ is a weighting factor balancing the beampattern approximation and space-frequency nulling requirements, and $d_0^{l,k}$ is the desired beampattern value at the $(l,k)$-th space-frequency cell.

### Optimization Formulation

- **Optimization Type:** Non-convex quadratically constrained quadratic programming (QCQP)

- **Optimization Parameters:**
    - $\lambda, \chi$: Lower and upper modulus bounds on the waveform amplitude, i.e., $\lambda \leq |s_n(m)| \leq \chi, \forall m \in \mathcal{M}, n \in \mathcal{N} = \{1, \ldots, N\}$
    - $p_1, p_2$: Lower and upper power bounds for each transmit antenna, i.e., $p_1 \leq \frac{1}{M}\|\mathbf{s}_n\|^2 \leq p_2, \forall n \in \mathcal{N}$
    - $e_1, e_2$: Lower and upper total energy bounds, i.e., $e_1 \leq \|\mathbf{s}\|^2 \leq e_2$

- **Optimization Variables:** $\mathbf{s} = [\mathbf{s}_1^T, \mathbf{s}_2^T, \ldots, \mathbf{s}_N^T]^T$, the concatenated waveform vector

- **Objective:** Minimize $f_0(\mathbf{s})$

- **Constraints:**
    - Modulus constraints: $\lambda \leq |s_n(m)| \leq \chi, \forall m \in \mathcal{M}, n \in \mathcal{N}$
    - Power constraints: $p_1 \leq \frac{1}{M}\|\mathbf{s}_n\|^2 \leq p_2, \forall n \in \mathcal{N}$
    - Total energy constraint: $e_1 \leq \|\mathbf{s}\|^2 \leq e_2$

### Optimization Algorithm

- **Algorithm Type:** Successive Alternating Direction Method of Multipliers (S-ADMM)

- **Algorithm Parameters:**
    - $\tau_1, \tau_2, \tau_3$: Small positive constants to control convergence
    - $\rho_1$: Penalty parameter in the ADMM algorithm for solving the convex QCQP subproblem, selected as $\rho_1^* = \frac{1}{\sqrt{\lambda_{\min}(\hat{\mathbf{A}})\lambda_{\max}(\hat{\mathbf{A}})}}$, where $\hat{\mathbf{A}} = \mathbf{B}\bar{\mathbf{A}}^{-1}\mathbf{B}^T$, $\bar{\mathbf{A}} = 2\mathbf{A}$, and $\mathbf{A}$, $\mathbf{B}$ are problem-specific matrices (see Equation (23) in the paper).

- **Algorithm Steps:**
    1. Initialize $\mathbf{s}^{(0)}$, $\{d_0^{l,k}\}_{(l,k)\in\Theta_1}$
    2. For $q = 1, 2, \ldots$
        1. Update $\phi_{l,k}^{(q-1)} = \arg\{\mathbf{a}_{\theta_l,f_k}^H\mathbf{H}_k\mathbf{s}^{(q-1)}\}$, $(l,k) \in \Theta_1$
        2. Update scaling factor $\alpha^{(q-1)}$ and desired beampattern $d^{(q)}_{l,k}$ using Equations (9) and (8)
        3. Solve the convex QCQP subproblem $\mathcal{P}_{\mathbf{s}}^{(q)}$ using the fast ADMM algorithm (Algorithm 2 in the paper) to obtain $\mathbf{s}^{(q)}$
        4. If $\|\mathbf{s}^{(q)} - \mathbf{s}^{(q-1)}\|/\|\mathbf{s}^{(q)}\| \leq \tau_3$, output $\mathbf{s}^* = \mathbf{s}^{(q)}$ and terminate. Otherwise, go to Step 2.
    
    The fast ADMM algorithm (Algorithm 2) for solving the convex QCQP subproblem $\mathcal{P}_{\mathbf{s}}^{(q)}$ involves the following steps:
    1. Initialize $\mathbf{x}^{(0)}, \mathbf{y}^{(0)}, \mathbf{z}^{(0)}, \mathbf{h}^{(0)}, \mathbf{u}_y^{(0)}, \mathbf{u}_z^{(0)}, \mathbf{u}_h^{(0)}$
    2. For $t = 1, 2, \ldots$
        1. Update $\mathbf{y}^{(t+1)}$, $\mathbf{z}^{(t+1)}$, $\mathbf{h}^{(t+1)}$ by solving closed-form subproblems involving the constraint sets $\Omega_y$, $\Omega_z$, $\Omega_h$, respectively
        2. Update $\mathbf{x}^{(t+1)}$ by solving a least-squares problem
        3. Update $\mathbf{u}_y^{(t+1)}$, $\mathbf{u}_z^{(t+1)}$, $\mathbf{u}_h^{(t+1)}$ using dual updates
        4. If $\max\{\|\mathbf{x}^{(t)} - \mathbf{y}^{(t)}\|, \|\mathbf{x}^{(t)} - \mathbf{h}^{(t)}\|, \|\mathbf{z}^{(t)} - \mathbf{x}^{(t)}\|, \|\mathbf{x}^{(t)} - \mathbf{x}^{(t+1)}\|\} \leq \tau_2$, output $\mathbf{x}^* = \mathbf{x}^{(t+1)}$ and terminate the inner loop. Otherwise, go to Step 2.
    3. The solution $\mathbf{s}^{(q)}$ to the convex QCQP subproblem $\mathcal{P}_{\mathbf{s}}^{(q)}$ is obtained from $\mathbf{x}^*$.

The proposed S-ADMM algorithm ensures that the objective value $f_0(\mathbf{s}^{(q)})$ monotonically decreases and converges to a finite value. Additionally, the solution $\mathbf{s}^*$ obtained satisfies the Karush-Kuhn-Tucker (KKT) conditions of the original non-convex problem $\mathcal{P}_1$.