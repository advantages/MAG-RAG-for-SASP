2024-05-06 23:39:22.926194

### System Model
- **Problem Type:** Direction-of-Arrival (DoA) estimation of narrowband far-field point sources impinging on a uniform linear array (ULA) of sensors.
- **Problem Description:** The goal is to estimate the directions-of-arrival (DoAs) of multiple narrowband signals impinging on a ULA of sensors. The key challenge is to accurately estimate the DoAs in the presence of coherent signals, which can cause rank loss in the spatial covariance matrix and degrade the performance of conventional DoA estimation techniques.
- **System Model Parameters:**
  - $M$: Number of sensors in the ULA
  - $K$: Total number of signals impinging on the array
  - $K_c$: Number of coherent signals
  - $K_u$: Number of uncorrelated signals ($K = K_c + K_u$)
  - $\theta_k$: DoA of the $k$-th signal
  - $s_k(t)$: Complex envelope of the $k$-th signal
  - $\lambda$: Central wavelength of the signals
  - $d$: Spacing between adjacent sensors
  - $n_m(t)$: Additive white noise at the $m$-th sensor
  - $\alpha_k$: Amplitude fading factor of the $k$-th signal
  - $\phi_k$: Phase difference of the $k$-th signal relative to the reference sensor
- **System Model Formulations:** The complex envelope of the signals at the $m$-th sensor can be expressed as:

$$x_m(t) = \sum_{k=1}^{K} s_k(t) \alpha_k e^{j\frac{2\pi}{\lambda}m d \sin(\theta_k) + j\phi_k} + n_m(t)$$

Let $\mathbf{x}(t) = [x_0(t), x_1(t), \ldots, x_{M-1}(t)]^T$ be the array output vector and $\mathbf{s}(t) = [s_1(t), s_2(t), \ldots, s_K(t)]^T$ be the signal vector. Define the steering vector $\mathbf{a}(\theta_k) = [1, e^{j\frac{2\pi}{\lambda}d \sin(\theta_k)}, \ldots, e^{j\frac{2\pi}{\lambda}(M-1)d \sin(\theta_k)}]^T$. Then, the array output can be modeled as:

$$\mathbf{x}(t) = \mathbf{A}(\theta)\mathbf{s}(t) + \mathbf{n}(t)$$

where $\mathbf{A}(\theta) = [\mathbf{a}(\theta_1), \mathbf{a}(\theta_2), \ldots, \mathbf{a}(\theta_K)]$ is the Vandermonde matrix containing the DoA information, and $\mathbf{n}(t)$ is the noise vector.

### Optimization Formulation
- **Optimization Type:** Subspace-based DoA estimation using the ESPRIT algorithm.
- **Optimization Parameters:**
  - $\mathbf{R}$: Covariance matrix of the array output, $\mathbf{R} = \mathbb{E}[\mathbf{x}(t)\mathbf{x}^H(t)]$
  - $\sigma_n^2$: Noise power
  - $\mathbf{T}$: Toeplitz matrix reconstructed from $\mathbf{R}$
  - $\mathbf{U}_s$: Signal subspace eigenvectors of $\mathbf{T}$
  - $\mathbf{U}_n$: Noise subspace eigenvectors of $\mathbf{T}$
- **Optimization Variables:** The DoAs $\theta_1, \theta_2, \ldots, \theta_K$.
- **Objective:** Estimate the DoAs $\theta_1, \theta_2, \ldots, \theta_K$ from the signal subspace eigenvectors $\mathbf{U}_s$.
- **Constraints:** The DoAs must satisfy the physical constraints imposed by the array geometry and the propagation environment.

### Optimization Algorithm
- **Algorithm Type:** Improved ESPRIT algorithm.
- **Algorithm Parameters:**
  - $\mathbf{U}_1$: Submatrix of $\mathbf{U}_s$ formed by the first $(M-1)$ rows
  - $\mathbf{U}_2$: Submatrix of $\mathbf{U}_s$ formed by the last $(M-1)$ rows
  - $\boldsymbol{\Phi}$: Diagonal matrix containing the eigenvalues of the rotation matrix $\boldsymbol{\Psi}$
- **Algorithm Steps:**
  1. Construct the Toeplitz matrix $\mathbf{T}$ from the covariance matrix $\mathbf{R}$ using Eq. (7) in the paper.
  2. Perform eigenvalue decomposition of $\mathbf{T}$ to obtain the signal subspace eigenvectors $\mathbf{U}_s$ and noise subspace eigenvectors $\mathbf{U}_n$.
  3. Partition $\mathbf{U}_s$ into $\mathbf{U}_1$ and $\mathbf{U}_2$.
  4. Compute the rotation matrix $\boldsymbol{\Psi}$ using the least-squares solution:
     $$\boldsymbol{\Psi} = (\mathbf{U}_1^H\mathbf{U}_1)^{-1}\mathbf{U}_1^H\mathbf{U}_2$$
  5. Compute the eigenvalues of $\boldsymbol{\Psi}$, which are the diagonal elements of $\boldsymbol{\Phi}$.
  6. Estimate the DoAs $\theta_k$ from the eigenvalues $\phi_k$ of $\boldsymbol{\Phi}$ using:
     $$\theta_k = \sin^{-1}\left(\frac{\lambda}{2\pi d}\angle\phi_k\right)$$
  7. Optionally, average the DoA estimates obtained from different rows of $\mathbf{T}$ to improve robustness.

To compare the estimation accuracy for different values of $K$, the algorithm can be run with varying values of $K$ and the corresponding root-mean-square error (RMSE) of the DoA estimates can be computed and compared.