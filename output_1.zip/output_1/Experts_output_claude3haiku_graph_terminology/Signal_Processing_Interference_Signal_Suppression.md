2024-05-06 23:39:22.926194

### System Model

**Problem Type:** Sensor array signal processing for maximizing the signal-to-interference plus noise ratio (SINR) at the beamform output.

**Problem Description:** The objective is to design the optimal array weight vector that maximizes the SINR at the beamformer output, given a uniform linear array with $N$ elements and an array spacing of half a wavelength. There exists a signal source in space that continuously emits a signal at an angle of $\Theta$, and there are $P$ interference sources continuously emitting signals from angles $\Phi_p$ (where $p=1,2,3,...,P$).

**System Model Parameters:**
- $N$: Number of array elements in the uniform linear array
- $\Theta$: Angle of the desired signal source
- $\Phi_p$: Angles of the $P$ interference sources, where $p=1,2,3,...,P$
- $\mathbf{a}(\Theta)$: $N$-dimensional steering vector of the desired signal source
- $\mathbf{a}(\Phi_p)$: $N$-dimensional steering vector of the $p$-th interference source
- $\sigma_s^2$: Variance of the desired signal
- $\sigma_i^2$: Variance of the $p$-th interference signal
- $\sigma_n^2$: Variance of the additive white Gaussian noise

**System Model Formulations:**
The received signal at the array can be expressed as:

$$\mathbf{x} = \sigma_s \mathbf{a}(\Theta) + \sum_{p=1}^P \sigma_i \mathbf{a}(\Phi_p) + \mathbf{n}$$

where $\mathbf{x}$ is the $N$-dimensional received signal vector, $\mathbf{a}(\Theta)$ and $\mathbf{a}(\Phi_p)$ are the steering vectors of the desired signal and the $p$-th interference, respectively, and $\mathbf{n}$ is the additive white Gaussian noise vector.

The output of the beamformer is given by:

$$y = \mathbf{w}^H \mathbf{x}$$

where $\mathbf{w}$ is the $N$-dimensional array weight vector.

The SINR at the beamformer output is defined as:

$$\text{SINR} = \frac{\sigma_s^2 |\mathbf{w}^H \mathbf{a}(\Theta)|^2}{\sum_{p=1}^P \sigma_i^2 |\mathbf{w}^H \mathbf{a}(\Phi_p)|^2 + \sigma_n^2 \|\mathbf{w}\|^2}$$

### Optimization Formulation

**Optimization Type:** The objective is to find the optimal array weight vector $\mathbf{w}$ that maximizes the SINR at the beamformer output.

**Optimization Parameters:**
- $N$: Number of array elements
- $\Theta$: Angle of the desired signal source
- $\Phi_p$: Angles of the $P$ interference sources, where $p=1,2,3,...,P$
- $\sigma_s^2$: Variance of the desired signal
- $\sigma_i^2$: Variance of the $p$-th interference signal
- $\sigma_n^2$: Variance of the additive white Gaussian noise

**Optimization Variables:**
- $\mathbf{w}$: $N$-dimensional array weight vector

**Objective:**
Maximize the SINR at the beamformer output:

$$\max_{\mathbf{w}} \frac{\sigma_s^2 |\mathbf{w}^H \mathbf{a}(\Theta)|^2}{\sum_{p=1}^P \sigma_i^2 |\mathbf{w}^H \mathbf{a}(\Phi_p)|^2 + \sigma_n^2 \|\mathbf{w}\|^2}$$

**Constraints:**
There are no explicit constraints on the array weight vector $\mathbf{w}$. However, it is typically desirable to have a unit-norm constraint, $\|\mathbf{w}\|=1$, to avoid the trivial solution of $\mathbf{w}=\mathbf{0}$.

### Optimization Algorithm

**Algorithm Type:** The optimal array weight vector $\mathbf{w}$ that maximizes the SINR can be obtained using the Linearly Constrained Minimum Variance (LCMV) beamforming approach.

**Algorithm Parameters:**
- $N$: Number of array elements
- $\Theta$: Angle of the desired signal source
- $\Phi_p$: Angles of the $P$ interference sources, where $p=1,2,3,...,P$
- $\sigma_s^2$: Variance of the desired signal
- $\sigma_i^2$: Variance of the $p$-th interference signal
- $\sigma_n^2$: Variance of the additive white Gaussian noise

**Algorithm Steps:**
1. Construct the steering vectors $\mathbf{a}(\Theta)$ and $\mathbf{a}(\Phi_p)$ for the desired signal and interference sources, respectively.
2. Compute the covariance matrix of the received signal:
   $$\mathbf{R} = \sigma_s^2 \mathbf{a}(\Theta)\mathbf{a}^H(\Theta) + \sum_{p=1}^P \sigma_i^2 \mathbf{a}(\Phi_p)\mathbf{a}^H(\Phi_p) + \sigma_n^2 \mathbf{I}$$
3. Formulate the LCMV optimization problem:
   $$\min_{\mathbf{w}} \mathbf{w}^H \mathbf{R} \mathbf{w} \quad \text{subject to} \quad \mathbf{w}^H \mathbf{a}(\Theta) = 1$$
4. Solve the LCMV optimization problem using the method of Lagrange multipliers:
   $$\mathbf{w}_{\text{opt}} = \frac{\mathbf{R}^{-1}\mathbf{a}(\Theta)}{\mathbf{a}^H(\Theta)\mathbf{R}^{-1}\mathbf{a}(\Theta)}$$
5. The optimal SINR at the beamformer output is given by:
   $$\text{SINR}_{\text{opt}} = \frac{\sigma_s^2}{\mathbf{a}^H(\Theta)\mathbf{R}^{-1}\mathbf{a}(\Theta)}$$

The LCMV beamforming algorithm provides the optimal array weight vector $\mathbf{w}_{\text{opt}}$ that maximizes the SINR at the beamformer output, given the desired signal and interference source directions, as well as the signal and noise variances.