2024-06-05 10:06:06.991172

### System Model

- **Problem Type:** Angle-of-Arrival (AOA) based Source Localization
- **Problem Description:** The problem involves localizing an unknown signal source by utilizing bearing angle (AOA) measurements from multiple sensors at known positions. The sensors are capable of measuring the bearing angle of the signal source, potentially with additive Gaussian noise. The objective is to estimate the location of the signal source by effectively combining the noisy AOA measurements from the distributed sensor network.
- **System Model Parameters:**
  - $M$: Number of sensors
  - $\mathbf{p} = [x_s, y_s]^T$: Unknown location of the signal source
  - $\mathbf{s}_i = [x_i, y_i]^T$: Known location of the $i^{th}$ sensor, $i = 1, 2, \ldots, M$
  - $\theta_i$: True bearing angle (AOA) of the source with respect to the $i^{th}$ sensor
  - $\hat{\theta}_i$: Measured bearing angle (AOA) of the source at the $i^{th}$ sensor
  - $\epsilon_i$: Additive Gaussian noise in the AOA measurement at the $i^{th}$ sensor, $\epsilon_i \sim \mathcal{N}(0, \sigma_i^2)$
  - $\sigma_i^2$: Variance of the AOA measurement noise for the $i^{th}$ sensor
- **System Model Formulations:**
  - The true bearing angle (AOA) of the source with respect to the $i^{th}$ sensor is given by:
    $$\theta_i = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)$$
  - The measured bearing angle (AOA) at the $i^{th}$ sensor is modeled as:
    $$\hat{\theta}_i = \theta_i + \epsilon_i$$
  - The vector of measured AOA values from all $M$ sensors is:
    $$\hat{\boldsymbol{\theta}} = [\hat{\theta}_1, \hat{\theta}_2, \ldots, \hat{\theta}_M]^T$$
  - The measurement noise vector is:
    $$\boldsymbol{\epsilon} = [\epsilon_1, \epsilon_2, \ldots, \epsilon_M]^T$$
  - The covariance matrix of the measurement noise vector is:
    $$\mathbf{Q} = \mathrm{diag}(\sigma_1^2, \sigma_2^2, \ldots, \sigma_M^2)$$

### Optimization Formulation

- **Optimization Type:** Nonlinear Least Squares Optimization
- **Optimization Parameters:**
  - $\mathbf{p} = [x_s, y_s]^T$: Unknown location of the signal source
  - $\mathbf{s}_i = [x_i, y_i]^T$: Known location of the $i^{th}$ sensor, $i = 1, 2, \ldots, M$
  - $\hat{\boldsymbol{\theta}} = [\hat{\theta}_1, \hat{\theta}_2, \ldots, \hat{\theta}_M]^T$: Vector of measured AOA values
  - $\mathbf{Q} = \mathrm{diag}(\sigma_1^2, \sigma_2^2, \ldots, \sigma_M^2)$: Covariance matrix of the measurement noise
- **Optimization Variables:** $\mathbf{p} = [x_s, y_s]^T$: The unknown location of the signal source
- **Objective:** The objective is to minimize the weighted least squares error between the measured AOA values and the predicted AOA values based on the estimated source location:
  $$\min_{\mathbf{p}} J(\mathbf{p}) = \frac{1}{2} \left\|\mathbf{Q}^{-\frac{1}{2}}(\hat{\boldsymbol{\theta}} - \boldsymbol{\theta}(\mathbf{p}))\right\|_2^2$$
  where $\boldsymbol{\theta}(\mathbf{p}) = [\theta_1(\mathbf{p}), \theta_2(\mathbf{p}), \ldots, \theta_M(\mathbf{p})]^T$, and $\theta_i(\mathbf{p}) = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)$.
- **Constraints:** There are no explicit constraints on the optimization variables in this formulation. However, the estimated source location should be within the feasible region covered by the sensor network.

### Optimization Algorithm

- **Algorithm Type:** Gauss-Newton Algorithm
- **Algorithm Parameters:**
  - $\mathbf{p}_0$: Initial estimate of the source location
  - $\epsilon_\mathrm{tol}$: Tolerance for the termination criterion based on the Euclidean norm of the residual vector
  - $k_\mathrm{max}$: Maximum number of iterations
- **Algorithm Steps:**
  1. Initialize the source location estimate $\mathbf{p}_k = \mathbf{p}_0$ and set the iteration index $k = 0$.
  2. Compute the residual vector $\mathbf{r}_k = \mathbf{Q}^{-\frac{1}{2}}(\hat{\boldsymbol{\theta}} - \boldsymbol{\theta}(\mathbf{p}_k))$.
  3. Compute the Jacobian matrix $\mathbf{J}_k = \left[\frac{\partial\boldsymbol{\theta}(\mathbf{p}_k)}{\partial\mathbf{p}}\right]$, where the $(i, j)^{th}$ element is given by:
    $$\left[\frac{\partial\boldsymbol{\theta}(\mathbf{p}_k)}{\partial\mathbf{p}}\right]_{ij} = \frac{\partial\theta_i(\mathbf{p}_k)}{\partial p_j} = \frac{y_i - y_s}{(x_i - x_s)^2 + (y_i - y_s)^2}\delta_{j1} - \frac{x_i - x_s}{(x_i - x_s)^2 + (y_i - y_s)^2}\delta_{j2}$$
    where $\delta_{ij}$ is the Kronecker delta function.
  4. Compute the Gauss-Newton update direction $\Delta\mathbf{p}_k$ by solving the normal equations:
    $$\left(\mathbf{J}_k^T\mathbf{Q}^{-1}\mathbf{J}_k\right)\Delta\mathbf{p}_k = -\mathbf{J}_k^T\mathbf{Q}^{-1}\mathbf{r}_k$$
  5. Update the source location estimate:
    $$\mathbf{p}_{k+1} = \mathbf{p}_k + \Delta\mathbf{p}_k$$
  6. Check the termination criterion based on the Euclidean norm of the residual vector:
    $$\|\mathbf{r}_{k+1}\|_2 < \epsilon_\mathrm{tol}$$
    If the criterion is met or the maximum number of iterations $k_\mathrm{max}$ is reached, terminate the algorithm and return the final estimate $\mathbf{p}_{k+1}$. Otherwise, increment $k$ and go to step 2.

The Gauss-Newton algorithm is an iterative method that linearizes the nonlinear least squares problem around the current estimate and solves the resulting linear system to obtain an update direction. The algorithm iterates until convergence or until a maximum number of iterations is reached.