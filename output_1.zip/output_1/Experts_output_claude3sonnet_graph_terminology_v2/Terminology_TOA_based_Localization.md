2024-06-05 10:06:06.991172

./output_202405/Extractor_output/sonnet_final/all_output_list_V2/extractor_Optimal sensor placement for time difference of arrival localization.md      0.6770099261413096
./output_202405/Extractor_output/sonnet_final/all_output_list_V2/extractor_Optimal_AOA_Sensor-Source_Geometry_With_Deployment_Region_Constraints.md      0.6511615450368138
./output_202405/Extractor_output/sonnet_final/all_output_list_V2/extractor_Optimal TDOA sensor-pair placement with uncertainty in source location.md      0.6287477784684805
