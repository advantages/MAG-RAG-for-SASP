2024-06-05 10:06:06.991172

### System Model
- **Problem Type:** Sensor array signal processing for maximizing signal-to-interference-plus-noise ratio (SINR) in the presence of interference sources.
- **Problem Description:** Consider a uniform linear array (ULA) containing $N$ array elements with an array spacing of half a wavelength. There exists a desired signal source in space that continuously emits a signal at an angle $\theta$. Additionally, there are $P$ interference sources continuously emitting signals from angles $\phi_p$ ($p=1,2,3,...P$). The objective is to determine the optimal array weight vector that maximizes the SINR at the beamformer output.
- **System Model Parameters:**
    - $N$: Number of array elements in the ULA
    - $\theta$: Direction of arrival (DOA) of the desired signal source
    - $P$: Number of interference sources
    - $\phi_p$: DOA of the $p$-th interference source
    - $\sigma_n^2$: Noise power
    - $s_d(t)$: Desired signal waveform
    - $s_i^{(p)}(t)$: Waveform of the $p$-th interference source
    - $\mathbf{a}(\theta)$: Steering vector of the array towards the desired signal direction $\theta$
    - $\mathbf{a}(\phi_p)$: Steering vector of the array towards the direction $\phi_p$ of the $p$-th interference source
- **System Model Formulations:**
The array output vector $\mathbf{y}(t)$ at time $t$ can be expressed as:

$$\mathbf{y}(t) = \mathbf{a}(\theta) s_d(t) + \sum_{p=1}^P \mathbf{a}(\phi_p) s_i^{(p)}(t) + \mathbf{n}(t)$$

where $\mathbf{n}(t)$ is the additive white Gaussian noise vector with covariance $\sigma_n^2 \mathbf{I}_N$, and $\mathbf{I}_N$ is the $N \times N$ identity matrix.

The beamformer output $z(t)$ is given by:

$$z(t) = \mathbf{w}^H \mathbf{y}(t)$$

where $\mathbf{w}$ is the $N \times 1$ complex weight vector applied to the array output.

The SINR at the beamformer output can be expressed as:

$$\text{SINR} = \frac{|\mathbf{w}^H \mathbf{a}(\theta)|^2 \sigma_d^2}{\mathbf{w}^H \left(\sum_{p=1}^P \sigma_i^{(p)2} \mathbf{a}(\phi_p) \mathbf{a}^H(\phi_p) + \sigma_n^2 \mathbf{I}_N\right) \mathbf{w}}$$

where $\sigma_d^2$ and $\sigma_i^{(p)2}$ are the powers of the desired signal and the $p$-th interference signal, respectively.

### Optimization Formulation
- **Optimization Type:** Non-convex optimization problem for maximizing the SINR at the beamformer output.
- **Optimization Parameters:**
    - $\mathbf{a}(\theta)$: Steering vector of the array towards the desired signal direction $\theta$
    - $\{\mathbf{a}(\phi_p)\}_{p=1}^P$: Steering vectors of the array towards the interference directions $\{\phi_p\}_{p=1}^P$
    - $\sigma_d^2$: Power of the desired signal
    - $\{\sigma_i^{(p)2}\}_{p=1}^P$: Powers of the interference signals
    - $\sigma_n^2$: Noise power
- **Optimization Variables:** $\mathbf{w}$: $N \times 1$ complex weight vector applied to the array output.
- **Objective:** Maximize the SINR at the beamformer output:

$$\max_{\mathbf{w}} \frac{|\mathbf{w}^H \mathbf{a}(\theta)|^2 \sigma_d^2}{\mathbf{w}^H \left(\sum_{p=1}^P \sigma_i^{(p)2} \mathbf{a}(\phi_p) \mathbf{a}^H(\phi_p) + \sigma_n^2 \mathbf{I}_N\right) \mathbf{w}}$$

- **Constraints:** $\|\mathbf{w}\|_2 = 1$ (Unit-norm constraint on the weight vector)

### Optimization Algorithm
- **Algorithm Type:** Semidefinite relaxation (SDR) with randomization.
- **Algorithm Parameters:**
    - $\epsilon$: Tolerance for the SDR solution accuracy
    - $N_{\text{rand}}$: Number of randomization trials for rank-one approximation
- **Algorithm Steps:**
1. Convert the non-convex SINR maximization problem into a convex semidefinite program (SDP) by introducing a positive semidefinite matrix variable $\mathbf{W} = \mathbf{w} \mathbf{w}^H$:

$$\begin{aligned}
\max_{\mathbf{W}} \quad & \frac{\sigma_d^2 \mathbf{a}^H(\theta) \mathbf{W} \mathbf{a}(\theta)}{\text{tr}\left(\left(\sum_{p=1}^P \sigma_i^{(p)2} \mathbf{a}(\phi_p) \mathbf{a}^H(\phi_p) + \sigma_n^2 \mathbf{I}_N\right) \mathbf{W}\right)} \\
\text{s.t.} \quad & \mathbf{W} \succeq 0 \\
& \text{tr}(\mathbf{W}) = 1
\end{aligned}$$

2. Solve the SDP using an interior-point method or other convex optimization solvers to obtain the optimal solution $\mathbf{W}^*$.
3. Check the rank of $\mathbf{W}^*$:
    - If $\text{rank}(\mathbf{W}^*) = 1$, extract the optimal weight vector as $\mathbf{w}^* = \sqrt{N} \mathbf{u}_1$, where $\mathbf{u}_1$ is the principal eigenvector of $\mathbf{W}^*$.
    - If $\text{rank}(\mathbf{W}^*) > 1$, proceed to the randomization step.
4. Randomization step:
    - For $k = 1, \ldots, N_{\text{rand}}$:
        1. Generate a random vector $\mathbf{v}_k \sim \mathcal{CN}(\mathbf{0}, \mathbf{I}_N)$.
        2. Compute $\mathbf{w}_k = \mathbf{W}^* \mathbf{v}_k / \|\mathbf{W}^* \mathbf{v}_k\|_2$.
        3. Evaluate the SINR achieved by $\mathbf{w}_k$, denoted as $\text{SINR}_k$.
    - Select the weight vector $\mathbf{w}^*$ that yields the maximum SINR among $\{\mathbf{w}_k\}_{k=1}^{N_{\text{rand}}}$.
5. If $\max_{k} \text{SINR}_k \geq (1 - \epsilon) \text{SINR}^*$, where $\text{SINR}^*$ is the optimal SINR obtained from the SDP solution, terminate the algorithm. Otherwise, increase $N_{\text{rand}}$ and repeat step 4.

The SDR approach provides a tight approximation to the non-convex SINR maximization problem by relaxing the rank constraint on the weight vector matrix. The randomization step aims to obtain a rank-one approximation of the optimal solution, which corresponds to the optimal weight vector. The algorithm parameters, such as the tolerance $\epsilon$ and the number of randomization trials $N_{\text{rand}}$, can be tuned to balance the solution accuracy and computational complexity.