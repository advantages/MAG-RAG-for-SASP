2024-06-05 10:06:06.991172

### System Model

- **Problem Type:** Time-Difference-of-Arrival (TDOA) and Frequency-Difference-of-Arrival (FDOA) based Source Localization
- **Problem Description:** The problem involves localizing a single source emitting a signal by jointly processing time-difference-of-arrival (TDOA) and frequency-difference-of-arrival (FDOA) measurements obtained from an array of spatially distributed sensors. The objective is to estimate the source position and velocity by optimally combining the TDOA and FDOA measurements.
- **System Model Parameters:**
  - $\mathbf{p} \in \mathbb{R}^3$: Position vector of the source
  - $\mathbf{v} \in \mathbb{R}^3$: Velocity vector of the source
  - $\mathbf{q}_i \in \mathbb{R}^3$: Position vector of the $i^{th}$ sensor ($i = 1, 2, \ldots, M$)
  - $M$: Number of sensors
  - $c$: Propagation speed of the signal
  - $f_0$: Carrier frequency of the signal
  - $\tau_{ij}$: TDOA measurement between sensors $i$ and $j$
  - $\nu_{ij}$: FDOA measurement between sensors $i$ and $j$
  - $\mathbf{n}_{\tau}$: TDOA measurement noise vector
  - $\mathbf{n}_{\nu}$: FDOA measurement noise vector
- **System Model Formulations:**
  - $\tau_{ij} = \frac{1}{c}(\|\mathbf{p} - \mathbf{q}_i\| - \|\mathbf{p} - \mathbf{q}_j\|) + n_{\tau_{ij}}$
  - $\nu_{ij} = \frac{f_0}{c}(\mathbf{v}^T(\mathbf{q}_i - \mathbf{q}_j)) + n_{\nu_{ij}}$
  - $\mathbf{h}_{\tau}(\mathbf{p}, \mathbf{q}) = [\tau_{ij}]_{(i, j) \in \mathcal{I}_{\tau}}$: TDOA measurement vector
  - $\mathbf{h}_{\nu}(\mathbf{p}, \mathbf{v}, \mathbf{q}) = [\nu_{ij}]_{(i, j) \in \mathcal{I}_{\nu}}$: FDOA measurement vector
  - $\mathcal{I}_{\tau}$: Set of sensor pairs for TDOA measurements
  - $\mathcal{I}_{\nu}$: Set of sensor pairs for FDOA measurements

The TDOA measurements are functions of the source position $\mathbf{p}$ and sensor positions $\mathbf{q}$, while the FDOA measurements depend on the source position $\mathbf{p}$, velocity $\mathbf{v}$, and sensor positions $\mathbf{q}$. The measurement vectors $\mathbf{h}_{\tau}$ and $\mathbf{h}_{\nu}$ are formed by stacking the TDOA and FDOA measurements for the selected sensor pairs.

### Optimization Formulation

- **Optimization Type:** Joint Maximum Likelihood Estimation (MLE) of source position and velocity
- **Optimization Parameters:**
  - $\mathbf{h}_{\tau}(\mathbf{p}, \mathbf{q})$: TDOA measurement vector
  - $\mathbf{h}_{\nu}(\mathbf{p}, \mathbf{v}, \mathbf{q})$: FDOA measurement vector
  - $\mathbf{C}_{\tau}$: Covariance matrix of TDOA measurement noise
  - $\mathbf{C}_{\nu}$: Covariance matrix of FDOA measurement noise
- **Optimization Variables:** Source position $\mathbf{p}$ and velocity $\mathbf{v}$
- **Objective:** Maximize the joint log-likelihood function of TDOA and FDOA measurements:
  $$\mathcal{L}(\mathbf{p}, \mathbf{v}) = -\frac{1}{2}\left[\left(\boldsymbol{\tau} - \mathbf{h}_{\tau}(\mathbf{p}, \mathbf{q})\right)^T\mathbf{C}_{\tau}^{-1}\left(\boldsymbol{\tau} - \mathbf{h}_{\tau}(\mathbf{p}, \mathbf{q})\right) + \left(\boldsymbol{\nu} - \mathbf{h}_{\nu}(\mathbf{p}, \mathbf{v}, \mathbf{q})\right)^T\mathbf{C}_{\nu}^{-1}\left(\boldsymbol{\nu} - \mathbf{h}_{\nu}(\mathbf{p}, \mathbf{v}, \mathbf{q})\right)\right] + \text{const.}$$
- **Constraints:** No explicit constraints on the source position and velocity.

### Optimization Algorithm

- **Algorithm Type:** Iterative Gauss-Newton algorithm
- **Algorithm Parameters:**
  - $\boldsymbol{\tau}$: Vector of TDOA measurements
  - $\boldsymbol{\nu}$: Vector of FDOA measurements
  - $\mathbf{C}_{\tau}$: Covariance matrix of TDOA measurement noise
  - $\mathbf{C}_{\nu}$: Covariance matrix of FDOA measurement noise
  - $\mathbf{p}^{(0)}$: Initial estimate of source position
  - $\mathbf{v}^{(0)}$: Initial estimate of source velocity
  - $\epsilon$: Convergence threshold
  - $k_{\max}$: Maximum number of iterations
- **Algorithm Steps:**
  1. Initialize $\mathbf{p}^{(0)}$ and $\mathbf{v}^{(0)}$ with initial estimates.
  2. For $k = 0, 1, 2, \ldots, k_{\max}$:
     a. Compute the Jacobian matrices:
        $$\mathbf{J}_{\tau}^{(k)} = \left[\frac{\partial \mathbf{h}_{\tau}}{\partial \mathbf{p}}\right]_{\mathbf{p}^{(k)}, \mathbf{q}}, \quad \mathbf{J}_{\nu}^{(k)} = \left[\frac{\partial \mathbf{h}_{\nu}}{\partial \mathbf{p}}, \frac{\partial \mathbf{h}_{\nu}}{\partial \mathbf{v}}\right]_{\mathbf{p}^{(k)}, \mathbf{v}^{(k)}, \mathbf{q}}$$
     b. Construct the joint measurement Jacobian matrix:
        $$\mathbf{J}^{(k)} = \begin{bmatrix} \mathbf{J}_{\tau}^{(k)} \\ \mathbf{J}_{\nu}^{(k)} \end{bmatrix}$$
     c. Compute the weighted residual vector:
        $$\mathbf{r}^{(k)} = \begin{bmatrix} \mathbf{C}_{\tau}^{-\frac{1}{2}}(\boldsymbol{\tau} - \mathbf{h}_{\tau}(\mathbf{p}^{(k)}, \mathbf{q})) \\ \mathbf{C}_{\nu}^{-\frac{1}{2}}(\boldsymbol{\nu} - \mathbf{h}_{\nu}(\mathbf{p}^{(k)}, \mathbf{v}^{(k)}, \mathbf{q})) \end{bmatrix}$$
     d. Solve the normal equations for the update vector $\boldsymbol{\delta}^{(k)}$:
        $$\left(\mathbf{J}^{(k)T}\mathbf{J}^{(k)}\right)\boldsymbol{\delta}^{(k)} = \mathbf{J}^{(k)T}\mathbf{r}^{(k)}$$
     e. Update the source position and velocity estimates:
        $$\mathbf{p}^{(k+1)} = \mathbf{p}^{(k)} + \boldsymbol{\delta}_{\mathbf{p}}^{(k)}, \quad \mathbf{v}^{(k+1)} = \mathbf{v}^{(k)} + \boldsymbol{\delta}_{\mathbf{v}}^{(k)}$$
     f. Check the convergence criterion:
        $$\|\boldsymbol{\delta}^{(k)}\| \leq \epsilon$$
        If the criterion is satisfied or $k = k_{\max}$, terminate the algorithm.
  3. The final estimates of the source position and velocity are $\mathbf{p}^{(k+1)}$ and $\mathbf{v}^{(k+1)}$, respectively.

The iterative Gauss-Newton algorithm jointly estimates the source position and velocity by linearizing the TDOA and FDOA measurement equations around the current estimates and solving the normal equations to update the estimates. The algorithm terminates when the update vector falls below a specified threshold or the maximum number of iterations is reached.