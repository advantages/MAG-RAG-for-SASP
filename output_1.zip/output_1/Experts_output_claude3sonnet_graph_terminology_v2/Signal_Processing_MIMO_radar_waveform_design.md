2024-06-05 10:06:06.991172

### System Model

- **Problem Type:** The problem at hand is a narrow-band multiple-input multiple-output (MIMO) radar waveform design for target detection and estimation in the presence of clutter and noise.

- **Problem Description:** The goal is to design the transmit waveforms for a colocated MIMO radar system with $N_T$ transmit antennas and $N_R$ receive antennas, such that the signal-to-interference-plus-noise ratio (SINR) at the output of the MMSE estimator is maximized for target detection and estimation. The system operates in the presence of clutter (unwanted reflections from the environment) and additive noise. The waveforms must be designed while considering practical constraints such as constant modulus and similarity constraints.

- **System Model Parameters:**
  - $N_T$: Number of transmit antennas
  - $N_R$: Number of receive antennas
  - $S \in \mathbb{C}^{N_T \times N}$: Transmit waveform matrix, where $N$ is the number of samples in each waveform
  - $s_n(t)$: Transmitted waveform from the $n^{th}$ antenna, $n = 1, \ldots, N_T$
  - $H_t \in \mathbb{C}^{N_R \times N_T}$: Target scattering matrix (Gaussian distributed with zero mean and covariance $R_t = \mathbb{E}\{H_t^H H_t\}$)
  - $H_c \in \mathbb{C}^{N_R \times N_T}$: Clutter scattering matrix (Gaussian distributed with zero mean and covariance $R_c = \mathbb{E}\{H_c^H H_c\}$)
  - $W \in \mathbb{C}^{N_R \times N}$: Additive white Gaussian noise matrix with power $\sigma^2$

- **System Model Formulations:**
  The received signal model at the radar receiver can be expressed as:
  $$Z = H_t S + H_c S + W$$
  The SINR at the output of the MMSE estimator for the target scattering matrix $H_t$ can be written as:
  $$\mathrm{SINR} = \frac{\mathrm{tr}\left(R_t S \left(S^H (R_t + R_c) S + \sigma^2 N_R I\right)^{-1} S^H R_t\right)}{\mathrm{tr}\left(R_t - R_t S \left(S^H (R_t + R_c) S + \sigma^2 N_R I\right)^{-1} S^H R_t\right)}$$

### Optimization Formulation

- **Optimization Type:** The optimization problem is formulated as a non-convex quadratically constrained quadratic programming (QCQP) problem.

- **Optimization Parameters:**
  - $R_t = \mathbb{E}\{H_t^H H_t\}$: Target covariance matrix
  - $R_c = \mathbb{E}\{H_c^H H_c\}$: Clutter covariance matrix
  - $\sigma^2$: Noise power
  - $\lambda$: Lower bound on the constant modulus constraint
  - $\chi$: Upper bound on the constant modulus constraint
  - $p_1$: Lower bound on the transmit power constraint for each antenna
  - $p_2$: Upper bound on the transmit power constraint for each antenna
  - $e_1$: Lower bound on the total transmit energy constraint
  - $e_2$: Upper bound on the total transmit energy constraint

- **Optimization Variables:** $S \in \mathbb{C}^{N_T \times N}$: Transmit waveform matrix

- **Objective:** Maximize the SINR at the output of the MMSE estimator, which is equivalent to minimizing the MMSE estimation error for the target scattering matrix $H_t$:
  $$\min_S \epsilon_\mathrm{MMSE} = \mathrm{tr}\left(R_t - R_t S \left(S^H (R_t + R_c) S + \sigma^2 N_R I\right)^{-1} S^H R_t\right)$$

- **Constraints:**
  - Constant modulus constraint: $\lambda \leq |s_n(t)| \leq \chi, \forall n = 1, \ldots, N_T, \forall t = 1, \ldots, N$
  - Transmit power constraint: $p_1 \leq \frac{1}{N} \|s_n\|^2 \leq p_2, \forall n = 1, \ldots, N_T$
  - Total transmit energy constraint: $e_1 \leq \mathrm{tr}\{SS^H\} \leq e_2$

### Optimization Algorithm

- **Algorithm Type:** Semi-definite programming (SDP) is a suitable approach to solve the non-convex QCQP problem by transforming it into a convex optimization problem. The SDP formulation involves introducing auxiliary variables and relaxing the non-convex constraints.

- **Algorithm Parameters:**
  - $\Omega = SS^H$: Auxiliary variable representing the transmit signal covariance matrix
  - $X$: Auxiliary variable

- **Algorithm Steps:**
  1. Reformulate the optimization problem as an SDP by introducing auxiliary variables $\Omega$ and $X$:
     $$\begin{aligned}
     \min_{\Omega, X} &\quad \mathrm{tr}\{X\} \\
     \text{subject to} &\quad \begin{bmatrix}
     X & I \\
     I & \frac{1}{\sigma^2 N_R} R_1 \Omega R_1^H + R_2
     \end{bmatrix} \succeq 0 \\
     &\quad \Omega \succeq 0 \\
     &\quad \mathrm{tr}\{\Omega\} = e_2 \\
     &\quad \lambda^2 \leq \Omega_{n,n} \leq \chi^2, \quad \forall n = 1, \ldots, N_T \\
     &\quad p_1 \leq \frac{1}{N} \Omega_{n,n} \leq p_2, \quad \forall n = 1, \ldots, N_T
     \end{aligned}$$
     where $R_1 = R_t^{-1} R_{tc}$, $R_2 = R_t^{-1} R_{tc} R_t^{-1}$, and $R_{tc} = R_t + R_c$.

  2. Solve the SDP problem using numerical methods or specialized solvers to obtain the optimal $\Omega^*$.

  3. Perform a full-rank decomposition on $\Omega^*$ to obtain the optimal transmit waveform matrix $S^*$ such that $S^* {S^*}^H = \Omega^*$.

  4. The optimal MMSE estimate of the target scattering matrix $H_t$ is given by:
     $$\hat{H}_\mathrm{MMSE} = Z \left(S^H (R_t + R_c) S + \sigma^2 N_R I\right)^{-1} S^H R_t$$

The SDP formulation provides a convex relaxation of the original non-convex QCQP problem, and the solution obtained is guaranteed to be a lower bound on the optimal value of the original problem. Additional techniques, such as randomization or iterative methods, may be employed to improve the solution quality if required.