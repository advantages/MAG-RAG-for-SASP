2024-06-05 10:06:06.991172

### System Model

- **Problem Type:** Beamforming for a uniform linear array to match a desired radiation beam pattern.

- **Problem Description:** For a uniform linear array comprising $N$ array elements with half-wavelength spacing, the objective is to determine the transmitted beamforming weights that produce a radiation beam pattern matching the given desired radiation beam pattern amplitudes in various spatial directions.

- **System Model Parameters:**
    - $N$: Number of array elements in the uniform linear array
    - $\lambda$: Wavelength of the signal
    - $d = \lambda/2$: Array element spacing (half-wavelength)
    - $\theta_k$: $k$-th spatial angle of interest, $k = 1, 2, \ldots, K$
    - $P_{\text{desired}}(\theta_k)$: Desired radiation beam pattern amplitude at angle $\theta_k$ (real and non-negative)

- **System Model Formulations:** The array manifold vector for the uniform linear array is given by
  $$\mathbf{a}(\theta) = \left[ 1, e^{-j\pi\sin(\theta)}, e^{-j2\pi\sin(\theta)}, \ldots, e^{-j(N-1)\pi\sin(\theta)} \right]^T$$
  
  The actual radiation beam pattern $P(\theta)$ produced by the array with weight vector $\mathbf{w} = [w_1, w_2, \ldots, w_N]^T$ is
  $$P(\theta) = \mathbf{w}^H \mathbf{a}(\theta) \mathbf{a}^H(\theta) \mathbf{w}$$

### Optimization Formulation

- **Optimization Type:** Weighted least-squares optimization under quadratic constraints (non-convex optimization problem).

- **Optimization Parameters:** $P_{\text{desired}}(\theta_k)$, $k = 1, 2, \ldots, K$ (desired radiation beam pattern amplitudes at the angles of interest).

- **Optimization Variables:** $\mathbf{w} = [w_1, w_2, \ldots, w_N]^T$ (complex beamforming weight vector).

- **Objective:** Minimize the weighted sum of squared errors between the desired and actual radiation beam pattern amplitudes at the angles of interest:
  $$\min_{\mathbf{w}} \sum_{k=1}^K \omega_k \left| P_{\text{desired}}(\theta_k) - \sqrt{\mathbf{w}^H \mathbf{a}(\theta_k) \mathbf{a}^H(\theta_k) \mathbf{w}} \right|^2$$
  where $\omega_k \geq 0$ are user-defined weights to prioritize certain angles over others.

- **Constraints:** Constant modulus constraint on the beamforming weights:
  $$|w_n| = 1, \quad n = 1, 2, \ldots, N$$
  to prevent non-linear distortion in the transmitter power amplifiers.

### Optimization Algorithm

- **Algorithm Type:** Alternating Direction Method of Multipliers (ADMM) algorithm.

- **Algorithm Parameters:**
    - $\rho > 0$: ADMM penalty parameter
    - $\epsilon_{\text{abs}} > 0$: Absolute tolerance for convergence
    - $\epsilon_{\text{rel}} > 0$: Relative tolerance for convergence
    - $N_{\text{max}}$: Maximum number of iterations

- **Algorithm Steps:**
    1) Initialize $\mathbf{w}^0$, $\mathbf{u}^0 = \mathbf{0}$, $k = 0$
    2) While stopping criteria $\left(\|\mathbf{r}^k\|_2 \leq \epsilon_{\text{abs}} \text{ and } \|\mathbf{s}^k\|_2 \leq \epsilon_{\text{rel}} \max(1, \|\mathbf{w}^k\|_2)\right)$ is not satisfied and $k < N_{\text{max}}$:
        a) Update $\mathbf{w}^{k+1}$ by solving the following problem:
           $$\mathbf{w}^{k+1} = \underset{\mathbf{w}}{\operatorname{argmin}} \left\{ \sum_{i=1}^K \omega_i \left| P_{\text{desired}}(\theta_i) - \sqrt{\mathbf{w}^H \mathbf{a}(\theta_i) \mathbf{a}^H(\theta_i) \mathbf{w}} \right|^2 + \frac{\rho}{2} \left\| \mathbf{w} - \mathbf{v}^k \right\|_2^2 \right\}$$
           where $\mathbf{v}^k = \mathbf{w}^k - \mathbf{u}^k$.
        b) Update $\mathbf{u}^{k+1}$ as $\mathbf{u}^{k+1} = \mathbf{u}^k + \mathbf{w}^{k+1} - \mathbf{v}^{k+1}$, where $\mathbf{v}^{k+1} = \text{Proj}_{\mathcal{C}}\left(\mathbf{w}^{k+1} + \mathbf{u}^{k+1}\right)$ and $\mathcal{C} = \left\{ \mathbf{w} \in \mathbb{C}^N : |w_n| = 1, n = 1, \ldots, N \right\}$ is the set of constant modulus vectors.
        c) Compute primal $\mathbf{r}^k$ and dual $\mathbf{s}^k$ residuals.
        d) $k \leftarrow k+1$
    3) Return $\mathbf{w}^k$ as the solution.

The algorithm alternates between minimizing an augmented Lagrangian function with respect to the weight vector $\mathbf{w}$ (step 2a), and updating the Lagrange multipliers $\mathbf{u}$ and projecting onto the constant modulus constraint set $\mathcal{C}$ (step 2b). Convergence is achieved when the primal and dual residuals satisfy the specified tolerances. The solution $\mathbf{w}^k$ yields the beamforming weights that produce a radiation beam pattern approximating the desired pattern amplitudes.