2024-06-05 10:06:06.991172

### System Model

- **Problem Type:** Time-of-Arrival (TOA) Based Source Localization
- **Problem Description:** The problem involves localizing a single signal source by utilizing Time-of-Arrival (TOA) measurements obtained from an array of $M$ spatially distributed sensors. The goal is to estimate the unknown location of the source by processing the noisy TOA measurements collected at each sensor, leveraging their known positions.
- **System Model Parameters:**
  - $p = [x_s, y_s]^T$: Location of the unknown signal source
  - $q_i = [x_i, y_i]^T$: Location of the $i^{th}$ sensor, $i = 1, 2, \ldots, M$
  - $t_0$: Unknown event time when the source emits the signal
  - $\nu$: Propagation speed of the signal (assumed known)
  - $d_i(p, q_i) = \|p - q_i\|$: Distance between the source and the $i^{th}$ sensor
  - $\epsilon_i$: Zero-mean Gaussian noise with variance $\sigma^2$ for the TOA measurement at the $i^{th}$ sensor
  - $\hat{t}_i$: Noisy TOA measurement at the $i^{th}$ sensor
- **System Model Formulations:**
  - $\hat{t}_i = t_0 + \frac{d_i(p, q_i)}{\nu} + \epsilon_i$: Noisy TOA measurement model for the $i^{th}$ sensor
  - $\mathbf{t} = [t_1, t_2, \ldots, t_M]^T$: $(M \times 1)$ vector of true TOA values
  - $\hat{\mathbf{t}} = [\hat{t}_1, \hat{t}_2, \ldots, \hat{t}_M]^T$: $(M \times 1)$ vector of noisy TOA measurements
  - $\mathbf{n} = [\epsilon_1, \epsilon_2, \ldots, \epsilon_M]^T$: $(M \times 1)$ vector of measurement noise
  - $\hat{\mathbf{t}} = \mathbf{t} + \mathbf{n}$: Vector form of the TOA measurement model
  - $\mathbf{Q} = \sigma^2\mathbf{I}_{M \times M}$: $(M \times M)$ covariance matrix of the measurement noise, assuming independent and identically distributed (i.i.d.) Gaussian noise

### Optimization Formulation

- **Optimization Type:** Maximum Likelihood Estimation (MLE)
- **Optimization Parameters:**
  - $\hat{\mathbf{t}}$: $(M \times 1)$ vector of noisy TOA measurements
  - $\mathbf{Q}$: $(M \times M)$ covariance matrix of the measurement noise
  - $q_i$: Location of the $i^{th}$ sensor, $i = 1, 2, \ldots, M$
  - $\nu$: Propagation speed of the signal
- **Optimization Variables:** $p = [x_s, y_s]^T$: Location of the unknown signal source
- **Objective:** Maximize the log-likelihood function $\mathcal{L}(p)$ with respect to the source location $p$:
  $$\max_{p} \mathcal{L}(p) = \max_{p} \left[-\frac{1}{2}(\hat{\mathbf{t}} - \mathbf{t}(p))^T \mathbf{Q}^{-1} (\hat{\mathbf{t}} - \mathbf{t}(p)) - \frac{M}{2}\log(2\pi) - \frac{1}{2}\log|\mathbf{Q}|\right]$$
  where $\mathbf{t}(p) = [t_0 + \frac{d_1(p, q_1)}{\nu}, t_0 + \frac{d_2(p, q_2)}{\nu}, \ldots, t_0 + \frac{d_M(p, q_M)}{\nu}]^T$ is the $(M \times 1)$ vector of true TOA values as a function of the source location $p$.
- **Constraints:** The source location $p$ must be within the region of interest defined by the sensor array geometry.

### Optimization Algorithm

- **Algorithm Type:** Iterative Nonlinear Least Squares (NLS) Estimation
- **Algorithm Parameters:**
  - $p^{(0)}$: Initial estimate of the source location
  - $\epsilon_{tol}$: Tolerance for the convergence criterion
  - $k_{\max}$: Maximum number of iterations
- **Algorithm Steps:**
  1. Initialize the source location estimate $\hat{p}^{(0)} = p^{(0)}$.
  2. For $k = 0, 1, 2, \ldots, k_{\max}$:
     a. Compute the residual vector $\mathbf{r}(\hat{p}^{(k)}) = \hat{\mathbf{t}} - \mathbf{t}(\hat{p}^{(k)})$.
     b. Compute the Jacobian matrix $\mathbf{J}(\hat{p}^{(k)}) = \frac{\partial \mathbf{t}(\hat{p}^{(k)})}{\partial \hat{p}^{(k)}}$.
     c. Solve the linear least squares problem:
        $$\Delta\hat{p}^{(k)} = \arg\min_{\Delta p} \|\mathbf{r}(\hat{p}^{(k)}) - \mathbf{J}(\hat{p}^{(k)})\Delta p\|^2$$
        to obtain the update $\Delta\hat{p}^{(k)}$.
     d. Update the source location estimate: $\hat{p}^{(k+1)} = \hat{p}^{(k)} + \Delta\hat{p}^{(k)}$.
     e. If $\|\Delta\hat{p}^{(k)}\| < \epsilon_{tol}$, terminate the algorithm and return $\hat{p}^{(k+1)}$ as the final estimate of the source location.
  3. If the maximum number of iterations $k_{\max}$ is reached without convergence, terminate the algorithm and return the last estimate $\hat{p}^{(k_{\max}+1)}$.

The iterative NLS algorithm iteratively refines the source location estimate by minimizing the squared residual between the observed TOA measurements and the predicted TOA values based on the current estimate. The algorithm terminates when the update in the source location estimate is smaller than a predefined tolerance or when the maximum number of iterations is reached.