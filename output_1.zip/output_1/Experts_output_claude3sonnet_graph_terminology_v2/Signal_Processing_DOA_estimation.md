2024-06-05 10:06:06.991172

Certainly, I will follow the outlined methodology to formulate and solve the signal processing problem you've presented.

### System Model

- **Problem Type:** Direction-of-Arrival (DOA) estimation of a signal source using a uniform linear array (ULA) of sensors.

- **Problem Description:** Given a uniform linear array containing $N$ array elements with an array spacing of half a wavelength, there exists a signal source in space that continuously emits a signal from angle $\Theta$ relative to the array. The goal is to estimate the angle $\Theta$ accurately and efficiently using the sampled signals received at the array elements.

- **System Model Parameters:**
    - $N$: Number of array elements in the ULA
    - $\lambda$: Wavelength of the signal
    - $d = \lambda/2$: Spacing between adjacent array elements
    - $\Theta$: Angle of the signal source relative to the array
    - $s(t)$: Complex envelope of the signal emitted by the source
    - $x_n(t)$: Received signal at the $n$-th array element
    - $n_n(t)$: Additive white Gaussian noise at the $n$-th array element
    - $K$: Number of sampled signal snapshots

- **System Model Formulations:**
    - The received signal at the $n$-th array element can be expressed as:
        $$x_n(t) = s(t) e^{j\frac{2\pi}{\lambda}nd\sin(\Theta)} + n_n(t)$$
    - The array output vector at time $t$ can be written as:
        $$\mathbf{x}(t) = [x_0(t), x_1(t), \ldots, x_{N-1}(t)]^T = s(t)\mathbf{a}(\Theta) + \mathbf{n}(t)$$
        where $\mathbf{a}(\Theta) = [1, e^{j\frac{2\pi}{\lambda}d\sin(\Theta)}, \ldots, e^{j\frac{2\pi}{\lambda}(N-1)d\sin(\Theta)}]^T$ is the steering vector, and $\mathbf{n}(t) = [n_0(t), n_1(t), \ldots, n_{N-1}(t)]^T$ is the noise vector.
    - The covariance matrix of the array output is given by:
        $$\mathbf{R} = \mathbb{E}\{\mathbf{x}(t)\mathbf{x}^H(t)\} = \sigma_s^2\mathbf{a}(\Theta)\mathbf{a}^H(\Theta) + \sigma_n^2\mathbf{I}_N$$
        where $\sigma_s^2$ and $\sigma_n^2$ are the signal and noise powers, respectively, and $\mathbf{I}_N$ is the $N\times N$ identity matrix.

### Optimization Formulation

- **Optimization Type:** Subspace-based DOA estimation.

- **Optimization Parameters:**
    - $\hat{\mathbf{R}}$: Sample covariance matrix estimated from $K$ snapshots of array output
    - $\mathbf{U}_s$: Signal subspace eigenvectors of $\hat{\mathbf{R}}$
    - $\mathbf{U}_n$: Noise subspace eigenvectors of $\hat{\mathbf{R}}$

- **Optimization Variables:** $\Theta$, the angle of the signal source.

- **Objective:** Minimize the cost function:
    $$J(\Theta) = \frac{\mathbf{a}^H(\Theta)\mathbf{U}_n\mathbf{U}_n^H\mathbf{a}(\Theta)}{\mathbf{a}^H(\Theta)\mathbf{a}(\Theta)}$$
    The cost function $J(\Theta)$ is the projection of the steering vector $\mathbf{a}(\Theta)$ onto the noise subspace $\mathbf{U}_n$. The objective is to find the $\Theta$ that minimizes $J(\Theta)$, as the true steering vector $\mathbf{a}(\Theta)$ should be orthogonal to the noise subspace.

- **Constraints:** $\Theta \in [-\pi/2, \pi/2]$, as the DOA is restricted to the range of angles visible to the array.

### Optimization Algorithm

- **Algorithm Type:** MUSIC (Multiple Signal Classification) algorithm.

- **Algorithm Parameters:**
    - $K$: Number of signal snapshots used to estimate the covariance matrix
    - $P$: Number of grid points over which the cost function $J(\Theta)$ is evaluated

- **Algorithm Steps:**
    1. Estimate the sample covariance matrix $\hat{\mathbf{R}}$ from $K$ snapshots of the array output:
        $$\hat{\mathbf{R}} = \frac{1}{K}\sum_{t=1}^K \mathbf{x}(t)\mathbf{x}^H(t)$$
    2. Perform eigendecomposition of $\hat{\mathbf{R}}$:
        $$\hat{\mathbf{R}} = \mathbf{U}_s\Lambda_s\mathbf{U}_s^H + \mathbf{U}_n\Lambda_n\mathbf{U}_n^H$$
        where $\mathbf{U}_s$ and $\mathbf{U}_n$ are the signal and noise subspace eigenvectors, respectively, and $\Lambda_s$ and $\Lambda_n$ are the corresponding eigenvalues.
    3. Construct a grid of $P$ angles within the range $[-\pi/2, \pi/2]$.
    4. For each grid point $\Theta_p$, compute the cost function:
        $$J(\Theta_p) = \frac{\mathbf{a}^H(\Theta_p)\mathbf{U}_n\mathbf{U}_n^H\mathbf{a}(\Theta_p)}{\mathbf{a}^H(\Theta_p)\mathbf{a}(\Theta_p)}$$
    5. Identify the grid point $\Theta_\text{est}$ that minimizes the cost function:
        $$\Theta_\text{est} = \argmin_{\Theta_p} J(\Theta_p)$$
        This $\Theta_\text{est}$ is the estimated DOA of the signal source.
    6. Terminate the algorithm.

To analyze the estimation accuracy for different values of $K$, the algorithm can be run multiple times with varying $K$, and the mean-squared error (MSE) or root-mean-squared error (RMSE) of the DOA estimates can be computed and compared across different $K$ values.

The provided system model, optimization formulation, and optimization algorithm address the problem of estimating the angle of the signal source $\Theta$ using a uniform linear array. The MUSIC algorithm exploits the orthogonality between the signal and noise subspaces to estimate the DOA by finding the angle that minimizes the projection of the steering vector onto the noise subspace.