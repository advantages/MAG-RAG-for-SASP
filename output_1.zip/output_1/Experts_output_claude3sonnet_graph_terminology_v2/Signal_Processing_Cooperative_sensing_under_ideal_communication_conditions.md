2024-06-05 10:06:06.991172

### System Model
- **Problem Type:** Distributed antenna array signal detection
- **Problem Description:** Consider a sensor network comprising $p$ distributed antennas tasked with detecting the presence of primary signals. A signal emitter is located somewhere in the space, continuously broadcasting primary signals with limited bandwidth, such as a QPSK modulation signal, which encapsulates segmental information. The objective is to develop an efficient strategy to leverage the distributed antenna array for detecting these primary signals and maximize the utility of the antennas for signal sensing.
- **System Model Parameters:**
    - $p$: Number of distributed antennas in the sensor network
    - $\mathbf{r}_i(t)$: Received signal at the $i$-th antenna at time $t$
    - $s(t)$: Transmitted primary signal from the emitter
    - $\mathbf{a}_i(\theta, \phi)$: Steering vector of the $i$-th antenna towards the direction $(\theta, \phi)$
    - $(\theta_0, \phi_0)$: Direction of the signal emitter
    - $n_i(t)$: Additive white Gaussian noise at the $i$-th antenna
- **System Model Formulations:**
The received signal at the $i$-th antenna can be modeled as:

$$\mathbf{r}_i(t) = \mathbf{a}_i(\theta_0, \phi_0) s(t) + n_i(t)$$

Stacking the received signals from all $p$ antennas, we obtain:

$$\mathbf{r}(t) = \begin{bmatrix} \mathbf{r}_1(t) \\ \mathbf{r}_2(t) \\ \vdots \\ \mathbf{r}_p(t) \end{bmatrix} = \begin{bmatrix} \mathbf{a}_1(\theta_0, \phi_0) \\ \mathbf{a}_2(\theta_0, \phi_0) \\ \vdots \\ \mathbf{a}_p(\theta_0, \phi_0) \end{bmatrix} s(t) + \begin{bmatrix} n_1(t) \\ n_2(t) \\ \vdots \\ n_p(t) \end{bmatrix}$$

$$\mathbf{r}(t) = \mathbf{a}(\theta_0, \phi_0) s(t) + \mathbf{n}(t)$$

Where $\mathbf{a}(\theta_0, \phi_0) = \begin{bmatrix} \mathbf{a}_1(\theta_0, \phi_0) \\ \mathbf{a}_2(\theta_0, \phi_0) \\ \vdots \\ \mathbf{a}_p(\theta_0, \phi_0) \end{bmatrix}$ is the overall steering vector, and $\mathbf{n}(t) = \begin{bmatrix} n_1(t) \\ n_2(t) \\ \vdots \\ n_p(t) \end{bmatrix}$ is the noise vector.

### Optimization Formulation
- **Optimization Type:** Detection theory and array signal processing
- **Optimization Parameters:**
    - $\mathbf{r}(t)$: Received signal vector across all antennas
    - $\mathbf{a}(\theta, \phi)$: Overall steering vector towards direction $(\theta, \phi)$
    - $\sigma_n^2$: Noise variance
- **Optimization Variables:** $\mathbf{w}$: Linear combiner weight vector
- **Objective:** Maximize the signal-to-noise ratio (SNR) of the combined signal, i.e., $\max_{\mathbf{w}} \text{SNR}(\mathbf{w})$
- **Constraints:**
    - $\|\mathbf{w}\|_2 = 1$: Unit norm constraint on the weight vector

### Optimization Algorithm
- **Algorithm Type:** Generalized Likelihood Ratio Test (GLRT)
- **Algorithm Parameters:**
    - $\gamma$: Detection threshold
    - $N$: Number of samples used for estimation
- **Algorithm Steps:**
1. Collect $N$ samples of the received signal vectors $\{\mathbf{r}(t)\}_{t=1}^N$.
2. Estimate the sample covariance matrix $\hat{\mathbf{R}} = \frac{1}{N} \sum_{t=1}^N \mathbf{r}(t) \mathbf{r}^H(t)$.
3. Perform eigenvalue decomposition on $\hat{\mathbf{R}}$: $\hat{\mathbf{R}} = \sum_{i=1}^p \lambda_i \mathbf{u}_i \mathbf{u}_i^H$, where $\lambda_1 \geq \lambda_2 \geq \cdots \geq \lambda_p$ are the eigenvalues, and $\mathbf{u}_i$ are the corresponding eigenvectors.
4. Partition the signal and noise subspaces:
    - Signal subspace: $\mathbf{U}_s = \begin{bmatrix} \mathbf{u}_1 & \mathbf{u}_2 & \cdots & \mathbf{u}_q \end{bmatrix}$
    - Noise subspace: $\mathbf{U}_n = \begin{bmatrix} \mathbf{u}_{q+1} & \mathbf{u}_{q+2} & \cdots & \mathbf{u}_p \end{bmatrix}$
5. Compute the GLRT statistic $T(\mathbf{r}) = \frac{\max_{\theta, \phi} \|\mathbf{U}_s^H \mathbf{a}(\theta, \phi)\|_2^2}{\|\mathbf{U}_n^H \mathbf{a}(\theta, \phi)\|_2^2}$.
6. Set the linear combiner weight vector as the steering vector that maximizes the GLRT statistic: $\mathbf{w} = \arg\max_{\theta, \phi} \|\mathbf{U}_s^H \mathbf{a}(\theta, \phi)\|_2^2$.
7. Declare the presence of a primary signal if $T(\mathbf{r}) > \gamma$, and absence otherwise.

The GLRT algorithm exploits the properties of the signal and noise subspaces to detect the presence of primary signals and estimate their direction of arrival. The weight vector $\mathbf{w}$ is chosen as the steering vector that maximizes the projection onto the signal subspace while minimizing the projection onto the noise subspace, effectively maximizing the SNR.