2024-06-05 10:06:06.991172

### System Model

- **Problem Type:** Two-dimensional (2-D) localization of a signal source using time-of-arrival (TOA) measurements from multiple sensors.

- **Problem Description:** The problem involves estimating the position of a continuously emitting signal source in a 2-D space using a network of $M$ sensors equipped with single antennas. The sensors measure the time of arrival (TOA) of the signal from the source and transmit the received signal samples to a data fusion center. The objective is to estimate the position $(\var{x}, \var{y})$ of the signal source based on the TOA measurements from the distributed sensors.

- **System Model Parameters:**
  - $M$: Number of sensors
  - $(\var{x}_m, \var{y}_m)$: Position of the $m^{th}$ sensor, $m = 1, 2, \ldots, M$
  - $(\var{x}, \var{y})$: Unknown position of the signal source
  - $\var{c}$: Propagation speed of the signal (constant)
  - $\var{t}_m$: True time of arrival of the signal at the $m^{th}$ sensor
  - $\tilde{\var{t}}_m$: Measured time of arrival of the signal at the $m^{th}$ sensor, corrupted by additive white Gaussian noise (AWGN)
  - $\var{n}_m \sim \mathcal{N}(0, \sigma_m^2)$: AWGN process at the $m^{th}$ sensor with zero mean and variance $\sigma_m^2$

- **System Model Formulations:**
  - The true time of arrival $\var{t}_m$ at the $m^{th}$ sensor is given by:
    $$\var{t}_m = \frac{1}{\var{c}} \sqrt{(\var{x} - \var{x}_m)^2 + (\var{y} - \var{y}_m)^2}$$
  - The measured time of arrival $\tilde{\var{t}}_m$ at the $m^{th}$ sensor is modeled as:
    $$\tilde{\var{t}}_m = \var{t}_m + \var{n}_m$$
  - The measured range $\tilde{\var{r}}_m$ corresponding to the TOA measurement $\tilde{\var{t}}_m$ is given by:
    $$\tilde{\var{r}}_m = \var{c} \tilde{\var{t}}_m$$

The goal is to estimate the source position $(\var{x}, \var{y})$ from the set of measured ranges $\{\tilde{\var{r}}_m\}_{m=1}^M$ at the fusion center.

### Optimization Formulation

- **Optimization Type:** Nonlinear least-squares optimization

- **Optimization Parameters:** The optimization parameters include the measured ranges $\{\tilde{\var{r}}_m\}_{m=1}^M$ from the sensors, the sensor positions $\{(\var{x}_m, \var{y}_m)\}_{m=1}^M$, and the noise variances $\{\sigma_m^2\}_{m=1}^M$.

- **Optimization Variables:** The optimization variables are the unknown source position coordinates $(\var{x}, \var{y})$.

- **Objective:** The objective is to minimize the sum of squared residuals between the measured ranges and the true ranges computed from the estimated source position:
  $$\min_{\var{x}, \var{y}} \sum_{m=1}^M \left(\tilde{\var{r}}_m - \sqrt{(\var{x} - \var{x}_m)^2 + (\var{y} - \var{y}_m)^2}\right)^2$$

- **Constraints:** There are no explicit constraints on the optimization variables $(\var{x}, \var{y})$, as the source position is assumed to be unconstrained in the 2-D space.

### Optimization Algorithm

- **Algorithm Type:** Nonlinear least-squares solver, such as the Levenberg-Marquardt algorithm or the Trust-Region-Reflective algorithm.

- **Algorithm Parameters:**
  - Initial guess for the source position $(\var{x}_0, \var{y}_0)$
  - Convergence tolerance for the residual norm and parameter updates
  - Maximum number of iterations
  - Algorithm-specific parameters (e.g., damping factor, trust-region size, etc.)

- **Algorithm Steps:**
  1. Initialize the source position estimate $(\hat{\var{x}}, \hat{\var{y}}) = (\var{x}_0, \var{y}_0)$ with an initial guess.
  2. Compute the residual vector $\vec{r}(\hat{\var{x}}, \hat{\var{y}})$, where the $m^{th}$ element is given by:
     $$r_m(\hat{\var{x}}, \hat{\var{y}}) = \tilde{\var{r}}_m - \sqrt{(\hat{\var{x}} - \var{x}_m)^2 + (\hat{\var{y}} - \var{y}_m)^2}$$
  3. Compute the Jacobian matrix $\mat{J}(\hat{\var{x}}, \hat{\var{y}})$, where the $(m, 1)^{th}$ and $(m, 2)^{th}$ elements are given by:
     $$\frac{\partial r_m}{\partial \hat{\var{x}}} = \frac{\hat{\var{x}} - \var{x}_m}{r_m(\hat{\var{x}}, \hat{\var{y}})}, \quad \frac{\partial r_m}{\partial \hat{\var{y}}} = \frac{\hat{\var{y}} - \var{y}_m}{r_m(\hat{\var{x}}, \hat{\var{y}})}$$
  4. Solve the weighted least-squares subproblem:
     $$\min_{\Delta\var{x}, \Delta\var{y}} \left\|\mat{W}^{1/2}\left(\vec{r}(\hat{\var{x}}, \hat{\var{y}}) - \mat{J}(\hat{\var{x}}, \hat{\var{y}}) \begin{bmatrix} \Delta\var{x} \\ \Delta\var{y} \end{bmatrix}\right)\right\|_2^2$$
     where $\mat{W}$ is a diagonal weight matrix with elements $w_m = 1/\sigma_m^2$, and $\Delta\var{x}$, $\Delta\var{y}$ are the updates to the current source position estimate.
  5. Update the source position estimate: $(\hat{\var{x}}, \hat{\var{y}}) \leftarrow (\hat{\var{x}} + \Delta\var{x}, \hat{\var{y}} + \Delta\var{y})$.
  6. Check the convergence criteria (residual norm, parameter updates). If convergence is achieved or the maximum number of iterations is reached, terminate the algorithm. Otherwise, go to step 2.
  7. The final estimate $(\hat{\var{x}}, \hat{\var{y}})$ represents the estimated position of the signal source.

The algorithm iteratively refines the source position estimate by minimizing the weighted sum of squared residuals between the measured ranges and the ranges computed from the current estimate. The convergence of the algorithm depends on the initial guess, the noise levels, and the sensor geometry.