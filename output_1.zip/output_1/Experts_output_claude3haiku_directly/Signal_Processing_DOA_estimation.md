2024-05-02 10:36:10.367126

# Signal Processing Problem: Angle of Arrival Estimation

## System Model

### Problem Type
The problem at hand is a direction-of-arrival (DOA) estimation problem, which is a fundamental signal processing task in sensor array signal processing.

### Problem Description
Given a uniform linear array (ULA) of `N` sensor elements with a spacing of half a wavelength, the objective is to accurately estimate the angle of arrival (AoA), denoted as `θ`, of a continuously emitting signal source.

### System Model Parameters
- `N`: Number of sensor elements in the ULA
- `θ`: Angle of arrival of the signal source relative to the array
- `K`: Number of sampled signal snapshots

### System Model Formulations
Let the array response vector, also known as the steering vector, be denoted as:

$\mathbf{a}(\theta) = \left[1, e^{-j\frac{2\pi}{\lambda}d\sin(\theta)}, \dots, e^{-j\frac{2\pi}{\lambda}(N-1)d\sin(\theta)}\right]^T$

where `d = λ/2` is the inter-element spacing, and `λ` is the wavelength of the signal.

The received signal at the ULA can be expressed as:

$\mathbf{x}(k) = \mathbf{a}(\theta)s(k) + \mathbf{n}(k)$

where:
- `s(k)` is the complex-valued signal source at the `k`-th time instant
- `\mathbf{n}(k)` is the additive noise vector at the `k`-th time instant, typically assumed to be zero-mean complex Gaussian distributed.

The covariance matrix of the received signal is given by:

$\mathbf{R}_\mathbf{x} = E\left[\mathbf{x}(k)\mathbf{x}^H(k)\right] = \mathbf{a}(\theta)\mathbf{a}^H(\theta)\sigma_s^2 + \sigma_n^2\mathbf{I}$

where:
- `σ_s^2` is the signal power
- `σ_n^2` is the noise power
- `\mathbf{I}` is the identity matrix

## Optimization Formulation

### Optimization Type
The optimization problem in this signal processing task is to estimate the angle of arrival `θ` given the received signal samples `\mathbf{x}(k)` for `k = 1, 2, ..., K`.

### Optimization Parameters
- `N`: Number of sensor elements in the ULA
- `K`: Number of signal snapshots
- `d = λ/2`: Inter-element spacing
- `σ_s^2`: Signal power
- `σ_n^2`: Noise power

### Optimization Variables
The optimization variable is the angle of arrival `θ`, which needs to be estimated.

### Objective
The objective is to estimate the angle of arrival `θ` as accurately as possible. This can be formulated as minimizing the mean-squared error (MSE) between the true angle `θ` and the estimated angle `\hat{\theta}`.

$\min_{\hat{\theta}} E\left[(\theta - \hat{\theta})^2\right]$

### Constraints
There are no explicit constraints in this optimization problem, as the angle of arrival `θ` can take any value within the range `[-π/2, π/2]`.

## Optimization Algorithm

### Algorithm Type
One of the commonly used algorithms for DOA estimation in ULAs is the MUSIC (Multiple Signal Classification) algorithm. MUSIC is a subspace-based method that exploits the orthogonality between the signal and noise subspaces to estimate the angle of arrival.

### Algorithm Parameters
The key parameters for the MUSIC algorithm are:
- Number of signal snapshots `K`
- Threshold for signal and noise subspace separation

### Algorithm Steps
1. Compute the sample covariance matrix of the received signal:
   $\mathbf{R}_\mathbf{x} = \frac{1}{K}\sum_{k=1}^{K}\mathbf{x}(k)\mathbf{x}^H(k)$
2. Perform eigenvalue decomposition of the covariance matrix:
   $\mathbf{R}_\mathbf{x} = \mathbf{U}_s\mathbf{\Lambda}_s\mathbf{U}_s^H + \mathbf{U}_n\mathbf{\Lambda}_n\mathbf{U}_n^H$
   where `\mathbf{U}_s` and `\mathbf{U}_n` are the signal and noise subspace eigenvectors, respectively, and `\mathbf{\Lambda}_s` and `\mathbf{\Lambda}_n` are the corresponding eigenvalues.
3. Compute the MUSIC spectrum:
   $P_\text{MUSIC}(\theta) = \frac{1}{\mathbf{a}^H(\theta)\mathbf{U}_n\mathbf{U}_n^H\mathbf{a}(\theta)}$
4. Find the angle `\hat{\theta}` that corresponds to the maximum of the MUSIC spectrum:
   $\hat{\theta} = \arg\max_\theta P_\text{MUSIC}(\theta)$

By comparing the estimation accuracy for different values of `K`, the tradeoff between the number of signal snapshots and the angle of arrival estimation accuracy can be analyzed.