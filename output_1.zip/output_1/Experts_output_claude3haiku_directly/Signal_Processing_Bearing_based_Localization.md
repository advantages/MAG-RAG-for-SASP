2024-05-02 10:36:10.367126

# Signal Source Localization using Bearing Angle Measurements

## System Model

### Problem Type
The given problem is a sensor array signal processing task, specifically focused on the localization of a signal source using bearing angle measurements from multiple sensors.

### Problem Description
In this problem, we have a set of M sensors located at different positions (x_i, y_i), where i = 1, 2, ..., M. Each sensor can measure the bearing angle of a signal source, which is the angle between the sensor's orientation and the direction of the signal source. However, these bearing angle measurements may be corrupted by additive Gaussian noise. The objective is to utilize these noisy bearing angle measurements from the sensors to estimate the location of the signal source.

### System Model Parameters
- $M$: Number of sensors
- $(x_i, y_i)$: Position of the $i^{th}$ sensor, for $i = 1, 2, \ldots, M$
- $\theta_i$: Bearing angle measured by the $i^{th}$ sensor, which is the angle between the sensor's orientation and the direction of the signal source
- $\sigma_i^2$: Variance of the additive Gaussian noise in the bearing angle measurement of the $i^{th}$ sensor

### System Model Formulations
Let $(x_s, y_s)$ be the unknown location of the signal source. The bearing angle $\theta_i$ measured by the $i^{th}$ sensor can be expressed as:

$$\theta_i = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right) + n_i$$

where $n_i$ is the additive Gaussian noise with zero mean and variance $\sigma_i^2$.

## Optimization Formulation

### Optimization Type
The problem of localizing the signal source using the bearing angle measurements can be formulated as an optimization problem, where the goal is to estimate the location $(x_s, y_s)$ of the signal source.

### Optimization Parameters
- $M$: Number of sensors
- $(x_i, y_i)$: Position of the $i^{th}$ sensor, for $i = 1, 2, \ldots, M$
- $\theta_i$: Bearing angle measured by the $i^{th}$ sensor
- $\sigma_i^2$: Variance of the additive Gaussian noise in the bearing angle measurement of the $i^{th}$ sensor

### Optimization Variables
The optimization variables are the coordinates of the signal source, $(x_s, y_s)$.

### Objective
The objective is to minimize the sum of squared errors between the measured bearing angles $\theta_i$ and the estimated bearing angles based on the hypothesized signal source location $(x_s, y_s)$. This can be formulated as:

$$\min_{x_s, y_s} \sum_{i=1}^M \left(\theta_i - \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)\right)^2$$

### Constraints
There are no explicit constraints in this problem, as the signal source location $(x_s, y_s)$ can be any real-valued coordinates.

## Optimization Algorithm

### Algorithm Type
To solve the optimization problem, we can employ a nonlinear optimization algorithm, such as the Levenberg-Marquardt algorithm or the Gauss-Newton method, which are well-suited for solving least-squares problems.

### Algorithm Parameters
- Initial estimates for the signal source location $(x_s, y_s)$
- Convergence tolerance: the algorithm will terminate when the change in the objective function value is less than the tolerance
- Maximum number of iterations: to ensure the algorithm terminates even if the convergence criterion is not met

### Algorithm Steps
1. Initialize the signal source location estimates $(x_s^{(0)}, y_s^{(0)})$.
2. Iterate until convergence or the maximum number of iterations is reached:
   a. Calculate the estimated bearing angles $\hat{\theta}_i = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)$ for each sensor.
   b. Compute the residuals $r_i = \theta_i - \hat{\theta}_i$ for each sensor.
   c. Compute the Jacobian matrix $\mathbf{J}$ with elements $J_{ij} = \frac{\partial r_i}{\partial x_j}$, where $x_j$ is either $x_s$ or $y_s$.
   d. Compute the update step $\Delta\mathbf{x} = (\mathbf{J}^\top\mathbf{J} + \lambda\mathbf{I})^{-1}\mathbf{J}^\top\mathbf{r}$, where $\mathbf{x} = [x_s, y_s]^\top$, $\mathbf{r} = [r_1, r_2, \ldots, r_M]^\top$, and $\lambda$ is the Levenberg-Marquardt damping factor.
   e. Update the signal source location estimates: $\mathbf{x}^{(k+1)} = \mathbf{x}^{(k)} + \Delta\mathbf{x}$.
3. Return the final estimates of the signal source location $(x_s, y_s)$.

The Levenberg-Marquardt algorithm is an iterative method that combines the Gauss-Newton algorithm and the method of gradient descent. It is effective in solving nonlinear least-squares problems, such as the one presented in this signal source localization problem.