2024-05-02 11:17:41.922786

{System Model}

- **Problem Type:** Time of Arrival (TOA) Based Source Localization

This problem falls under the category of sensor array signal processing, specifically for locating a signal source using time of arrival measurements from multiple sensors.

- **Problem Description:** Given a set of M sensors located at known positions (x_i, y_i) for i = 1, 2, ..., M, the objective is to estimate the location of a signal source by utilizing the time of arrival (TOA) measurements, t_i, obtained at each sensor. The TOA measurements correspond to the propagation time of the signal from the source to the respective sensor. By exploiting the geometric relationships between the source location, sensor positions, and TOA measurements, the source can be localized.

- **System Model Parameters:**
    - M: Number of sensors
    - (x_i, y_i): Position coordinates of the i-th sensor, for i = 1, 2, ..., M
    - t_i: Time of arrival (TOA) measurement at the i-th sensor
    - c: Propagation speed of the signal (e.g., speed of sound or electromagnetic wave)
    - (x_s, y_s): Unknown location coordinates of the signal source

- **System Model Formulations:**
The system model is based on the relationship between the TOA measurements and the distances between the source and sensors. The distance between the source and the i-th sensor, denoted as r_i, can be expressed as:

$$r_i = c \cdot t_i = \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}$$

This equation represents a circle with the i-th sensor as the center and r_i as the radius. The source location lies on the intersection of these circles formed by the TOA measurements from multiple sensors.

{Optimization Formulation}

- **Optimization Type:** Nonlinear Least Squares Optimization

Since the source location estimation involves finding the intersection of multiple circles (defined by the TOA measurements and sensor positions), it can be formulated as a nonlinear least squares optimization problem.

- **Optimization Parameters:**
    - M: Number of sensors
    - (x_i, y_i): Position coordinates of the i-th sensor, for i = 1, 2, ..., M
    - t_i: Time of arrival (TOA) measurement at the i-th sensor
    - c: Propagation speed of the signal

- **Optimization Variables:**
    - (x_s, y_s): Unknown location coordinates of the signal source

- **Objective:**
The objective is to minimize the sum of squared residuals between the measured TOA distances (c * t_i) and the estimated distances from the source to the sensors:

$$\min_{x_s, y_s} \sum_{i=1}^{M} \left(c \cdot t_i - \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}\right)^2$$

- **Constraints:**
    - The source location (x_s, y_s) must lie within the physical boundaries of the sensor array region.

{Optimization Algorithm}

- **Algorithm Type:** Gradient-Based Optimization (e.g., Levenberg-Marquardt Algorithm)

Gradient-based optimization algorithms are well-suited for nonlinear least squares problems, as they leverage the gradient information to iteratively refine the solution. The Levenberg-Marquardt algorithm is a popular choice for its robustness and efficiency in solving such problems.

- **Algorithm Parameters:**
    - Initial guess for the source location (x_s^0, y_s^0)
    - Maximum number of iterations
    - Convergence tolerance

- **Algorithm Steps:**
1. Initialize the source location estimate (x_s^0, y_s^0) with an initial guess or using techniques like centroid approximation.
2. Compute the residuals for the current source location estimate:
   $$r_i^k = c \cdot t_i - \sqrt{(x_s^k - x_i)^2 + (y_s^k - y_i)^2}$$
   for i = 1, 2, ..., M, where k is the current iteration index.
3. Evaluate the Jacobian matrix J, which contains the partial derivatives of the residuals with respect to the source location coordinates:
   $$J_{ij} = \frac{\partial r_i}{\partial x_j}, \quad \text{where} \quad x_j \in \{x_s, y_s\}$$
4. Compute the update step (Δx_s, Δy_s) by solving the following linear system:
   $$(J^T J + \lambda \text{diag}(J^T J)) \begin{bmatrix} \Delta x_s \\ \Delta y_s \end{bmatrix} = -J^T r$$
   where λ is the damping parameter that controls the step size, and r is the residual vector.
5. Update the source location estimate:
   $$x_s^{k+1} = x_s^k + \Delta x_s$$
   $$y_s^{k+1} = y_s^k + \Delta y_s$$
6. Evaluate the convergence criteria based on the change in the source location estimate or the residual norm. If converged or the maximum iterations are reached, terminate the algorithm. Otherwise, update the damping parameter λ and go to step 2.

The Levenberg-Marquardt algorithm iteratively refines the source location estimate by minimizing the sum of squared residuals between the measured and estimated TOA distances. The algorithm adjusts the damping parameter to ensure convergence and handles the nonlinearity of the problem effectively.