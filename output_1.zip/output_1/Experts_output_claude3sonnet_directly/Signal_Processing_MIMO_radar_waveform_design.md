2024-05-02 11:17:41.922786

{System Model}

- **Problem Type:** Colocated Narrowband MIMO Radar Waveform Code Design

- **Problem Description:** In a colocated narrowband MIMO radar system with $N_T$ transmit antennas and $N_R$ receive antennas, each transmit element emits a different waveform code through omnidirectional transmission. The objective is to design the transmitting waveform codes such that the cross-correlation between different waveform codes is minimized, while satisfying the constant modulus and similarity constraints. This problem arises in scenarios where multiple orthogonal waveforms are required to mitigate mutual interference and enable efficient target detection and parameter estimation.

- **System Model Parameters:**
  - $N_T$: Number of transmit antennas
  - $N_R$: Number of receive antennas
  - $\boldsymbol{s}_k \in \mathbb{C}^{N_T \times 1}$: Transmit waveform code for the $k$-th transmit antenna, $k = 1, \ldots, N_T$
  - $\boldsymbol{c}_k \in \mathbb{C}^{N_c \times 1}$: Constant modulus constraint vector for the $k$-th transmit waveform code
  - $\boldsymbol{d}_k \in \mathbb{C}^{N_s \times 1}$: Similarity constraint vector for the $k$-th transmit waveform code
  - $N_c$: Length of the constant modulus constraint vector
  - $N_s$: Length of the similarity constraint vector

- **System Model Formulations:**
  - Constant Modulus Constraint: $|\boldsymbol{s}_k^H \boldsymbol{c}_k| = 1$, for $k = 1, \ldots, N_T$
  - Similarity Constraint: $|\boldsymbol{s}_k^H \boldsymbol{d}_k| \geq \alpha$, for $k = 1, \ldots, N_T$, where $\alpha$ is a prescribed similarity threshold.
  - Cross-Correlation: $\rho_{ij} = \frac{|\boldsymbol{s}_i^H \boldsymbol{s}_j|}{\sqrt{N_T}}$, for $i \neq j$, where $\rho_{ij}$ is the cross-correlation between waveform codes $\boldsymbol{s}_i$ and $\boldsymbol{s}_j$.

{Optimization Formulation}

- **Optimization Type:** Constrained Optimization

- **Optimization Parameters:**
  - $N_T$: Number of transmit antennas
  - $N_c$: Length of the constant modulus constraint vector
  - $N_s$: Length of the similarity constraint vector
  - $\boldsymbol{c}_k \in \mathbb{C}^{N_c \times 1}$: Constant modulus constraint vector for the $k$-th transmit waveform code
  - $\boldsymbol{d}_k \in \mathbb{C}^{N_s \times 1}$: Similarity constraint vector for the $k$-th transmit waveform code
  - $\alpha$: Prescribed similarity threshold

- **Optimization Variables:** $\boldsymbol{s}_k \in \mathbb{C}^{N_T \times 1}$, for $k = 1, \ldots, N_T$ (Transmit waveform codes)

- **Objective:** Minimize the sum of squared cross-correlations between different waveform codes:
  $$\min_{\{\boldsymbol{s}_k\}} \sum_{i=1}^{N_T} \sum_{j=1, j \neq i}^{N_T} \rho_{ij}^2$$

- **Constraints:**
  - Constant Modulus Constraint: $|\boldsymbol{s}_k^H \boldsymbol{c}_k| = 1$, for $k = 1, \ldots, N_T$
  - Similarity Constraint: $|\boldsymbol{s}_k^H \boldsymbol{d}_k| \geq \alpha$, for $k = 1, \ldots, N_T$

{Optimization Algorithm}

- **Algorithm Type:** Cyclic Algorithm

- **Algorithm Parameters:**
  - $\epsilon$: Convergence threshold
  - $\mu$: Step-size parameter
  - $\lambda_1, \lambda_2$: Lagrange multiplier vectors for constant modulus and similarity constraints, respectively

- **Algorithm Steps:**
  1. Initialize $\boldsymbol{s}_k^{(0)}$ with random values, $\lambda_1^{(0)} = \boldsymbol{0}$, $\lambda_2^{(0)} = \boldsymbol{0}$, and set iteration index $n = 0$.
  2. For each $k = 1, \ldots, N_T$, update $\boldsymbol{s}_k^{(n+1)}$ as follows:
     $$\boldsymbol{s}_k^{(n+1)} = \boldsymbol{s}_k^{(n)} - \mu \left[ \sum_{i=1, i \neq k}^{N_T} \rho_{ik}^{(n)} \boldsymbol{s}_i^{(n)} + \lambda_1^{(n)} \boldsymbol{c}_k + \lambda_2^{(n)} \boldsymbol{d}_k \right]$$
  3. Update the Lagrange multipliers:
     $$\lambda_1^{(n+1)} = \lambda_1^{(n)} + \mu_1 \left( 1 - |\boldsymbol{s}_k^{H(n+1)} \boldsymbol{c}_k| \right) \boldsymbol{c}_k^*$$
     $$\lambda_2^{(n+1)} = \lambda_2^{(n)} + \mu_2 \left( \alpha - |\boldsymbol{s}_k^{H(n+1)} \boldsymbol{d}_k| \right) \boldsymbol{d}_k^*$$
  4. If $\|\boldsymbol{s}_k^{(n+1)} - \boldsymbol{s}_k^{(n)}\| < \epsilon$ for all $k$, terminate the algorithm. Otherwise, increment $n$ and go to step 2.

This cyclic algorithm iteratively updates the waveform codes $\boldsymbol{s}_k$ and the Lagrange multipliers $\lambda_1, \lambda_2$ to minimize the sum of squared cross-correlations while satisfying the constant modulus and similarity constraints. The step-size parameters $\mu, \mu_1, \mu_2$ and the convergence threshold $\epsilon$ control the algorithm's behavior and termination criterion.