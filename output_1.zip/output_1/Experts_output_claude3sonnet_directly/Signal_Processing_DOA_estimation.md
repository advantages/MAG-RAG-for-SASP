2024-05-02 11:17:41.922786

### System Model
- **Problem Type:** This is a signal estimation problem involving a uniform linear array (ULA) used for direction-of-arrival (DOA) estimation of a narrowband signal source in the far-field.

- **Problem Description:** The goal is to estimate the angle $\Theta$ at which a continuous signal source is located relative to a ULA with $N$ array elements and a half-wavelength spacing. The array receives $K$ sampled signals containing information about the signal source's direction.

- **System Model Parameters:**
    - $N$: Number of array elements in the ULA
    - $d$: Array element spacing (given as half-wavelength, $d = \lambda/2$)
    - $\Theta$: Angle of the signal source relative to the array
    - $K$: Number of sampled signals received by the array
    - $\mathbf{a}(\Theta)$: Array steering vector for the angle $\Theta$
    - $\mathbf{x}(t)$: Received signal vector at time $t$
    - $s(t)$: Transmitted signal from the source
    - $\mathbf{n}(t)$: Additive noise vector

- **System Model Formulations:**
    - The array steering vector $\mathbf{a}(\Theta)$ is given by:
        $$\mathbf{a}(\Theta) = \begin{bmatrix}
        1\\
        e^{-j\pi\sin(\Theta)}\\
        \vdots\\
        e^{-j(N-1)\pi\sin(\Theta)}
        \end{bmatrix}$$
    - The received signal vector $\mathbf{x}(t)$ can be modeled as:
        $$\mathbf{x}(t) = \mathbf{a}(\Theta)s(t) + \mathbf{n}(t)$$
    - The objective is to estimate $\Theta$ based on the $K$ sampled signals $\{\mathbf{x}(t_k)\}_{k=1}^K$.

### Optimization Formulation
- **Optimization Type:** This is a non-linear optimization problem, where the goal is to find the angle $\Theta$ that minimizes the difference between the observed signals and the expected signals based on the array model.

- **Optimization Parameters:**
    - $N$: Number of array elements
    - $\{\mathbf{x}(t_k)\}_{k=1}^K$: Set of $K$ sampled received signal vectors

- **Optimization Variables:**
    - $\Theta$: Angle of the signal source relative to the array

- **Objective:** The objective is to minimize the squared error between the observed signals and the expected signals based on the array model, given by:
    $$\min_{\Theta} \sum_{k=1}^K \left\|\mathbf{x}(t_k) - \mathbf{a}(\Theta)s(t_k)\right\|^2$$

- **Constraints:**
    - $-\pi/2 \leq \Theta \leq \pi/2$ (Signal source is in the far-field)

### Optimization Algorithm
- **Algorithm Type:** A non-linear optimization algorithm, such as the Levenberg-Marquardt algorithm or a gradient-based method like Conjugate Gradient or BFGS, can be used to solve this problem.

- **Algorithm Parameters:**
    - Initial guess for $\Theta$
    - Convergence threshold
    - Maximum number of iterations
    - Step size or learning rate

- **Algorithm Steps:**
    1. Initialize $\Theta$ with an initial guess.
    2. Compute the array steering vector $\mathbf{a}(\Theta)$ using the current $\Theta$.
    3. Compute the objective function value as the sum of squared errors between the observed signals and the expected signals based on the array model:
        $$J(\Theta) = \sum_{k=1}^K \left\|\mathbf{x}(t_k) - \mathbf{a}(\Theta)s(t_k)\right\|^2$$
    4. Compute the gradient of the objective function with respect to $\Theta$:
        $$\nabla_\Theta J(\Theta) = -2\sum_{k=1}^K \Re\left\{\left[\mathbf{x}(t_k) - \mathbf{a}(\Theta)s(t_k)\right]^H \frac{\partial\mathbf{a}(\Theta)}{\partial\Theta}s(t_k)\right\}$$
    5. Update $\Theta$ using the chosen optimization algorithm (e.g., Levenberg-Marquardt, Conjugate Gradient, BFGS) and the computed gradient.
    6. Repeat steps 2-5 until the convergence criterion is met or the maximum number of iterations is reached.

The estimation accuracy can be evaluated by computing the root-mean-square error (RMSE) between the estimated angle $\hat{\Theta}$ and the true angle $\Theta$ over multiple Monte Carlo simulations. The RMSE can be compared for different values of $K$ to assess the impact of the number of sampled signals on the estimation accuracy.

To simulate the problem in MATLAB or Python, you can implement the above algorithm and generate synthetic data for the received signal vectors $\{\mathbf{x}(t_k)\}_{k=1}^K$ based on the system model. The true angle $\Theta$ can be varied, and the estimation accuracy can be evaluated for different values of $K$.