2024-05-02 11:17:41.922786

{System Model}

- **Problem Type:** This is a sensor array signal processing problem focused on source localization using bearing angle measurements.

- **Problem Description:** Given a set of $M$ sensors at different positions $(x_i, y_i)$, where $i=1,2,\ldots,M$, the objective is to localize a signal source by exploiting the bearing angle measurements from each sensor. Each sensor measures the bearing angle (direction of arrival) of the signal source, possibly with some additive Gaussian noise. The measured angle at sensor $i$ is denoted as $\theta_i$.

- **System Model Parameters:**
  - $M$: The number of sensors in the array
  - $(x_i, y_i)$: The known position coordinates of sensor $i$
  - $\theta_i$: The measured bearing angle at sensor $i$
  - $\sigma_i^2$: The variance of the additive Gaussian noise associated with the bearing angle measurement at sensor $i$

- **System Model Formulations:**
  - The true bearing angle of the signal source at sensor $i$ can be expressed as:
    $$\phi_i = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)$$
    where $(x_s, y_s)$ is the unknown position of the signal source.
  - The measured bearing angle at sensor $i$ is modeled as:
    $$\theta_i = \phi_i + n_i$$
    where $n_i \sim \mathcal{N}(0, \sigma_i^2)$ is the additive Gaussian noise with zero mean and variance $\sigma_i^2$.

{Optimization Formulation}

- **Optimization Type:** This is a non-linear least-squares optimization problem, where the objective is to estimate the unknown signal source position $(x_s, y_s)$ by minimizing the sum of squared residuals between the measured bearing angles and the true bearing angles computed from the estimated source position.

- **Optimization Parameters:**
  - $M$: The number of sensors
  - $(x_i, y_i)$: The known positions of the sensors
  - $\theta_i$: The measured bearing angles at each sensor
  - $\sigma_i^2$: The variances of the measurement noise for each sensor

- **Optimization Variables:** The decision variables are the unknown coordinates $(x_s, y_s)$ of the signal source.

- **Objective:** The objective function to be minimized is the sum of squared residuals between the measured bearing angles and the true bearing angles computed from the estimated source position:
  $$J(x_s, y_s) = \sum_{i=1}^M \left[\theta_i - \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)\right]^2$$

- **Constraints:** The optimization variables $(x_s, y_s)$ may be subject to physical constraints based on the operational region or the deployment area of the sensor array. These constraints can be expressed as:
  $$x_s^{\min} \leq x_s \leq x_s^{\max}$$
  $$y_s^{\min} \leq y_s \leq y_s^{\max}$$
  where $(x_s^{\min}, x_s^{\max})$ and $(y_s^{\min}, y_s^{\max})$ define the bounds of the region of interest.

{Optimization Algorithm}

- **Algorithm Type:** To solve the non-linear least-squares optimization problem, an iterative algorithm such as the Gauss-Newton or Levenberg-Marquardt algorithm can be employed. These algorithms are well-suited for minimizing the sum of squared residuals and can handle non-linear objective functions effectively.

- **Algorithm Parameters:**
  - Initial guess: $(x_s^{(0)}, y_s^{(0)})$ - The initial estimate of the signal source position
  - Convergence threshold: $\epsilon$ - The algorithm terminates when the change in the objective function or the step size falls below this threshold
  - Maximum iterations: $N_{\max}$ - The maximum number of iterations to perform before terminating

- **Algorithm Steps:**
  1. Initialize the algorithm with an initial guess $(x_s^{(0)}, y_s^{(0)})$ for the signal source position.
  2. For iteration $k=0, 1, 2, \ldots$:
     1. Compute the true bearing angles $\phi_i^{(k)}$ at each sensor using the current estimate $(x_s^{(k)}, y_s^{(k)})$:
        $$\phi_i^{(k)} = \tan^{-1}\left(\frac{y_s^{(k)} - y_i}{x_s^{(k)} - x_i}\right)$$
     2. Compute the residuals $r_i^{(k)}$ between the measured bearing angles $\theta_i$ and the true bearing angles $\phi_i^{(k)}$:
        $$r_i^{(k)} = \theta_i - \phi_i^{(k)}$$
     3. Construct the Jacobian matrix $\mathbf{J}^{(k)}$ by computing the partial derivatives of the residuals with respect to the optimization variables $(x_s, y_s)$:
        $$\mathbf{J}^{(k)} = \begin{bmatrix}
            \frac{\partial r_1^{(k)}}{\partial x_s} & \frac{\partial r_1^{(k)}}{\partial y_s} \\
            \vdots & \vdots \\
            \frac{\partial r_M^{(k)}}{\partial x_s} & \frac{\partial r_M^{(k)}}{\partial y_s}
        \end{bmatrix}$$
     4. Compute the update step $(\Delta x_s^{(k)}, \Delta y_s^{(k)})$ by solving the normal equations:
        $$\begin{bmatrix}
            \Delta x_s^{(k)} \\
            \Delta y_s^{(k)}
        \end{bmatrix} = -\left(\mathbf{J}^{(k)\top}\mathbf{J}^{(k)}\right)^{-1}\mathbf{J}^{(k)\top}\mathbf{r}^{(k)}$$
     5. Update the estimate of the signal source position:
        $$x_s^{(k+1)} = x_s^{(k)} + \Delta x_s^{(k)}$$
        $$y_s^{(k+1)} = y_s^{(k)} + \Delta y_s^{(k)}$$
     6. Check the convergence criteria:
        - If $\|(\Delta x_s^{(k)}, \Delta y_s^{(k)})\| < \epsilon$ or $k \geq N_{\max}$, terminate the algorithm.
        - Otherwise, proceed to the next iteration $k+1$.
  3. Return the final estimate $(x_s^{(k+1)}, y_s^{(k+1)})$ as the localized signal source position.

By following this structured approach, the signal processing problem of source localization using bearing angle measurements from a sensor array can be effectively formulated and solved using an appropriate non-linear least-squares optimization algorithm.