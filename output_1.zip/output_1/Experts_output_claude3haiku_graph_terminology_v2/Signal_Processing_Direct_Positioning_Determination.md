2024-05-30 23:49:16.706420

### System Model

**Problem Type:** Two-dimensional (2-D) localization of a single signal source using time-of-arrival (TOA) measurements from multiple sensors.

**Problem Description:** The goal is to estimate the position of a signal source that continuously emits signals in a 2-D space, using TOA measurements from a network of sensors. The sensors are spatially distributed, and each sensor has the capability to upload the received signal samples to a data fusion center. The data fusion center is responsible for processing the TOA measurements and estimating the position of the signal source.

**System Model Parameters:**
- $M$: Number of sensors
- $(x, y)$: True position of the signal source
- $\boldsymbol{r}_i = [r_{xi}, r_{yi}]^T$: Position of the $i$-th sensor, $i = 1, 2, \ldots, M$
- $\tilde{t}_i$: Noisy TOA measurement at the $i$-th sensor
- $c$: Signal propagation speed (constant)
- $\eta_i \sim \mathcal{N}(0, \sigma^2_i/c^2)$: Additive Gaussian white noise for the TOA measurement at the $i$-th sensor, where $\sigma^2_i$ is the noise variance

**System Model Formulations:**
The noisy TOA measurement at the $i$-th sensor is modeled as:
$$\tilde{t}_i = \frac{2}{c}\sqrt{(x - r_{xi})^2 + (y - r_{yi})^2} + \eta_i$$

The transformed measurement model is given by:
$$\tilde{s}_i = 2d_i + c\eta_i$$
where $d_i = \sqrt{(x - r_{xi})^2 + (y - r_{yi})^2}$ is the distance between the signal source and the $i$-th sensor.

The Jacobian vector of the $i$-th sensor measurement error is:
$$\boldsymbol{J}_i = \left[\frac{\partial \tilde{s}_i}{\partial x}, \frac{\partial \tilde{s}_i}{\partial y}\right]^T = \left[\frac{2(x - r_{xi})}{d_i}, \frac{2(y - r_{yi})}{d_i}\right]^T$$

### Optimization Formulation

**Optimization Type:** The optimization problem aims to minimize the trace of the Cramér-Rao Lower Bound (CRLB) on the mean-squared error (MSE) of the signal source position estimate. This is equivalent to maximizing the Fisher Information Matrix (FIM) for the problem.

**Optimization Parameters:**
- $\sigma^2$: Measurement noise variance (assumed to be uniform for all sensors)
- $M$: Number of sensors

**Optimization Variables:**
- $(x, y)$: Position of the signal source

**Objective:**
Minimize the trace of the CRLB, which is given by:
$$\text{minimize} \quad \text{tr}(\text{CRLB}) = \frac{\sigma^2}{M}$$

**Constraints:**
There are no explicit constraints in this problem formulation.

### Optimization Algorithm

**Algorithm Type:** The optimization problem can be solved using an analytical approach based on the derived CRLB expression.

**Algorithm Parameters:** There are no explicit algorithm parameters required.

**Algorithm Steps:**
1. Compute the Jacobian vectors $\boldsymbol{J}_i$ for each sensor, $i = 1, 2, \ldots, M$.
2. Construct the Fisher Information Matrix (FIM) as:
   $$\boldsymbol{F} = \sum_{i=1}^M \frac{1}{\sigma^2_i} \boldsymbol{J}_i \boldsymbol{J}_i^T$$
3. Compute the CRLB as the inverse of the FIM:
   $$\text{CRLB} = \boldsymbol{F}^{-1}$$
4. Evaluate the trace of the CRLB:
   $$\text{tr}(\text{CRLB}) = \frac{\sigma^2}{M}$$

The algorithm terminates after step 4, as the trace of the CRLB represents the minimum achievable mean-squared error (MSE) for the signal source position estimate, given the sensor network configuration and noise characteristics.

The key steps of the algorithm are:
1. Compute the Jacobian vectors of the sensor measurement errors.
2. Construct the Fisher Information Matrix (FIM) using the Jacobian vectors.
3. Compute the Cramér-Rao Lower Bound (CRLB) as the inverse of the FIM.
4. Evaluate the trace of the CRLB, which represents the minimum MSE of the signal source position estimate.

The analytical solution provided by this algorithm allows for a straightforward determination of the minimum achievable localization error, given the sensor network and noise parameters.