2024-05-30 23:49:16.706420

### System Model
- **Problem Type:** Direction-of-Arrival (DOA) estimation for a uniform linear array (ULA) with coherent signals.
- **Problem Description:** The signal processing problem involves estimating the directions of arrival (DOAs) of multiple narrowband signals impinging on a uniform linear array (ULA) with $N$ sensor elements, where some of the signals are coherent. Conventional subspace-based DOA estimation techniques like MUSIC and ESPRIT fail to perform effectively in the presence of coherent signals due to the rank deficiency of the spatial covariance matrix. The goal is to develop a method that can accurately estimate the DOAs of the coherent and uncorrelated signals.
- **System Model Parameters:**
  - $N$: Number of sensor elements in the ULA
  - $\Theta$: DOA of the signal source relative to the array
  - $K$: Number of sampled signal snapshots
  - $\lambda$: Wavelength of the impinging signals
  - $d$: Spacing between adjacent sensor elements (half-wavelength)
  - $\mathbf{x}(t) = [x_0(t), x_1(t), \ldots, x_{N-1}(t)]^T$: Array output vector at time $t$
  - $\mathbf{s}(t) = [s_1(t), s_2(t), \ldots, s_K(t)]^T$: Vector of signal amplitudes at time $t$
  - $\mathbf{a}(\Theta) = [1, e^{j\frac{2\pi}{\lambda}d\sin(\Theta)}, \ldots, e^{j\frac{2\pi}{\lambda}(N-1)d\sin(\Theta)}]^T$: Steering vector corresponding to the DOA $\Theta$
  - $\mathbf{A}(\Theta) = [\mathbf{a}(\Theta_1), \mathbf{a}(\Theta_2), \ldots, \mathbf{a}(\Theta_K)]$: Vandermonde matrix of steering vectors
  - $\mathbf{n}(t)$: Additive white noise vector
- **System Model Formulations:**
  The array output can be modeled as:
  $$\mathbf{x}(t) = \mathbf{A}(\Theta)\mathbf{s}(t) + \mathbf{n}(t)$$
  where $\mathbf{A}(\Theta)$ is the Vandermonde matrix containing the DOA information, and $\mathbf{s}(t)$ is the vector of signal amplitudes.

### Optimization Formulation
- **Optimization Type:** Subspace-based DOA estimation using the ESPRIT algorithm.
- **Optimization Parameters:**
  - $\mathbf{R} = \mathbb{E}[\mathbf{x}(t)\mathbf{x}^H(t)]$: Covariance matrix of the array output
  - $\sigma_n^2$: Noise power
  - $\mathbf{T}$: Toeplitz matrix reconstructed from $\mathbf{R}$
  - $\mathbf{U}_s$: Signal subspace eigenvectors of $\mathbf{T}$
  - $\mathbf{U}_n$: Noise subspace eigenvectors of $\mathbf{T}$
- **Optimization Variables:** The DOAs $\Theta_1, \Theta_2, \ldots, \Theta_K$.
- **Objective:** Estimate the DOAs $\Theta_1, \Theta_2, \ldots, \Theta_K$ from the signal subspace eigenvectors $\mathbf{U}_s$.
- **Constraints:** The DOAs must satisfy the physical constraints imposed by the array geometry and the propagation environment.

### Optimization Algorithm
- **Algorithm Type:** Improved ESPRIT algorithm.
- **Algorithm Parameters:**
  - $\mathbf{U}_1$: Submatrix of $\mathbf{U}_s$ formed by the first $(N-1)$ rows
  - $\mathbf{U}_2$: Submatrix of $\mathbf{U}_s$ formed by the last $(N-1)$ rows
  - $\boldsymbol{\Phi}$: Diagonal matrix containing the eigenvalues of the rotation matrix $\boldsymbol{\Psi}$
- **Algorithm Steps:**
  1. Construct the Toeplitz matrix $\mathbf{T}$ from the covariance matrix $\mathbf{R}$ using the following equation:
     $$\mathbf{T} = \begin{bmatrix}
     \mathbf{R}[0] & \mathbf{R}[1] & \cdots & \mathbf{R}[N-2] \\
     \mathbf{R}^H[1] & \mathbf{R}[0] & \cdots & \mathbf{R}[N-3] \\
     \vdots & \vdots & \ddots & \vdots \\
     \mathbf{R}^H[N-2] & \mathbf{R}^H[N-3] & \cdots & \mathbf{R}[0]
     \end{bmatrix}$$
  2. Perform eigenvalue decomposition of $\mathbf{T}$ to obtain the signal subspace eigenvectors $\mathbf{U}_s$ and noise subspace eigenvectors $\mathbf{U}_n$.
  3. Partition $\mathbf{U}_s$ into $\mathbf{U}_1$ and $\mathbf{U}_2$.
  4. Compute the rotation matrix $\boldsymbol{\Psi}$ using the least-squares solution:
     $$\boldsymbol{\Psi} = (\mathbf{U}_1^H\mathbf{U}_1)^{-1}\mathbf{U}_1^H\mathbf{U}_2$$
  5. Compute the eigenvalues of $\boldsymbol{\Psi}$, which are the diagonal elements of $\boldsymbol{\Phi}$.
  6. Estimate the DOAs $\Theta_k$ from the eigenvalues $\phi_k$ of $\boldsymbol{\Phi}$ using:
     $$\Theta_k = \sin^{-1}\left(\frac{\lambda}{2\pi d}\angle\phi_k\right)$$
  7. Optionally, average the DOA estimates obtained from different rows of $\mathbf{T}$ to improve robustness.

To compare the estimation accuracy for different values of $K$, the algorithm can be executed with varying numbers of signal snapshots, and the root-mean-square error (RMSE) of the DOA estimates can be computed and compared.