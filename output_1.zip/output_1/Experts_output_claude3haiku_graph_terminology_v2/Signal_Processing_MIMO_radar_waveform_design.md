2024-05-31 00:10:14.335578

### System Model

- **Problem Type:** Waveform design for a colocated narrow band multiple-input multiple-output (MIMO) radar system.

- **Problem Description:** The goal is to design the transmit waveforms for a MIMO radar system with $N_T$ transmit antennas and $N_R$ receive antennas, such that the transmit waveforms satisfy certain desirable properties. Specifically, the cross-correlation between different waveform codes should be as small as possible, and the waveform code design should consider constant modulus and similarity constraints.

- **System Model Parameters:**
  - $N_T$: Number of transmit antennas in the MIMO radar system
  - $N_R$: Number of receive antennas in the MIMO radar system
  - $s_n(t)$: Baseband signal transmitted from the $n$-th antenna, where $n = 1, 2, \ldots, N_T$
  - $\mathbf{s} = [s_1(t), s_2(t), \ldots, s_{N_T}(t)]^T$: Vector of transmit waveforms

- **System Model Formulations:**
  The cross-correlation between the waveform codes transmitted from different antennas should be as small as possible, which can be expressed as:
  $$\min_{\mathbf{s}} \sum_{n_1 \neq n_2} \left|\int s_{n_1}(t) s_{n_2}^*(t) dt\right|$$

  Additionally, the waveform code design should consider the following constraints:
  1. Constant modulus constraint: $|s_n(t)| = 1/\sqrt{N_T}, \forall t, n$
  2. Similarity constraint: $\int |s_n(t) - s_m(t)|^2 dt \leq \epsilon, \forall n \neq m$
     where $\epsilon$ is a small positive constant that controls the maximum allowable difference between any two waveform codes.

### Optimization Formulation

- **Optimization Type:** Non-convex quadratically constrained quadratic programming (QCQP) problem.

- **Optimization Parameters:**
  - $\lambda, \chi$: Lower and upper bounds on the modulus of the waveform amplitudes, i.e., $\lambda \leq |s_n(t)| \leq \chi, \forall t, n$
  - $\epsilon$: Maximum allowable difference between any two waveform codes, as specified in the similarity constraint

- **Optimization Variables:** $\mathbf{s} = [s_1(t), s_2(t), \ldots, s_{N_T}(t)]^T$: Vector of transmit waveforms

- **Objective:** Minimize the cross-correlation between the waveform codes:
  $$\min_{\mathbf{s}} \sum_{n_1 \neq n_2} \left|\int s_{n_1}(t) s_{n_2}^*(t) dt\right|$$

- **Constraints:**
  1. Constant modulus constraint: $\lambda \leq |s_n(t)| \leq \chi, \forall t, n$
  2. Similarity constraint: $\int |s_n(t) - s_m(t)|^2 dt \leq \epsilon, \forall n \neq m$

### Optimization Algorithm

- **Algorithm Type:** Successive Alternating Direction Method of Multipliers (S-ADMM) algorithm.

- **Algorithm Parameters:**
  - $\tau_1, \tau_2, \tau_3$: Small positive constants to control the convergence of the algorithm
  - $\rho_1$: Penalty parameter in the ADMM algorithm for solving the convex QCQP subproblem, selected as $\rho_1^* = \frac{1}{\sqrt{\lambda_{\min}(\hat{\mathbf{A}})\lambda_{\max}(\hat{\mathbf{A}})}}$, where $\hat{\mathbf{A}} = \mathbf{B}\bar{\mathbf{A}}^{-1}\mathbf{B}^T$, $\bar{\mathbf{A}} = 2\mathbf{A}$, and $\mathbf{A}$, $\mathbf{B}$ are problem-specific matrices (see Equation (23) in the paper).

- **Algorithm Steps:**
  1. Initialize $\mathbf{s}^{(0)}$, $\{d_0^{l,k}\}_{(l,k)\in\Theta_1}$
  2. For $q = 1, 2, \ldots$:
     1. Update $\phi_{l,k}^{(q-1)} = \arg\{\mathbf{a}_{\theta_l,f_k}^H\mathbf{H}_k\mathbf{s}^{(q-1)}\}$, $(l,k) \in \Theta_1$
     2. Update scaling factor $\alpha^{(q-1)}$ and desired beampattern $d^{(q)}_{l,k}$ using Equations (9) and (8)
     3. Solve the convex QCQP subproblem $\mathcal{P}_{\mathbf{s}}^{(q)}$ using the fast ADMM algorithm (Algorithm 2 in the paper) to obtain $\mathbf{s}^{(q)}$
     4. If $\|\mathbf{s}^{(q)} - \mathbf{s}^{(q-1)}\|/\|\mathbf{s}^{(q)}\| \leq \tau_3$, output $\mathbf{s}^* = \mathbf{s}^{(q)}$ and terminate. Otherwise, go to Step 2.

  The fast ADMM algorithm (Algorithm 2) for solving the convex QCQP subproblem $\mathcal{P}_{\mathbf{s}}^{(q)}$ involves the following steps:
  1. Initialize $\mathbf{x}^{(0)}, \mathbf{y}^{(0)}, \mathbf{z}^{(0)}, \mathbf{h}^{(0)}, \mathbf{u}_y^{(0)}, \mathbf{u}_z^{(0)}, \mathbf{u}_h^{(0)}$
  2. For $t = 1, 2, \ldots$:
     1. Update $\mathbf{y}^{(t+1)}$, $\mathbf{z}^{(t+1)}$, $\mathbf{h}^{(t+1)}$ by solving closed-form subproblems involving the constraint sets $\Omega_y$, $\Omega_z$, $\Omega_h$, respectively
     2. Update $\mathbf{x}^{(t+1)}$ by solving a least-squares problem
     3. Update $\mathbf{u}_y^{(t+1)}$, $\mathbf{u}_z^{(t+1)}$, $\mathbf{u}_h^{(t+1)}$ using dual updates
     4. If $\max\{\|\mathbf{x}^{(t)} - \mathbf{y}^{(t)}\|, \|\mathbf{x}^{(t)} - \mathbf{h}^{(t)}\|, \|\mathbf{z}^{(t)} - \mathbf{x}^{(t)}\|, \|\mathbf{x}^{(t)} - \mathbf{x}^{(t+1)}\|\} \leq \tau_2$, output $\mathbf{x}^* = \mathbf{x}^{(t+1)}$ and terminate the inner loop. Otherwise, go to Step 2.
  3. The solution $\mathbf{s}^{(q)}$ to the convex QCQP subproblem $\mathcal{P}_{\mathbf{s}}^{(q)}$ is obtained from $\mathbf{x}^*$.

The proposed S-ADMM algorithm ensures that the objective value $f_0(\mathbf{s}^{(q)})$ monotonically decreases and converges to a finite value. Additionally, the solution $\mathbf{s}^*$ obtained satisfies the Karush-Kuhn-Tucker (KKT) conditions of the original non-convex problem $\mathcal{P}_1$.