2024-05-30 23:49:16.706420

### System Model

- **Problem Type:** Angle-of-Arrival (AOA) Based Source Localization
- **Problem Description:** The problem involves localizing a single source emitting an acoustic or electromagnetic signal using AOA measurements obtained from an array of sensors. The objective is to infer the source location from the noisy AOA measurements by optimizing the sensor geometry.

- **System Model Parameters:**
  - $p = [x_s, y_s]^T$: Location of the unknown source
  - $s_i = [x_i, y_i]^T$: Coordinates of the $i$-th sensor location
  - $\hat{\theta}_i$: Observed AOA measurement at the $i$-th sensor
  - $\theta_i = \arctan\frac{y_s - y_i}{x_s - x_i}$: True AOA of the source with respect to the $i$-th sensor
  - $\epsilon_i \sim \mathcal{N}(0, \sigma_i^2)$: Measurement noise at the $i$-th sensor, following a zero-mean Gaussian distribution with variance $\sigma_i^2$
  - $\hat{\theta} = [\hat{\theta}_1, \hat{\theta}_2, \ldots, \hat{\theta}_N]^T$: Vector of observed AOA measurements
  - $\theta = [\theta_1, \theta_2, \ldots, \theta_N]^T$: Vector of true AOAs
  - $\epsilon = [\epsilon_1, \epsilon_2, \ldots, \epsilon_N]^T$: Vector of measurement noises
  - $Q = \mathrm{diag}(\sigma_1^2, \sigma_2^2, \ldots, \sigma_N^2)$: Covariance matrix of the measurement noise

- **System Model Formulations:**
  - $\hat{\theta}_i = \theta_i + \epsilon_i$
  - $\hat{\theta} = \theta + \epsilon$
  - The Fisher Information Matrix (FIM) is given by:
$$F(p) = \begin{bmatrix}
\sum_{i=1}^{N}\frac{\sin^2\theta_i}{\sigma_i^2r_i^2} & -\frac{1}{2}\sum_{i=1}^{N}\frac{\sin2\theta_i}{\sigma_i^2r_i^2} \\
-\frac{1}{2}\sum_{i=1}^{N}\frac{\sin2\theta_i}{\sigma_i^2r_i^2} & \sum_{i=1}^{N}\frac{\cos^2\theta_i}{\sigma_i^2r_i^2}
\end{bmatrix}$$
where $r_i = \sqrt{(x_s - x_i)^2 + (y_s - y_i)^2}$ is the distance between the $i$-th sensor and the source.

### Optimization Formulation

- **Optimization Type:** Constrained optimization problem
- **Optimization Parameters:**
  - $\theta_{ij} = \pi - ||\theta_j - \theta_i| - \pi|$: Separation angle subtended at the source by the $i$-th and $j$-th sensors
  - $r_i$: Distance between the $i$-th sensor and the source
  - $\sigma_i$: Measurement noise standard deviation at the $i$-th sensor
  - $\lambda$: Radius of the circular deployment region
  - $r$: Minimum safety distance between sensors and the source
  - $O = [x_0, y_0]^T$: Center of the circular deployment region
- **Optimization Variables:**
  - $\theta_{ij}$: Separation angles between sensors
  - $r_i$: Sensor-source distances
- **Objective:** Maximize the D-optimality criterion, which is equivalent to maximizing the determinant of the FIM:
$$\max_{\{\theta_{ij}, r_i, r_j\}, i, j \in \{1, \ldots, N\}} \prod_{i=1}^{N}\prod_{j>i}\frac{\sin^2\theta_{ij}}{\sigma_i^2\sigma_j^2r_i^2r_j^2}$$
- **Constraints:**
  - $(x_i - x_0)^2 + (y_i - y_0)^2 \leq \lambda^2$ (sensors within the circular region)
  - $(x_s - x_0)^2 + (y_s - y_0)^2 \leq \lambda^2$ (source within the circular region)
  - $(x_i - x_s)^2 + (y_i - y_s)^2 \geq r^2$ (minimum safety distance between sensors and source)

### Optimization Algorithm

- **Algorithm Type:** Analytical approach based on geometric considerations
- **Algorithm Parameters:**
  - $\phi$: Maximum feasible angle subtended at the source by any two sensors, considering the deployment region constraints
  - $\theta^*_{ij}$: Optimal separation angle between the $i$-th and $j$-th sensors for the unconstrained case
- **Algorithm Steps:**
  1. Determine the maximum feasible angle $\phi$ based on the circular deployment region and minimum safety distance constraints.
  2. Compare $\phi$ with the optimal separation angle $\theta^*_{ij}$ for the unconstrained case.
  3. Analyze the optimal geometries for different ranges of $\phi$ values, considering the constraints and the relationship between $\phi$ and $\theta^*_{ij}$.
  4. Provide geometric interpretations and placements of sensors that optimize the D-optimality criterion while satisfying the constraints.

The key steps in this approach are to first determine the maximum feasible angle $\phi$ based on the deployment region and safety constraints, and then compare it with the optimal separation angle $\theta^*_{ij}$ for the unconstrained case. By analyzing the relationship between $\phi$ and $\theta^*_{ij}$, the algorithm can identify the optimal sensor geometries that maximize the D-optimality criterion while respecting the practical constraints.