2024-05-31 00:10:14.335578

### System Model

**Problem Type:** Colocated MIMO radar transmit beampattern synthesis under constant modulus constraints.

**Problem Description:** The goal is to design the transmit waveform $\mathbf{s} = [s_1, s_2, \ldots, s_L]^T \in \mathbb{C}^{M \times L}$ for a colocated MIMO radar with $M$ transmit antennas and $L$ signal samples per antenna, such that the synthesized beampattern $P(\theta)$ approximates a desired beampattern $d(\theta)$ while minimizing cross-correlation sidelobes. The constant modulus constraint $|s_i(l)| = 1, i=1,2,\ldots,ML$ prevents nonlinear distortion in the power amplifier.

**System Model Parameters:**
- $M$: Number of transmit antennas
- $L$: Number of signal samples per transmit pulse
- $\theta$: Angle of interest
- $\mathbf{a}_T(\theta) = [1, e^{-j2\pi d_u/\lambda}, \ldots, e^{-j2\pi (M-1)d_u/\lambda}]^T$: $M$-dimensional transmit steering vector
- $d_u$: Inter-element spacing
- $\lambda$: Signal wavelength
- $u = \sin\theta$: Direction cosine

**System Model Formulations:**
- $\mathbf{x}(l) = \mathbf{a}_T^T(\theta)\mathbf{s}_l, l=1,2,\ldots,L$: Synthesis signal at angle $\theta$ for the $l$-th sample
- $\mathbf{x} = [\mathbf{x}(1), \mathbf{x}(2), \ldots, \mathbf{x}(L)]^T = (\mathbf{I}_L \otimes \mathbf{a}_T^T(\theta))\mathbf{s}$: Concatenated synthesis signal vector
- $P(\theta) = \mathbf{x}^H\mathbf{x} = \mathbf{s}^H\mathbf{R}(\theta)\mathbf{s}$, where $\mathbf{R}(\theta) = (\mathbf{I}_L \otimes \mathbf{a}_T^T(\theta))^H(\mathbf{I}_L \otimes \mathbf{a}_T^T(\theta))$: Power received at angle $\theta$
- $P_{cc}(\theta, \bar{\theta}) = \mathbf{s}^H\overline{\mathbf{R}}(\theta, \bar{\theta})\mathbf{s}$, where $\overline{\mathbf{R}}(\theta, \bar{\theta}) = (\mathbf{I}_L \otimes \mathbf{a}_T^T(\theta))^H(\mathbf{I}_L \otimes \mathbf{a}_T^T(\bar{\theta}))$: Cross-correlation sidelobe at angles $\theta$ and $\bar{\theta}$

### Optimization Formulation

**Optimization Type:** Minimization of a nonconvex fourth-order polynomial objective function subject to nonconvex constant modulus constraints.

**Optimization Parameters:**
- $\alpha^2$: Scaling parameter to be optimized
- $\omega_k \geq 0, k=1,2,\ldots,K$: Weighted coefficients for the $K$ angles of interest
- $\omega_c$: Weight for cross-correlation sidelobes

**Optimization Variables:** $\mathbf{r} = [\alpha, \mathbf{s}^T]^T \in \mathbb{C}^{ML+1}$

**Objective:**
$$
\begin{align*}
\min_{\mathbf{r}} J_1(\mathbf{r}) &= \frac{1}{K}\sum_{k=1}^K \omega_k \left| \alpha^2 d(\theta_k) - \mathbf{r}^H\mathbf{A}(\theta_k)\mathbf{r} \right|^2 \\
&\quad + \omega_c \sum_{p=1}^{\bar{K}} \sum_{q=p+1}^{\bar{K}} \left| \mathbf{r}^H\overline{\mathbf{A}}(\theta_p, \theta_q)\mathbf{r} \right|^2
\end{align*}
$$
where $\mathbf{A}(\theta_k) = \begin{bmatrix} d(\theta_k) & \mathbf{0}^T \\ \mathbf{0} & -\mathbf{R}(\theta_k) \end{bmatrix}$ and $\overline{\mathbf{A}}(\theta_p, \theta_q) = \begin{bmatrix} \mathbf{0} & \mathbf{0}^T \\ \mathbf{0} & \overline{\mathbf{R}}(\theta_p, \theta_q) \end{bmatrix}$.

**Constraints:** $\mathbf{r}^H\mathbf{E}_{i+1}\mathbf{r} = 1, i=1,2,\ldots,ML$, where $\mathbf{E}_i$ is a $(ML+1) \times (ML+1)$ matrix with 1 at the $(i,i)$-th entry and 0 elsewhere (constant modulus constraints).

### Optimization Algorithm

**Algorithm Type:** Alternating Direction Method of Multipliers (ADMM)

**Algorithm Parameters:**
- $\rho_1, \rho_2 > 0$: Penalty parameters
- $\epsilon_{\text{abs}}^{(1)}, \epsilon_{\text{rel}}^{(1)}$: Absolute and relative tolerances for termination criteria

**Algorithm Steps:**
1) Initialize $\mathbf{h}^0, \mathbf{r}^0, \mathbf{u}^0, \mathbf{v}^0, \rho_1, \rho_2, \epsilon_{\text{abs}}^{(1)}, \epsilon_{\text{rel}}^{(1)}$
2) While termination criteria (based on primal and dual residuals) are not satisfied:
    a) Update $\mathbf{h}^{m+1}$ using $\mathbf{h}^{m+1} = \boldsymbol{\Xi}^{-1}\boldsymbol{\gamma}$, where $\boldsymbol{\Xi}$ and $\boldsymbol{\gamma}$ are defined in the paper
    b) Update $\mathbf{r}^{m+1}$ using $\mathbf{r}^{m+1} = \boldsymbol{\Omega}^{-1}\boldsymbol{\zeta}$, where $\boldsymbol{\Omega}$ and $\boldsymbol{\zeta}$ are defined in the paper
    c) Update $\mathbf{u}^{m+1} = \mathbf{u}^m + \mathbf{h}^{m+1} - \mathbf{r}^{m+1}$
    d) Update $\mathbf{v}^{m+1} = \mathbf{v}^m + \mathbf{T}'(\mathbf{r}^{m+1})\mathbf{h}^{m+1} - \mathbf{1}$
    e) $m \leftarrow m+1$
3) Return $\mathbf{r}^{m+1}$ as the solution

**Algorithm Termination:** The algorithm terminates when the primal and dual residuals satisfy:
$$
\begin{aligned}
\|\mathbf{d}_r^{m+1}\|_2 &\leq \epsilon_{\text{pri}}^{(1)}, \\
\|\mathbf{d}_s^{m+1}\|_2 &\leq \epsilon_{\text{dual}}^{(1)},
\end{aligned}
$$
where $\mathbf{d}_r^{m+1}$ and $\mathbf{d}_s^{m+1}$ are the primal and dual residuals at iteration $m+1$, respectively, and $\epsilon_{\text{pri}}^{(1)}$ and $\epsilon_{\text{dual}}^{(1)}$ are tolerances defined in the paper.