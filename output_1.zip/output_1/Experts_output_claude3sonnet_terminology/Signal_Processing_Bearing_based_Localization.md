2024-05-04 00:04:36.229547

### System Model
- **Problem Type:** This is a signal source localization problem using bearing-only measurements from a sensor array. It falls under the category of passive sensor array signal processing, where the goal is to estimate the position of a signal source based on noisy measurements from multiple sensors.

- **Problem Description:** Given a set of $M$ sensors located at known positions $(x_i, y_i)$, $i = 1, 2, \ldots, M$, the objective is to estimate the location $(x_s, y_s)$ of a signal source using the bearing angle measurements $\theta_i$ obtained from each sensor. The bearing angle measurements are assumed to be corrupted by additive Gaussian noise.

- **System Model Parameters:**
  - $M$: Number of sensors
  - $(x_i, y_i)$: Known position coordinates of sensor $i$
  - $\theta_i$: Bearing angle measurement from sensor $i$ towards the signal source
  - $(x_s, y_s)$: Unknown position coordinates of the signal source (to be estimated)
  - $\sigma_\theta^2$: Variance of the additive Gaussian noise in the bearing angle measurements

- **System Model Formulations:** The bearing angle measurement $\theta_i$ from sensor $i$ towards the signal source can be modeled as:

$$
\theta_i = \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right) + n_i
$$

where $n_i$ is the additive Gaussian noise with zero mean and variance $\sigma_\theta^2$.

The goal is to estimate $(x_s, y_s)$ based on the set of bearing angle measurements $\{\theta_i\}_{i=1}^M$.

### Optimization Formulation
- **Optimization Type:** This is a non-linear least-squares optimization problem, where the objective is to find the source location $(x_s, y_s)$ that minimizes the sum of squared residuals between the measured bearing angles and the bearing angles predicted by the system model.

- **Optimization Parameters:**
  - $M$: Number of sensors
  - $(x_i, y_i)$: Known position coordinates of sensor $i$
  - $\theta_i$: Bearing angle measurement from sensor $i$
  - $\sigma_\theta^2$: Variance of the additive Gaussian noise in the bearing angle measurements

- **Optimization Variables:**
  - $(x_s, y_s)$: Unknown position coordinates of the signal source

- **Objective:** The objective is to minimize the sum of squared residuals between the measured bearing angles and the bearing angles predicted by the system model:

$$
\min_{x_s, y_s} \sum_{i=1}^M \left[\theta_i - \tan^{-1}\left(\frac{y_s - y_i}{x_s - x_i}\right)\right]^2
$$

- **Constraints:** There are no explicit constraints on the optimization variables $(x_s, y_s)$, as they represent the unknown source location in the 2D plane.

### Optimization Algorithm
- **Algorithm Type:** Due to the non-linear nature of the objective function, a suitable algorithm for this problem is the Gauss-Newton method or the Levenberg-Marquardt algorithm, which are iterative techniques for solving non-linear least-squares problems.

- **Algorithm Parameters:**
  - $\epsilon$: Convergence threshold for the algorithm
  - $\lambda$: Damping parameter for the Levenberg-Marquardt algorithm (if used)
  - $k_{\max}$: Maximum number of iterations

- **Algorithm Steps:**
1. Initialize the source location estimate $(x_s^{(0)}, y_s^{(0)})$ with an initial guess or the centroid of the sensor locations.
2. For $k = 0, 1, 2, \ldots, k_{\max}$:
   1. Compute the residual vector $\mathbf{r}^{(k)}$ and the Jacobian matrix $\mathbf{J}^{(k)}$ at the current estimate $(x_s^{(k)}, y_s^{(k)})$:
      $$
      \mathbf{r}^{(k)} = \begin{bmatrix}
      \theta_1 - \tan^{-1}\left(\frac{y_s^{(k)} - y_1}{x_s^{(k)} - x_1}\right) \\
      \vdots \\
      \theta_M - \tan^{-1}\left(\frac{y_s^{(k)} - y_M}{x_s^{(k)} - x_M}\right)
      \end{bmatrix}
      $$
      $$
      \mathbf{J}^{(k)} = \begin{bmatrix}
      \frac{\partial r_1}{\partial x_s} & \frac{\partial r_1}{\partial y_s} \\
      \vdots & \vdots \\
      \frac{\partial r_M}{\partial x_s} & \frac{\partial r_M}{\partial y_s}
      \end{bmatrix}
      $$
   2. Compute the update step $\Delta\mathbf{x}^{(k)}$ by solving the normal equations:
      $$
      (\mathbf{J}^{(k)\top}\mathbf{J}^{(k)} + \lambda\mathbf{I})\Delta\mathbf{x}^{(k)} = -\mathbf{J}^{(k)\top}\mathbf{r}^{(k)}
      $$
   3. Update the source location estimate:
      $$
      \begin{bmatrix}
      x_s^{(k+1)} \\
      y_s^{(k+1)}
      \end{bmatrix} = \begin{bmatrix}
      x_s^{(k)} \\
      y_s^{(k)}
      \end{bmatrix} + \Delta\mathbf{x}^{(k)}
      $$
   4. Check convergence criterion: if $\|\Delta\mathbf{x}^{(k)}\| < \epsilon$, terminate the algorithm.
3. Return the final estimate $(x_s^{(k_{\rm final})}, y_s^{(k_{\rm final})})$ as the estimated source location.

This algorithm iteratively updates the source location estimate by minimizing the sum of squared residuals between the measured and predicted bearing angles, using the Gauss-Newton or Levenberg-Marquardt method. The convergence is achieved when the update step falls below a specified threshold, or the maximum number of iterations is reached.