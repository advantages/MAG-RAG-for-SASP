2024-05-04 00:04:36.229547

### System Model
- **Problem Type:** Signal Source Localization using Time-of-Arrival (TOA) Measurements
- **Problem Description:** The problem involves determining the location of a signal source based on time-of-arrival (TOA) measurements obtained from an array of $M$ sensors distributed at known positions $(x_i, y_i)$, where $i = 1, 2, \ldots, M$. Each sensor measures the time $t_i$ at which the signal arrives at its location. By combining these TOA measurements from multiple sensors, the goal is to estimate the coordinates of the signal source.
- **System Model Parameters:**
    - $M$: Number of sensors in the array
    - $(x_i, y_i)$: Known coordinates of the $i$-th sensor, for $i = 1, 2, \ldots, M$
    - $t_i$: Time-of-arrival measurement at the $i$-th sensor, for $i = 1, 2, \ldots, M$
    - $(x_s, y_s)$: Unknown coordinates of the signal source
    - $c$: Propagation speed of the signal (typically the speed of light)
- **System Model Formulations:** The TOA measurement $t_i$ at the $i$-th sensor is related to the unknown source location $(x_s, y_s)$ through the following equation:

$$
t_i = \frac{1}{c}\sqrt{(x_i - x_s)^2 + (y_i - y_s)^2} + n_i
$$

where $n_i$ represents the measurement noise or error associated with the $i$-th sensor's TOA measurement. The goal is to estimate $(x_s, y_s)$ by solving the set of nonlinear equations formed by the TOA measurements from all $M$ sensors.

### Optimization Formulation
- **Optimization Type:** Nonlinear Least Squares Optimization
- **Optimization Parameters:**
    - $M$: Number of sensors
    - $(x_i, y_i)$: Known coordinates of the $i$-th sensor, for $i = 1, 2, \ldots, M$
    - $t_i$: Time-of-arrival measurement at the $i$-th sensor, for $i = 1, 2, \ldots, M$
    - $c$: Propagation speed of the signal
- **Optimization Variables:** $(x_s, y_s)$: Unknown coordinates of the signal source
- **Objective:** Minimize the sum of squared residuals between the measured TOA values and the predicted TOA values based on the estimated source location:

$$
\min_{x_s, y_s} \sum_{i=1}^{M} \left(t_i - \frac{1}{c}\sqrt{(x_i - x_s)^2 + (y_i - y_s)^2}\right)^2
$$

- **Constraints:** No explicit constraints on $(x_s, y_s)$ are considered in this formulation.

### Optimization Algorithm
- **Algorithm Type:** Nonlinear Least Squares Solver (e.g., Gauss-Newton, Levenberg-Marquardt)
- **Algorithm Parameters:**
    - Convergence tolerance: Threshold for the change in the objective function or parameter updates to declare convergence.
    - Maximum iterations: Maximum number of iterations allowed for the algorithm to run.
    - Initial guess: Initial values for $(x_s, y_s)$ to start the iterative optimization process.
- **Algorithm Steps:**
    1. Initialize $(x_s, y_s)$ with an initial guess or estimate.
    2. Compute the predicted TOA values $\hat{t}_i$ for each sensor using the current estimate of $(x_s, y_s)$:
    
    $$
    \hat{t}_i = \frac{1}{c}\sqrt{(x_i - x_s)^2 + (y_i - y_s)^2}
    $$
    
    3. Calculate the residuals between the measured TOA values $t_i$ and the predicted values $\hat{t}_i$:
    
    $$
    r_i = t_i - \hat{t}_i
    $$
    
    4. Compute the Jacobian matrix $J$, which contains the partial derivatives of the residuals with respect to $(x_s, y_s)$:
    
    $$
    J_{ij} = \frac{\partial r_i}{\partial p_j}, \quad \text{where } p_1 = x_s, p_2 = y_s
    $$
    
    5. Solve the normal equations $J^T J \delta = J^T r$ to obtain the update vector $\delta$.
    6. Update the estimate of $(x_s, y_s)$ using the update vector $\delta$:
    
    $$
    \begin{pmatrix}
    x_s \\
    y_s
    \end{pmatrix}_{\text{new}} = \begin{pmatrix}
    x_s \\
    y_s
    \end{pmatrix}_{\text{old}} + \delta
    $$
    
    7. Check for convergence by evaluating the change in the objective function or the magnitude of the update vector $\delta$. If the convergence criteria are met, terminate the algorithm and output the final estimate of $(x_s, y_s)$. Otherwise, go back to step 2 and continue the iterative process.

This algorithm follows the standard nonlinear least squares optimization approach, where the objective is to minimize the sum of squared residuals between the measured TOA values and the predicted TOA values based on the estimated source location. The Jacobian matrix is used to compute the update direction, and the algorithm iteratively refines the estimate of $(x_s, y_s)$ until convergence is achieved.