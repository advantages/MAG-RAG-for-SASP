2024-05-04 00:04:36.229547

#### Terminological Description:
The problem involves estimating the position (x, y) of a signal source emitting continuous signals using the received signals at M spatially distributed sensor locations, each equipped with a single antenna. The sensors can transmit their received signal samples to a central data fusion center. The key terminological aspects include direction-of-arrival (DOA) estimation, source localization, time-of-arrival (TOA) estimation, distributed or decentralized processing, wireless sensor networks, and array signal processing techniques like MUSIC, ESPRIT, and subspace-based methods.

#### Relevant Examples:
1. Guvenc Third Quarter 2009 A Survey on TOA Based Wireless Localization and NLOS Mitigation Techniques
2. Sun January 2019 Solution and Analysis of TDOA Localization of a Near or Distant Source
3. Tzafri September 2016 High-Resolution Direct Position Determination Using MVDR