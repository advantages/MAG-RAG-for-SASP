2024-05-04 00:04:36.229547

#### Terminological Description:
The problem involves localizing a signal source by utilizing time-of-arrival (TOA) measurements from multiple sensors at different positions. The key terms include:

- Signal source localization
- Time-of-arrival (TOA) measurements
- Sensor positions ($x_i$, $y_i$)
- TOA measurements from each sensor ($t_i$)
- Multiple sensors ($M$ sensors)

The goal is to estimate the location of the signal source by combining the TOA measurements from the distributed sensor array.

#### Relevant Examples:
1. Guvenc 和 Chong - 2009 - A Survey on TOA Based Wireless Localization and NL.md
2. Sun 等 - 2019 - Solution and Analysis of TDOA Localization of a Ne.md
3. Tzafri 和 Weiss - 2016 - High-Resolution Direct Position Determination Usin.md