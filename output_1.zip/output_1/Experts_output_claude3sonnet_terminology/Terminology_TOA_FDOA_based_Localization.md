2024-05-04 00:04:36.229547

#### Terminological Description:
The problem involves localizing a signal source by utilizing time difference of arrival (TDOA) and frequency difference of arrival (FDOA) measurements obtained from an array of $M$ sensors at different positions $(\var{x_i}, \var{y_i})$, $i=1,2,\ldots,M$. The key terminologies include TDOA, FDOA, sensor array, source localization, signal processing, and estimation techniques.

#### Relevant Examples:
1. Sun January 2019 Solution and Analysis of TDOA Localization of a Near or Distant Source in Closed Form
2. Tzafri September 2016 High-Resolution Direct Position Determination Using MVDR
3. Guvenc Third Quarter 2009 A Survey on TOA Based Wireless Localization and NLOS Mitigation Techniques