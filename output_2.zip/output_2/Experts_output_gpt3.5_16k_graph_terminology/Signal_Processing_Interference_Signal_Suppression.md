2024-05-06 23:00:51.730759

### System Model

- **Problem Type:** Sensor array signal processing for source localization based on TOA or RSS measurements.
- **Problem Description:** The problem involves finding the optimal sensor locations for source localization techniques using either time of arrival (TOA) or received signal strength (RSS) measurements. The source is assumed to be present within a specified surveillance area or volume, without any specific assumption on its actual position.
- **System Model Parameters:** 
    - $m$: Number of sensors
    - $n$: Dimension of the problem (2 for 2D, 3 for 3D)
    - $p \in \mathbb{R}^n$: Unknown source position
    - $r_i \in \mathbb{R}^n$: Position of the $i$-th sensor, $i=1,\ldots,m$
    - $\tilde{d}_i$: Noisy distance measurement at the $i$-th sensor for TOA
    - $L_i$: Noisy RSS measurement at the $i$-th sensor in dB
    - $\epsilon_i \sim \mathcal{N}(0, \sigma_i^2)$: TOA measurement noise at the $i$-th sensor
    - $\nu_i \sim \mathcal{N}(0, \rho_i^2)$: RSS measurement noise at the $i$-th sensor
    - $L_0$: Received power in dB at a reference distance (assumed 1)
    - $\eta$: Path loss exponent (assumed known)
    - $\mathbf{R}_\text{TOA} = \text{diag}(\sigma_1^2, \ldots, \sigma_m^2)$: TOA measurement noise covariance matrix
    - $\mathbf{R}_\text{RSS} = \text{diag}(\rho_1^2, \ldots, \rho_m^2)$: RSS measurement noise covariance matrix
- **System Model Formulations:** 
    - TOA measurement model: $\tilde{d}_i = \|p - r_i\|_2 + \epsilon_i, \quad i=1,\ldots,m$
    - RSS measurement model: $L_i = L_0 - 10\eta \log_{10}(\|p - r_i\|_2) + \nu_i, \quad i=1,\ldots,m$

### Optimization Formulation

- **Optimization Type:** The optimization problems are formulated to minimize either the average or the worst-case CRB-related metric over a grid of points sampling the surveillance region, considering both A-optimal (trace of CRB) and D-optimal (determinant of CRB) design criteria.
- **Optimization Parameters:** 
    - $K$: Number of grid points $\{p_k\}_{k=1}^K$ sampling the surveillance region
    - $\mathbf{H}_k = [h_{k,1}, \ldots, h_{k,m}]^\top$, where $h_{k,i} = \frac{p_k - r_i}{\|p_k - r_i\|_2}$ for TOA
    - $\mathbf{G}_k = [g_{k,1}, \ldots, g_{k,m}]^\top$, where $g_{k,i} = \frac{(p_k - r_i)}{\|p_k - r_i\|_2^2}$ for RSS
    - $\mathbf{R}_i$: Feasible deployment region for the $i$-th sensor
- **Optimization Variables:** $r_1, \ldots, r_m$: Sensor positions
- **Objective:**
    - Average A-optimal: $\min_{r_i \in \mathbf{R}_i} \frac{1}{K} \sum_{k=1}^K \text{Tr}\left(\left(\mathbf{H}_k^\top \mathbf{R}_\text{TOA}^{-1} \mathbf{H}_k\right)^{-1}\right)$ for TOA
    - Average D-optimal: $\min_{r_i \in \mathbf{R}_i} \frac{1}{K} \sum_{k=1}^K \det\left(\left(\mathbf{H}_k^\top \mathbf{R}_\text{TOA}^{-1} \mathbf{H}_k\right)^{-1}\right)$ for TOA
    - Worst-case A-optimal: $\min_{r_i \in \mathbf{R}_i} \max_{k \in \{1, \ldots, K\}} \text{Tr}\left(\left(\mathbf{H}_k^\top \mathbf{R}_\text{TOA}^{-1} \mathbf{H}_k\right)^{-1}\right)$ for TOA
    - Worst-case D-optimal: $\min_{r_i \in \mathbf{R}_i} \max_{k \in \{1, \ldots, K\}} \det\left(\left(\mathbf{H}_k^\top \mathbf{R}_\text{TOA}^{-1} \mathbf{H}_k\right)^{-1}\right)$ for TOA
    
    Analogous objectives for RSS by replacing $\mathbf{H}_k$ with $\mathbf{G}_k$ and $\mathbf{R}_\text{TOA}$ with $\alpha^{-2} \mathbf{R}_\text{RSS}$, where $\alpha = -10\eta$.
- **Constraints:** $r_i \in \mathbf{R}_i, \quad i=1,\ldots,m$: Sensor positions must lie within their respective feasible deployment regions.


### Optimization Algorithm

- **Algorithm Type:** Block majorization-minimization (MM) algorithm
- **Algorithm Parameters:** 
    - $\tilde{\mathbf{A}}_{k,i}^t = \sum_{h=1, h\neq i} \sigma_h^{-2} h_{k,h} h_{k,h}^\top$ for TOA
    - $\tilde{\mathbf{A}}_{k,i}^t = \sum_{h=1, h\neq i} \rho_h^{-2} g_{k,h} g_{k,h}^\top$ for RSS
    - $\alpha_{k,i}^t = \text{Tr}\left(\left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-1}\right)$ for A-optimal TOA
    - $\alpha_{k,i}^t = \det\left(\left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-1}\right)$ for D-optimal TOA
    - $\mathbf{A}_{k,i}^t = \sigma_i^{-2} \alpha_{k,i}^t \left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-2}$ for A-optimal TOA
    - $\mathbf{A}_{k,i}^t = \sigma_i^{-2} \alpha_{k,i}^t \left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-1}$ for D-optimal TOA
    - $\mathbf{B}_{k,i}^t = \sigma_i^{-2} \left(\tilde{\mathbf{A}}_{k,i}^t\right)^{-1}$
    - $\mathbf{D}_{k,i}^t = \mathbf{I}_n + \mathbf{B}_{k,i}^t$
    
    Analogous parameters for RSS by replacing $\sigma_i^2$ with $\rho_i^2$ and $\mathbf{H}_k$ with $\mathbf{G}_k$.

- **Algorithm Steps:**
    1. Initialize sensor positions $r_i^0 \in \mathbf{R}_i$, $i=1,\ldots,m$
    2. For $t=0,1,2,\ldots$
        1. For $i=1,\ldots,m$
            1. Compute $\tilde{\mathbf{A}}_{k,i}^t$, $\alpha_{k,i}^t$, $\mathbf{A}_{k,i}^t$, $\mathbf{B}_{k,i}^t$, $\mathbf{D}_{k,i}^t$
            2. Construct surrogate functions based on the design criteria
            3. Solve the corresponding convex optimization problem to update $r_i^{t+1}$
        2. End
    3. Until convergence
    4. Return $r_i^*$, $i=1,\ldots,m$

The algorithm monotonically decreases the objective function and converges to a stationary point under mild technical conditions, as proven in the paper.