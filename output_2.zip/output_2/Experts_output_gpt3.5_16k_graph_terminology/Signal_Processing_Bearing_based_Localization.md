2024-05-06 23:00:51.730759

### System Model
- **Problem Type:** Time-of-arrival (TOA) based wireless localization in the presence of non-line-of-sight (NLOS) propagation.
- **Problem Description:** The goal is to estimate the location of a mobile terminal (MT) using TOA measurements from multiple fixed terminals (FTs) in both line-of-sight (LOS) and NLOS scenarios. The NLOS propagation introduces a positive bias in the TOA measurements, which can degrade the localization accuracy if not mitigated.
- **System Model Parameters:**
  - $N$: Number of FTs
  - $\hat{d}_i$: Measured distance between the MT and the $i$-th FT
  - $d_i$: Actual distance between the MT and the $i$-th FT
  - $b_i$: NLOS bias for the $i$-th FT, where $b_i = 0$ for LOS FTs and $b_i = \psi_i$ for NLOS FTs
  - $n_i \sim \mathcal{N}(0, \sigma_i^2)$: Additive white Gaussian noise (AWGN) for the $i$-th FT
  - $\mathbf{x} = [x, y]^T$: Location of the MT
  - $\mathbf{x}_i = [x_i, y_i]^T$: Location of the $i$-th FT
- **System Model Formulations:** The measured distance between the MT and the $i$-th FT is modeled as:

$$\hat{d}_i = d_i + b_i + n_i = c t_i, \quad i = 1, 2, \ldots, N$$

where $c$ is the speed of light, and $t_i$ is the TOA of the signal at the $i$-th FT. The actual distance $d_i$ is related to the MT and FT locations by:

$$(x - x_i)^2 + (y - y_i)^2 = d_i^2, \quad i = 1, 2, \ldots, N$$


### Optimization Formulation
- **Optimization Type:** The optimization problem can be formulated as either a maximum likelihood estimation (MLE) problem or a least squares (LS) minimization problem, depending on the assumptions and constraints.
- **Optimization Parameters:**
  - $\hat{\mathbf{d}} = [\hat{d}_1, \hat{d}_2, \ldots, \hat{d}_N]^T$: Vector of measured distances
  - $\mathbf{d}(\mathbf{x}) = [d_1(\mathbf{x}), d_2(\mathbf{x}), \ldots, d_N(\mathbf{x})]^T$: Vector of actual distances as a function of the MT location $\mathbf{x}$
  - $\mathbf{b} = [b_1, b_2, \ldots, b_N]^T$: Vector of NLOS biases
  - $\mathbf{Q} = \text{diag}[\sigma_1^2, \sigma_2^2, \ldots, \sigma_N^2]^T$: Covariance matrix of the noise vector
- **Optimization Variables:** The optimization variable is the MT location $\mathbf{x} = [x, y]^T$.
- **Objective:** The objective can be either maximizing the likelihood function $p(\hat{\mathbf{d}} | \mathbf{x})$ or minimizing the squared residual error $\|\hat{\mathbf{d}} - \mathbf{d}(\mathbf{x})\|^2$.
- **Constraints:** Different algorithms may impose additional constraints, such as:
  - $b_i = 0$ for LOS FTs
  - $b_i \in [\ell_i, u_i]$ for NLOS FTs, where $\ell_i$ and $u_i$ are known lower and upper bounds on the NLOS bias
  - Geometric constraints based on the intersection points of the circles defined by the TOA measurements


### Optimization Algorithm
- **Algorithm Type:** The paper discusses various algorithms for solving the TOA-based localization problem, including:
  - ML algorithms (exact, two-step, approximate)
  - LS algorithms (non-linear, linearized, constrained)
  - Robust estimators (M-estimators, least median squares)
  - Identify and discard (IAD) techniques (residual test algorithm)
- **Algorithm Parameters:** The specific parameters depend on the chosen algorithm, but may include:
  - Initial estimate of the MT location
  - Thresholds for NLOS identification
  - Weighting factors for robust estimation
  - Convergence criteria and step sizes for iterative algorithms
- **Algorithm Steps:** The general steps for an iterative localization algorithm can be summarized as:
  1. Initialize the MT location estimate (e.g., using a coarse LS estimator)
  2. Identify potential NLOS FTs based on residuals or statistical tests
  3. Update the system model and objective function based on the identified NLOS FTs
  4. Solve the optimization problem to obtain a refined MT location estimate
  5. Check convergence criteria, and repeat steps 2-4 if necessary
  6. Terminate the algorithm and return the final MT location estimate

The specific mathematical formulations and update rules will depend on the chosen algorithm and the assumptions made regarding the NLOS bias and measurement noise distributions.