2024-05-06 23:00:51.730759

### System Model
- **Problem Type:** Beamforming for sensor array signal processing.
- **Problem Description:** The objective is to design a beamformer to enhance the desired signal while suppressing interference and noise for a sensor array.
- **System Model Parameters:**
  - $\mathbf{x}(t)$: Received signal vector of the sensor array.
  - $\mathbf{A}$: Steering matrix consisting of steering vectors corresponding to impinging signals.
  - $\mathbf{s}(t)$: Source signal vector.
  - $\mathbf{n}(t)$: Noise vector.
- **System Model Formulations:**
  - Narrowband: $\mathbf{x}(t) = \mathbf{A}\mathbf{s}(t) + \mathbf{n}(t)$