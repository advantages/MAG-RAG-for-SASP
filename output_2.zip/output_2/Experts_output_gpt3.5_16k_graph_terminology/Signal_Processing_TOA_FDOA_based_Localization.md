2024-05-06 23:00:51.730759

## System Model

- **Problem Type:** Localization of a signal source using Time Difference of Arrival (TDOA) and Frequency Difference of Arrival (FDOA) measurements.
- **Problem Description:** The goal is to estimate the location of a signal source using measurements of the TDOA and FDOA observed at multiple sensors. The TDOA measurement provides information about the difference in arrival time of the signal at different sensors, while the FDOA measurement provides information about the difference in frequency of the signal at different sensors.
- **System Model Parameters:**
  - $M$: Number of sensors
  - $(x_i, y_i)$: Position coordinates of the $i$-th sensor, $i = 1, 2, \ldots, M$
  - $\Delta t_i$: TDOA measurement of the signal at the $i$-th sensor
  - $\Delta f_i$: FDOA measurement of the signal at the $i$-th sensor
- **System Model Formulations:** The TDOA measurement between the $i$-th and $j$-th sensors can be related to the distance between the source and the sensors as:

$$\Delta t_{ij} = \frac{1}{c} \left(\sqrt{(x_i - x)^2 + (y_i - y)^2} - \sqrt{(x_j - x)^2 + (y_j - y)^2}\right)$$

where $(x, y)$ are the true coordinates of the source, and $c$ is the speed of light.

Similarly, the FDOA measurement between the $i$-th and $j$-th sensors can be related to the frequency difference between the source and the sensors as:

$$\Delta f_{ij} = \frac{1}{c} \left(\frac{f}{f_0} - \frac{f_i}{f_{0i}}\right)$$

where $f$ is the true frequency of the source, $f_0$ is the reference frequency, $f_i$ is the frequency at the $i$-th sensor, and $f_{0i}$ is the reference frequency at the $i$-th sensor.

The goal is to estimate the source coordinates $(x, y)$ from the TDOA and FDOA measurements.

## Optimization Formulation

- **Optimization Type:** Nonlinear least squares minimization problem.
- **Optimization Parameters:**
  - $\mathbf{t} = [\Delta t_1, \Delta t_2, \ldots, \Delta t_{\frac{M(M-1)}{2}}]$: Vector of TDOA measurements.
  - $\mathbf{f} = [\Delta f_1, \Delta f_2, \ldots, \Delta f_{\frac{M(M-1)}{2}}]$: Vector of FDOA measurements.
  - $\mathbf{x} = [x, y]^T$: Vector of source coordinates.
  - $\mathbf{x_i} = [x_i, y_i]^T$: Vector of sensor coordinates.
  - $\mathbf{d}(\mathbf{x}) = [\sqrt{(x_1 - x)^2 + (y_1 - y)^2}, \sqrt{(x_2 - x)^2 + (y_2 - y)^2}, \ldots, \sqrt{(x_M - x)^2 + (y_M - y)^2}]$: Vector of distances between the source and the sensors.
- **Optimization Variables:** The optimization variables are the source coordinates $\mathbf{x} = [x, y]^T$.
- **Objective:** The objective is to minimize the sum of squared differences between the measured TDOA and FDOA values and the values calculated from the source coordinates:

$$\text{minimize} \quad J(\mathbf{x}) = \sum_{k=1}^{\frac{M(M-1)}{2}}\left(\frac{1}{c} \left(\sqrt{(x_{i_k} - x)^2 + (y_{i_k} - y)^2} - \sqrt{(x_{j_k} - x)^2 + (y_{j_k} - y)^2}\right) - \Delta t_k\right)^2 + \sum_{k=1}^{\frac{M(M-1)}{2}}\left(\frac{1}{c} \left(\frac{f}{f_0} - \frac{f_{i_k}}{f_{0i_k}}\right) - \Delta f_k\right)^2$$

where $(i_k, j_k)$ are sensor indices for the $k$-th TDOA measurement, and $(i_k, i_k)$ are sensor indices for the $k$-th FDOA measurement.
- **Constraints:** None.

## Optimization Algorithm

- **Algorithm Type:** Gauss-Newton algorithm.
- **Algorithm Parameters:**
  - Initial estimate of source coordinates: $\mathbf{x}_{\text{init}}$
  - Convergence threshold: $\epsilon$
  - Maximum number of iterations: $N_{\text{max}}$
- **Algorithm Steps:**
  1. Initialize the source coordinates: $\mathbf{x}^{(0)} = \mathbf{x}_{\text{init}}$
  2. Set the iteration counter: $n = 0$
  3. Repeat until convergence or maximum iterations reached:
     - a. Calculate the Jacobian matrix $\mathbf{J}$ with respect to the source coordinates:
       - For TDOA measurements: $\mathbf{J}_{\Delta t} = \frac{\partial \text{vec}(\Delta \mathbf{t})}{\partial \text{vec}(\mathbf{x})}$, where $\text{vec}(\mathbf{x})$ vectorizes the matrix $\mathbf{x}$.
       - For FDOA measurements: $\mathbf{J}_{\Delta f} = \frac{\partial \text{vec}(\Delta \mathbf{f})}{\partial \text{vec}(\mathbf{x})}$, where $\text{vec}(\mathbf{f})$ vectorizes the matrix $\mathbf{f}$.
     - b. Calculate the residual vectors for TDOA and FDOA:
       - TDOA: $\mathbf{r}_{\Delta t} = \text{vec}(\mathbf{d}(\mathbf{x}^{(n)}) - \frac{c}{\sqrt{(x_{i_k}^{(n)} - x)^2 + (y_{i_k}^{(n)} - y)^2}} + \sqrt{(x_{j_k}^{(n)} - x)^2 + (y_{j_k}^{(n)} - y)^2}} - \Delta \mathbf{t})$
       - FDOA: $\mathbf{r}_{\Delta f} = \text{vec}\left(\frac{f}{f_0} - \frac{f_{i_k}^{(n)}}{f_{0i_k}} - \Delta \mathbf{f}\right)$
     - c. Calculate the total residual vector: $\mathbf{r} = \begin{bmatrix} \mathbf{r}_{\Delta t} \\ \mathbf{r}_{\Delta f} \end{bmatrix}$
     - d. Calculate the Gauss-Newton update: $\delta \mathbf{x} = -(\mathbf{J}^T \mathbf{J})^{-1}\mathbf{J}^T \mathbf{r}$
     - e. Update the source coordinates: $\mathbf{x}^{(n+1)} = \mathbf{x}^{(n)} + \delta \mathbf{x}$
     - f. Increment the iteration counter: $n \leftarrow n+1$
     - g. Check for convergence: If $\|\delta \mathbf{x}\| < \epsilon$ or $n > N_{\text{max}}$, terminate the algorithm.
  4. Return the estimated source coordinates: $\hat{\mathbf{x}} = \mathbf{x}^{(n)}$