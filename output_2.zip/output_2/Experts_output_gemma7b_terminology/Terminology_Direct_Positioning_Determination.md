2024-05-07 11:13:33.796124

## Paper_29: An Overview of Signal Processing Techniques for Joint Communication and Radar Sensing

**1. Paper Title:** An Overview of Signal Processing Techniques for Joint Communication and Radar Sensing

**2. Authors:** J. Andrew Zhang, Fan Liu, Christos Masouros, Robert W. Heath, Jr., Zhiyong Feng, Le Zheng, and Athina Petropulu

**3. Publication Date:** November 2021

**4. File Name:** Zhang_Nov2021_AnOverviewOfSignalProcessingTechniquesFor.md

**Abstract:**

This paper presents an overview of signal processing techniques for joint communication and radar (JCR) systems. It covers communication-centric, radar-centric, and joint design and optimization approaches for JCR systems.

**Problem:**

The problem is to accurately extract the position of the signal source and determine the signal power at a given location in space.

**Solution:**

The solution involves using signal processing techniques to analyze the received signal and determine the position and signal power of the signal source.

**Conclusion:**

The paper concludes by summarizing the key points and potential applications of the signal processing techniques discussed in the paper. It encourages further exploration of these techniques and their potential applications in JCR systems.