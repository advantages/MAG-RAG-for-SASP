2024-05-07 11:13:33.796124

## Paper 29: An Overview of Signal Processing Techniques for Joint Communication and Radar Sensing

**Abstract:**

This paper presents an overview of signal processing techniques for joint communication and radar (JCR) systems. It covers communication-centric, radar-centric, and joint design and optimization approaches for JCR systems.

**Problem:**

The problem is to localize the signal source by making use of the TDOA and FDOA measurements.

**Solution:**

The solution is to use a tripartite methodology to find the optimal location for the signal source.

**Conclusion:**

This paper provides an overview of signal processing techniques for JCR systems. It is intended to provide guidance and insights for engineers who are designing and deploying these systems.