2024-05-07 11:13:33.796124

## Signal Estimation Problem Framework

**System Model:**

**Problem Type:** Beamforming for Signal-to-Interference Plus Noise Ratio Maximization

**Problem Description:**

A uniform linear array of N elements spaced half a wavelength apart receives a signal from a source at angle Theta. There are P interference sources emitting signals from angles Phi_p (p = 1, 2, ..., P). The goal is to maximize the signal-to-interference plus noise ratio (SINR) at the beamform output.

**System Model Parameters:**

- N: Number of array elements
- Theta: Angle of the signal source
- Phi_p: Angles of the interference sources
- S_p: Power of the interference source p
- N_s: Power of the signal source
- W: Array weight vector
- H: Channel matrix

**System Model Formulations:**

- **Signal Model:**

$$y = Hw + n$$

where:

- y is the output vector
- H is the channel matrix
- w is the array weight vector
- n is the noise vector

- **SINR:**

$$SINR = \frac{S_s}{N_t + S_I}$$

where:

- S_s is the signal power
- N_t is the total noise power
- S_I is the total interference power

**Optimization Formulation:**

**Optimization Type:** Convex Optimization

**Optimization Parameters:**

- W_opt: Optimal array weight vector

**Optimization Variables:**

- W

**Objective:**

Maximize SINR

**Constraints:**

- **Norm Constraint:** ||W|| = 1
- **Non-negativity Constraint:** W >= 0

**Optimization Algorithm:**

**Algorithm Type:** Gradient-Based Search

**Algorithm Parameters:**

- Learning rate: Lambda
- Number of iterations: N_iter

**Algorithm Steps:**

1. Initialize W with random values.
2. Iterate for N_iter iterations:
    - Calculate the gradient of the objective function with respect to W.
    - Update W in the direction of the gradient.
    - Normalize W to ensure the norm constraint is met.
    - Check if the stopping criteria are met. If they are, exit the loop.
3. Output the optimal W.

**Optimal Expression for Array Weight Vector:**

$$W_opt = \frac{H^T(S_s + N_t)H}{H^T(S_s + N_t)H + I}$$