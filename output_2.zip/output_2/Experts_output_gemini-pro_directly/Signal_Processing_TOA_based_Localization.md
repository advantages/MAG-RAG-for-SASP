2024-05-02 12:33:28.382581

---
## System Model
### Problem Type:
 Localization Problem

### Problem Description:
The problem seeks to pinpoint the location of a signal source utilizing Time of Arrival (TOA) measurements acquired from an array of sensors with known positions. Each sensor registers and records the specific time of arrival for the signal emitted by the source. The objective is to harness these TOA measurements to determine the source's position accurately.

### System Model Parameters:
- \(\mathbf{s}=(x_s,y_s)\): The unknown coordinates of the signal source.
- \(\mathbf{x}_i=(x_i,y_i)\), \(i=1,2,\ldots,M\): Known coordinates of the \(M\) sensors.
- \(t_i\): Time of Arrival measurement at sensor \(i\).
- \(c\): Signal propagation speed, assumed to be constant.

### System Model Formulations:
 The relationship between the signal source and sensor locations, along with the time of arrival measurements, can be mathematically expressed as:
$$
t_i=\frac{\Vert \mathbf{x}_i-\mathbf{s} \Vert}{c}
$$

---
## Optimization Formulation
### Optimization Type:
 Non-linear Least Squares

### Optimization Parameters:
- \(\mathbf{s}\): Coordinates of the signal source.

### Optimization Variables:
- \(\mathbf{s}\): Coordinates of the signal source.

### Objective:
 Minimize the sum of squared differences between the measured TOA values and those predicted by the model:
$$
\min_{\mathbf{s}} \sum_{i=1}^M (t_i-\frac{\Vert \mathbf{x}_i-\mathbf{s} \Vert}{c})^2
$$

### Constraints:
- None

---
## Optimization Algorithm
### Algorithm Type:
 Levenberg-Marquardt Algorithm

### Algorithm Parameters:
- Learning Rate: \(\alpha\)
- Convergence Threshold: \(\epsilon\)

### Algorithm Steps:
1. **Initialization**: Set an initial estimate for the source location \(\mathbf{s}_0\)
2. **Iteration**:
 - Update the source location estimate:
$$
\mathbf{s}_{k+1} = \mathbf{s}_k - \alpha J^T J^{-1} r_k
$$
where \(J\) is the Jacobian matrix and \(r_k\) is the residual vector.
 - Calculate the new residual vector:
$$
r_{k+1} = \mathbf{t} - \mathbf{h}(\mathbf{s}_{k+1})
$$
where \(\mathbf{t}\) is the vector of TOA measurements and \(\mathbf{h}(\mathbf{s})\) is the vector of predicted TOA values based on the current source location estimate.
 - Update the learning rate:
$$
\alpha_{k+1} = \begin{cases}
\beta \alpha_k & \text{if } f(\mathbf{s}_{k+1}) < f(\mathbf{s}_k) \\
\alpha_k/\beta & \text{otherwise}
\end{cases}
$$
where \(\beta>1\) is a constant.
 3. **Termination**: Terminate the algorithm when the norm of the residual vector is less than the convergence threshold \(\epsilon\).