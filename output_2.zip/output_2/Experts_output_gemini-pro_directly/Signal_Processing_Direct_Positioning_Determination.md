2024-05-02 12:33:28.382581

**System Model**

- **Problem Type:** Source Localization using Sensor Arrays
- **Problem Description:** An array of \(\text{M}\) sensors is deployed in a 2D space, aiming to estimate the location of a signal source that continuously emits signals. Each sensor is equipped with one antenna and can independently upload received signal samples to a data fusion center.
- **System Model Parameters:**
    - \(M\): Number of sensors
    - \(x\), \(y\): Coordinates of the signal source
    - \(x_i\), \(y_i\): Coordinates of the \((i\)-th\) sensor
    - \(s\): Signal transmitted by the source
    - \(n_i\): Noise at the \((i\)-th\) sensor
- **System Model Formulations:**
    - Received signal at the \((i\)-th\) sensor: $$r_i = s \ast h_i + n_i$$
    - Channel impulse response between the source and the \((i\)-th\) sensor: $$h_i = \delta(t - \tau_i)$$
    - Time delay: $$\tau_i = \frac{\sqrt{(x-x_i)^2+(y-y_i)^2}}{c}$$

**Optimization Formulation**

- **Optimization Type:** Maximum Likelihood Estimation (MLE)
- **Optimization Parameters:**
    - Received signal samples from all sensors
    - Coordinates of the sensors
- **Optimization Variables:**
    - Coordinates of the signal source: \((x, y)\)
- **Objective:**
    - Maximize the likelihood function: $$L(x, y) = \prod_{i=1}^{M} p(r_i | s, h_i)$$
- **Constraints:**
    - None

**Optimization Algorithm**

- **Algorithm Type:** Iterative Gradient Descent
- **Algorithm Parameters:**
    - Learning rate: \(\alpha\)
    - Convergence threshold: \(\epsilon\)
- **Algorithm Steps:**
    - Initialize the source location estimate: \((x_0, y_0)\)
    - Iteratively update the estimate using the gradient of the likelihood function: $$x_{k+1} = x_k - \alpha \nabla_x L(x_k, y_k)$$
    - Terminate the algorithm when the change in the estimate falls below the threshold: $$\sqrt{(x_{k+1} - x_k)^2 + (y_{k+1} - y_k)^2} < \epsilon$$