2024-05-02 12:33:28.382581

## System Model
### Problem Type:
Localization using Sensor Array Signal Processing

### Problem Description:
Given M sensors at distinct positions \((x_i, y_i)\), i = 1, 2, ..., M, each sensor can measure the bearing angle of a signal source corrupted by additive Gaussian noise. \(\theta_i\) denotes the measured angle of sensor i. The objective is to determine the coordinates of the signal source based on these bearing angle measurements.

### System Model Parameters:
- Number of sensors: M
- Sensor positions: \((x_i, y_i)\), i = 1, 2, ..., M
- Measured bearing angles: \(\theta_i\), i = 1, 2, ..., M
- Source coordinates: \((x_s, y_s)\)
- Noise standard deviation: \(\sigma\)

### System Model Formulations:
The relationship between the sensor positions, source coordinates, and bearing angles can be expressed as:

$$
\theta_i = \arctan\left(\frac{y_s - y_i}{x_s - x_i}\right) + \epsilon_i
$$

where \(\epsilon_i\) is the additive noise.

## Optimization Formulation
### Optimization Type:
Non-linear Least Squares (NLS)

### Optimization Parameters:
- Sensor positions: \((x_i, y_i)\), i = 1, 2, ..., M
- Measured bearing angles: \(\theta_i\), i = 1, 2, ..., M
- Noise standard deviation: \(\sigma\)

### Optimization Variables:
- Source coordinates: \((x_s, y_s)\)

### Objective:
Minimize the sum of squared residuals:

$$
J(x_s, y_s) = \sum_{i=1}^M \left(\theta_i - \arctan\left(\frac{y_s - y_i}{x_s - x_i}\right)\right)^2
$$

### Constraints:
- None

## Optimization Algorithm
### Algorithm Type:
Levenberg-Marquardt Algorithm

### Algorithm Parameters:
- Initial guess for source coordinates: \((x_{s0}, y_{s0})\)
- Convergence threshold: \(\epsilon\)

### Algorithm Steps:
1. **Initialize:** Set \((x_s^0, y_s^0) = (x_{s0}, y_{s0})\)
2. **Iterate:**
   a. Compute the Jacobian matrix:
   $$
   J = \begin{bmatrix}
   \frac{\partial J}{\partial x_s} & \frac{\partial J}{\partial y_s}
   \end{bmatrix}
   $$

   b. Update the source coordinates:
   $$
   \begin{bmatrix}
   x_s^{k+1} \\
   y_s^{k+1}
   \end{bmatrix} = \begin{bmatrix}
   x_s^k \\
   y_s^k
   \end{bmatrix} - \lambda J^T J^{-1} \nabla J
   $$

   where \(\lambda\) is the damping factor.
3. **Check for convergence:**
   a. If \(\left\Vert \begin{bmatrix}
   x_s^{k+1} \\
   y_s^{k+1}
   \end{bmatrix} - \begin{bmatrix}
   x_s^k \\
   y_s^k
   \end{bmatrix}\right\Vert < \epsilon\), then stop.
   b. Otherwise, increment k and go to step 2.

4. **Output:** The estimated source coordinates \((x_s, y_s)\) are obtained.