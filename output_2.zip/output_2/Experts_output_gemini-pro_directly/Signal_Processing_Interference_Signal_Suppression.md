2024-05-02 12:33:28.382581

```md
## Signal Processing Problem Formulation

### System Model
- **Problem Type:** Uniform Linear Array Signal Processing for Angle Estimation
- **Problem Description:**
   - A uniform linear array (ULA) with \(N\) elements, spaced half a wavelength apart, receives signals from:
     - A single signal source located at an angle \(\theta\)
     - \(P\) interference sources located at angles \(\phi_1, \phi_2, ..., \phi_P\)
- **System Model Parameters:**
   - Array element spacing: \(\lambda/2\)
   - Number of array elements: \(N\)
   - Signal source angle: \(\theta\)
   - Interference source angles: \(\phi_1, \phi_2, ..., \phi_P\)
   - Signal of interest (SOI): \(s(t)\)
   - Interference signals: \(i_1(t), i_2(t), ..., i_P(t)\)
   - Noise: \(n(t)\)
- **System Model Formulations:**
   - Array output signal: \(x(t) = s(t)a(\theta) + \sum_{p=1}^P i_p(t)a(\phi_p) + n(t)\)
   - Array response vector: \(a(\phi) = [1,  e^{-j2\pi(\lambda/2)\sin(\phi)}, ..., e^{-j2\pi(\lambda/2)(N-1)\sin(\phi)}]^T\)

### Optimization Formulation
- **Optimization Type:** Beamforming
- **Optimization Parameters:**
   - Array weights: \(w_1, w_2, ..., w_N\)
- **Optimization Variables:**
   - Array weight vector: \(\mathbf{w} = [w_1, w_2, ..., w_N]^T\)
- **Objective:**
   - Maximize signal-to-interference-plus-noise ratio (SINR):
     - $$SINR = \frac{|s(\theta)\mathbf{w}^Ha(\theta)|^2}{\sum_{p=1}^P |i_p(\theta)\mathbf{w}^Ha(\phi_p)|^2 + \sigma_n^2||\mathbf{w}||^2}$$
- **Constraints:**
   - Unit norm constraint: \(\mathbf{w}^H\mathbf{w} = 1\)

### Optimization Algorithm
- **Algorithm Type:** Linear Conjugate Gradient (LCG)
- **Algorithm Parameters:**
   - Step size: \(\eta\)
   - Maximum iterations: \(K\)
- **Algorithm Steps:**
   1. Initialize weight vector \(\mathbf{w}_0\)
   2. Compute gradient \(\nabla f(\mathbf{w}_k)\)
   3. Compute conjugate direction \(\mathbf{d}_k\): \(\mathbf{d}_k = -\nabla f(\mathbf{w}_k) + \beta_k\mathbf{d}_{k-1}\)
   4. Line search to find step size \(\eta_k\)
   5. Update weight vector: \(\mathbf{w}_{k+1} = \mathbf{w}_k + \eta_k\mathbf{d}_k\)
   6. Repeat steps 2-5 until convergence or maximum iterations reached

### Optimal Array Weight Vector
The optimal array weight vector \(\mathbf{w}_{opt}\) is given by:
$$\mathbf{w}_{opt} = \frac{\mathbf{R_s}^{-1}\mathbf{a}(\theta)}{\mathbf{a}^H(\theta)\mathbf{R_s}^{-1}\mathbf{a}(\theta)}$$

where \(\mathbf{R_s}\) is the covariance matrix of the received signal.
```