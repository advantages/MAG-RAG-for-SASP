2024-05-02 12:33:28.382581

### System Model
- **Problem Type:** Distributed Antenna Array Signal Detection for Primary Signal Detection
- **Problem Description:** A sensor network of $p$ distributed antennas aims to detect the presence of primary signals continuously transmitted from an unknown location. These signals have limited bandwidth and contain segmental information, and the objective is to maximize the detection capabilities of the antenna array.
- **System Model Parameters:**
    - p: Number of distributed antennas
    - s(t): Transmitted primary signal
    - r_i(t): Received signal at antenna i
    - h_i: Channel impulse response between the signal emitter and antenna i
    - n_i(t): Additive white Gaussian noise at antenna i
    - SNR: Signal-to-noise ratio at the antenna array
- **System Model Formulations:**
    - Received Signal at Antenna i:
      $$r_i(t) = s(t) * h_i + n_i(t)$$
    - Array Output:
      $$y(t) = [r_1(t), r_2(t), ..., r_p(t)]^T$$
    - Spatial Correlation Matrix:
      $$R_s = E[y(t)y(t)^H]$$

### Optimization Formulation
- **Optimization Type:** Multi-Antenna Maximum Likelihood Estimation
- **Optimization Parameters:**
    - y(t): Array output
    - s(t): Transmitted primary signal
    - R_s: Spatial correlation matrix
    - SNR: Signal-to-noise ratio
- **Optimization Variables:**
    - s(t): Transmitted primary signal
- **Objective:**
    $$max_{s(t)} \prod_{i=1}^p p_i(r_i(t)|s(t))$$
- **Constraints:**
    - Signal Power Constraint:
      $$P_s = \int_{-\infty}^{\infty} |s(t)|^2 dt < P_s^{max}$$

### Optimization Algorithm
- **Algorithm Type:** Expectation-Maximization (EM) Algorithm
- **Algorithm Parameters:**
    - Number of EM iterations: K
    - Initial estimate of s(t): s_0(t)
- **Algorithm Steps:**
    1. **E-Step:**
      - Update the posterior distribution of s(t):
        $$p(s(t)|y(t)) \propto p(y(t)|s(t))p(s(t))$$
    2. **M-Step:**
      - Update the maximum likelihood estimate of s(t):
        $$s_{k+1}(t) = argmax_s(t) \int_{-\infty}^{\infty} p(s(t)|y(t))log(p(y(t)|s(t)))ds(t)$$
    3. Repeat steps 1 and 2 for K iterations or until convergence.