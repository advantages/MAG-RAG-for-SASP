2024-05-02 12:33:28.382581

## System Model
- **Problem Type:** Sensor array signal processing (Source Localization)
- **Problem Description:** Localizing a signal source using Time Difference of Arrival (TDOA) and Frequency Difference of Arrival (FDOA) measurements from multiple sensors.
- **System Model Parameters:**
    - $M$: Number of sensors
    - $(\var{x_i}, \var{y_i})$: Position of the $i$th sensor
    - $\tau_i$: TDOA measurement from the $i$th sensor
    - $f_i$: FDOA measurement from the $i$th sensor
    - $c$: Speed of signal propagation
    - $\lambda$: Wavelength of the signal
- **System Model Formulations:**
    - TDOA: $$\tau_i = \frac{d_i - d_1}{c}$$
    - FDOA: $$f_i = \frac{d_i - d_1}{\lambda}$$
    where $d_i$ is the distance between the signal source and the $i$th sensor, and $d_1$ is the distance between the signal source and the reference sensor.

## Optimization Formulation
- **Optimization Type:** Nonlinear least squares optimization
- **Optimization Parameters:**
    - $(\var{x_s}, \var{y_s})$: Position of the signal source
- **Optimization Variables:**
    - $(\var{x_s}, \var{y_s})$
- **Objective:**
    - Minimize the sum of squared errors: $$J(\var{x_s}, \var{y_s}) = \sum_{i=1}^M \left(\tau_i - \frac{d_i - d_1}{c}\right)^2 + \left(f_i - \frac{d_i - d_1}{\lambda}\right)^2$$
- **Constraints:**
    - None

## Optimization Algorithm
- **Algorithm Type:** Gauss-Newton method
- **Algorithm Parameters:**
    - Initial guess: $(\var{x_s}^0, \var{y_s}^0)$
    - Convergence threshold: $\epsilon$
- **Algorithm Steps:**
    1. Initialize $(\var{x_s}^0, \var{y_s}^0)$.
    2. Calculate the gradient and Hessian of $J(\var{x_s}, \var{y_s})$.
    3. Solve for the update: $$\begin{bmatrix} \var{x_s}^{k+1} \\\ \var{y_s}^{k+1} \end{bmatrix} = \begin{bmatrix} \var{x_s}^k \\\ \var{y_s}^k \end{bmatrix} - \left(\nabla^2 J(\var{x_s}^k, \var{y_s}^k)\right)^{-1} \nabla J(\var{x_s}^k, \var{y_s}^k)$$.
    4. If the convergence criterion is met (i.e., $$\left\Vert \begin{bmatrix} \var{x_s}^{k+1} \\\ \var{y_s}^{k+1} \end{bmatrix} - \begin{bmatrix} \var{x_s}^k \\\ \var{y_s}^k \end{bmatrix} \right\Vert < \epsilon$$), stop. Otherwise, set $k = k+1$ and go to Step 2.