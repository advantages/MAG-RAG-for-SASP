2024-05-02 12:33:28.382581

## Signal Processing Problem Formulation

### System Model

- **Problem Type:** Source Localization
- **Problem Description:** A uniform linear array (ULA) consisting of N equally spaced elements receives signals emanating from a far-field source impinging at an unknown angle θ. The objective is to estimate θ accurately using signal samples obtained over a finite time.
- **System Model Parameters:**
    - N: Number of array elements
    - λ: Wavelength of the signal
    - d: Spacing between array elements (d = λ/2 for ULA)
    - θ: Angle of signal arrival (AoA)
    - K: Number of sampled signal segments

- **System Model Formulations:**

The received signal at the nth array element can be expressed as:

$$x_n[k] = s[k] \cdot e^{-j2\pi (n-1)d \sin(\theta)/\lambda}$$

where:
- s[k] is the transmitted signal at time k
- e^{-j2\pi (n-1)d \sin(\theta)/\lambda} represents the phase shift due to the spatial separation between the array elements

The received signal vector can be represented as:

$$\mathbf{x}[k] = \mathbf{a}(\theta) s[k]$$

where:

- $\mathbf{x}[k] = [x_1[k], x_2[k], ..., x_N[k]]^T$ is the received signal vector at time k
- $\mathbf{a}(\theta) = [1, e^{-j2\pi d \sin(\theta)/\lambda}, ..., e^{-j2\pi (N-1)d \sin(\theta)/\lambda}]^T$ is the steering vector corresponding to the AoA θ

### Optimization Formulation

- **Optimization Type:** Maximum Likelihood Estimation (MLE)
- **Optimization Parameters:**
    - θ: Angle of signal arrival
    - $\mathbf{x}[k]$: Received signal vector over K segments
- **Optimization Variables:** θ
- **Objective:** Maximize the likelihood function:
$$L(\theta) = \prod_{k=1}^{K} p(\mathbf{x}[k] | \theta)$$
where $p(\mathbf{x}[k] | \theta)$ is the probability density function of the received signal vector given the AoA θ
- **Constraints:** None

### Optimization Algorithm

- **Algorithm Type:** Gradient Ascent
- **Algorithm Parameters:**
    - Step size: η
    - Maximum number of iterations: I
- **Algorithm Steps:**

1. Initialize θ = θ_0
2. For t = 1 to I:
    a. Compute the gradient of the likelihood function:
    $$\nabla_{\theta} L(\theta) = \sum_{k=1}^{K} \frac{\partial p(\mathbf{x}[k] | \theta)}{\partial \theta}$$
    b. Update θ:
    $$\theta_{t+1} = \theta_t + \eta \nabla_{\theta} L(\theta_t)$$
3. Return the estimated AoA: $\hat{\theta} = \theta_I$

### Simulation Code (MATLAB)

```
% Parameters
N = 10; % Number of array elements
d = 0.5; % Element spacing (half-wavelength)
theta_true = 30; % True AoA
K = 100; % Number of signal segments
SNR = 10; % Signal-to-noise ratio

% Signal and noise generation
s = randn(1, K) + 1j * randn(1, K); % Transmitted signal
noise = 1/sqrt(2*SNR) * (randn(N, K) + 1j * randn(N, K)); % Noise

% Received signal
x = zeros(N, K);
for n = 1:N
    x(n, :) = exp(-1j * 2 * pi * (n-1) * d * sind(theta_true) / lambda) .* s + noise(n, :);
end

% AoA estimation
theta_hat = zeros(1, K);
for k = 1:K
    steering_vector = exp(-1j * 2 * pi * (0:N-1)' * d * sind(theta_true) / lambda);
    theta_hat(k) = angle(x(:, k)' * steering_vector / norm(steering_vector));
end

% Accuracy evaluation
RMSE = sqrt(mean((theta_hat - theta_true * ones(1, K)).^2));

```