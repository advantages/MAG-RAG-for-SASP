2024-06-10 23:16:57.553947

### System Model
- **Problem Type:** Sensor array signal processing for wireless localization in the presence of a jammer node
- **Problem Description:** Consider a wireless localization network in a two-dimensional space consisting of $N_A$ anchor nodes at known locations $\boldsymbol{y}_i \in \mathbb{R}^2, i=1, \ldots, N_A$ and $N_T$ target nodes at unknown locations $\boldsymbol{x}_i \in \mathbb{R}^2, i=1, \ldots, N_T$, which aim to estimate their locations based on signals received from the anchor nodes. There is also a jammer node located at $\boldsymbol{z} \in \mathbb{R}^2$, which transmits zero-mean Gaussian noise to degrade the localization performance.
- **System Model Parameters:**
    - $N_A$: Number of anchor nodes
    - $N_T$: Number of target nodes
    - $\boldsymbol{y}_i \in \mathbb{R}^2$: Location of the $i$-th anchor node
    - $\boldsymbol{x}_i \in \mathbb{R}^2$: Location of the $i$-th target node
    - $\boldsymbol{z} \in \mathbb{R}^2$: Location of the jammer node
    - $\mathcal{A}_i$: Set of anchor nodes connected to the $i$-th target node
    - $L_{ij}$: Number of multipath components between anchor node $j$ and target node $i$
    - $\alpha^k_{ij}$: Amplitude of the $k$-th multipath component between anchor node $j$ and target node $i$
    - $\tau^k_{ij}$: Delay of the $k$-th multipath component between anchor node $j$ and target node $i$
    - $b^k_{ij}$: Range bias for the $k$-th multipath component between anchor node $j$ and target node $i$
    - $P_J$: Transmit power of the jammer node
    - $\gamma_{ij}$: Channel coefficient between the jammer node and the $i$-th target node for signals from anchor node $j$
    - $N_0/2$: Spectral density level of the measurement noise
- **System Model Formulations:** The received signal at the $i$-th target node from the $j$-th anchor node is modeled as:

$$r_{ij}(t) = \sum_{k=1}^{L_{ij}} \alpha^k_{ij} s_j\left(t - \tau^k_{ij}\right) + \gamma_{ij} \sqrt{P_J} v_{ij}(t) + n_{ij}(t), \quad \text{for } t \in [0, T_{\text{obs}}], i \in \{1, \ldots, N_T\}, j \in \mathcal{A}_i$$

where $s_j(t)$ is the known transmitted signal from anchor node $j$, $v_{ij}(t)$ is the zero-mean white Gaussian jammer noise, and $n_{ij}(t)$ is the zero-mean white Gaussian measurement noise.

The delay $\tau^k_{ij}$ is expressed as:

$$\tau^k_{ij} = \frac{\|\boldsymbol{y}_j - \boldsymbol{x}_i\| + b^k_{ij}}{c}$$

where $c$ is the speed of propagation.


### Optimization Formulation
- **Optimization Type:** Non-convex optimization problem
- **Optimization Parameters:**
    - $\epsilon > 0$: Lower limit for the distance between a target node and the jammer node
    - $\tilde{K}_i$: Unitless constant depending on antenna characteristics and average channel attenuation for target node $i$
    - $d_0$: Reference distance for the antenna far-field
    - $\nu$: Path-loss exponent (typically between 2 and 4)
- **Optimization Variables:** $\boldsymbol{z} \in \mathbb{R}^2$: Location of the jammer node
- **Objective:** Maximize the minimum of the CRLBs for the target nodes:

$$\max_{\boldsymbol{z}} \min_{i \in \{1, \ldots, N_T\}} \text{tr}\left(\boldsymbol{J}_i(\boldsymbol{x}_i, P_J)^{-1}\right)$$

where $\text{tr}(\cdot)$ denotes the trace operator, and $\boldsymbol{J}_i(\boldsymbol{x}_i, P_J)$ is the equivalent Fisher information matrix for the $i$-th target node.

- **Constraints:** $\|\boldsymbol{z} - \boldsymbol{x}_i\| \geq \epsilon, \quad i = 1, \ldots, N_T$

The channel power gain between the jammer node and the $i$-th target node is modeled as:

$$|\gamma_{ij}|^2 = \tilde{K}_i \left(\frac{d_0}{\|\boldsymbol{z} - \boldsymbol{x}_i\|}\right)^\nu, \quad \text{for } \|\boldsymbol{z} - \boldsymbol{x}_i\| > d_0$$


### Optimization Algorithm
- **Algorithm Type:** Theoretical analysis and simplification of the optimization problem under various conditions
- **Algorithm Parameters:** N/A
- **Algorithm Steps:**
    1. If $N_T = 1$, the optimal jammer location can be chosen as any point at a distance of $\epsilon$ from the target node.
    2. If $N_T = 2$, the optimal jammer location can be obtained explicitly based on Proposition 3 in the paper, which provides closed-form solutions or a simple one-dimensional search.
    3. If $N_T \geq 3$:
        a. If the conditions in Proposition 1 hold, the optimal jammer location is at a distance of $\epsilon$ from a specific target node.
        b. If the conditions in Proposition 2 hold, the optimal jammer location is determined by two of the target nodes, as described in Proposition 3.
        c. Otherwise:
            i. For each distinct group of three target nodes, say $\ell_1, \ell_2$, and $\ell_3$:
                - Calculate the pairwise CRLBs considering the equalizer property in Corollary 1, and determine the minimum, say $\text{CRLB}_{\ell_1, \ell_2}$.
                - If the condition in Proposition 6(b) holds, set $\text{CRLB}_{\ell_1, \ell_2, \ell_3}$ to $\text{CRLB}_{\ell_1, \ell_2}$.
                - Otherwise, obtain $\text{CRLB}_{\ell_1, \ell_2, \ell_3}$ from the equalizer constraint specified in Proposition 5.
            ii. Determine the minimum of the $\text{CRLB}_{\ell_1, \ell_2, \ell_3}$ terms and the corresponding optimal location, $\boldsymbol{z}_{\text{unc}}^{\text{opt}}$ (optimal location in the absence of distance constraints).
            iii. If $\boldsymbol{z}_{\text{unc}}^{\text{opt}}$ is feasible according to the distance constraints, then the optimal jammer location is $\boldsymbol{z}_{\text{unc}}^{\text{opt}}$. Otherwise, solve the original optimization problem directly to obtain the optimal jammer location.