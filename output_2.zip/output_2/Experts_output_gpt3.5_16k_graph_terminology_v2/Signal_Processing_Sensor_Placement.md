2024-06-10 23:16:57.553947

### System Model
- **Problem Type:** Sensor array signal processing problem for colocated MIMO radar systems
- **Problem Description:** The problem involves designing transmit waveforms and receive filters for a colocated MIMO radar system with Nt transmit and Nr receive antennas. The system operates in the presence of signal-dependent interference from K uncorrelated point-like interferers and additive white Gaussian noise.
- **System Model Parameters:**
    - $\alpha$: Complex amplitude of the target's radar cross-section (RCS) with $\mathbb{E}[|\alpha|^2] = \sigma_0^2$
    - $\nu_0$: Doppler frequency of the target
    - $\mathbf{a}_t(\theta)$: Nt × 1 transmit steering vector
    - $\mathbf{a}_r(\theta)$: Nr × 1 receive propagation vector
    - $\alpha_k$: Complex amplitude of the k-th interferer with $\mathbb{E}[|\alpha_k|^2] = \sigma_k^2$
    - $\nu_k$: Doppler frequency of the k-th interferer
    - $\sigma_v^2$: Variance of the additive white Gaussian noise
- **System Model Formulations:**
    - Received signal at time n: $\mathbf{x}(n) = \alpha \mathbf{a}_r(\theta_0) \mathbf{a}_t^T(\theta_0) \mathbf{s}(n) e^{j2\pi(n-1)\nu_0} + \sum_{k=1}^K \alpha_k \mathbf{a}_r(\theta_k) \mathbf{a}_t^T(\theta_k) \mathbf{s}(n-r_k) e^{j2\pi(n-1)\nu_k} + \mathbf{v}(n)$
    - Vectorized received signal: $\mathbf{x} = \alpha \mathbf{A}_0 \mathbf{s} + \sum_{k=1}^K \alpha_k \mathbf{A}_k \mathbf{s} + \mathbf{v}$
    - Output of linear receive filter $\mathbf{w}$: $r = \mathbf{w}^H \mathbf{x} = \alpha \mathbf{w}^H \mathbf{A}_0 \mathbf{s} + \sum_{k=1}^K \alpha_k \mathbf{w}^H \mathbf{A}_k \mathbf{s} + \mathbf{w}^H \mathbf{v}$
    - SINR expression: $\text{SINR} = \frac{\sigma_0^2 |\mathbf{w}^H \mathbf{A}_0 \mathbf{s}|^2}{\mathbf{w}^H \left(\sum_{k=1}^K \sigma_k^2 \mathbf{A}_k \mathbf{s}\mathbf{s}^H \mathbf{A}_k^H\right) \mathbf{w} + \sigma_v^2 \|\mathbf{w}\|^2}$


### Optimization Formulation
- **Optimization Type:** Non-convex fractional quadratic constrained optimization problem
- **Optimization Parameters:**
    - $\mathbf{A}_0$: System matrix for the target signal
    - $\mathbf{A}_k$: System matrix for the k-th interferer signal
    - $q_k = \sigma_k^2 / \sigma_v^2$: Normalized interference power for the k-th interferer
    - $\mathbf{\Psi}(\mathbf{S}) = \sum_{k=1}^K q_k \mathbf{A}_k \mathbf{S} \mathbf{A}_k^H$: Interference-plus-noise correlation matrix
- **Optimization Variables:** Transmit waveform $\mathbf{s}$ and receive filter $\mathbf{w}$
- **Objective:** Maximize the SINR, i.e., $\max_{\mathbf{s}, \mathbf{w}} \frac{|\mathbf{w}^H \mathbf{A}_0 \mathbf{s}|^2}{\mathbf{w}^H (\mathbf{\Psi}(\mathbf{s}) + \mathbf{I}) \mathbf{w}}$
- **Constraints:**
    - $\mathbf{s} \in \mathcal{S}$, where $\mathcal{S}$ is a non-empty, possibly non-convex set representing waveform constraints such as constant modulus, similarity to a reference waveform, PAR, or spectral compatibility constraints.


### Optimization Algorithm
- **Algorithm Type:** Majorization-Minimization (MM) algorithm
- **Algorithm Parameters:**
    - $\lambda_u(\mathbf{P})$: An upper bound on the eigenvalues of the positive semidefinite matrix $\mathbf{P}$, chosen as $\text{Tr}(\mathbf{P})$ for computational efficiency.
- **Algorithm Steps:**
1. Initialize $\mathbf{s}^{(0)}$ and $\mathbf{S}^{(0)} = \mathbf{s}^{(0)} (\mathbf{s}^{(0)})^H$.
2. For $\ell = 0, 1, 2, \ldots$, repeat:
    1. Compute $\mathbf{z}^{(\ell)} = \mathbf{A}_0^H (\mathbf{\Psi}(\mathbf{S}^{(\ell)}) + \mathbf{I})^{-1} \mathbf{A}_0 \mathbf{s}^{(\ell)}$.
    2. Compute $\mathbf{Q}_k^{(\ell)} = \mathbf{A}_0^H (\mathbf{\Psi}(\mathbf{S}^{(\ell)}) + \mathbf{I})^{-1} \mathbf{A}_k$ for $k = 1, \ldots, K$.
    3. Compute $\mathbf{P}^{(\ell)} = \sum_{k=1}^K q_k \mathbf{Q}_k^{(\ell)} (\mathbf{S}^{(\ell)})^H \mathbf{Q}_k^{(\ell)H}$.
    4. Solve the majorized subproblem: $\mathbf{s}^{(\ell+1)} = \arg\min_{\mathbf{s}} \text{Re}\left\{(\mathbf{v}^{(\ell)})^H \mathbf{s}\right\}$ subject to $\mathbf{s} \in \mathcal{S}$, where $\mathbf{v}^{(\ell)} = 2(\mathbf{P}^{(\ell)} - \lambda_u(\mathbf{P}^{(\ell)}) \mathbf{I}) \mathbf{s}^{(\ell)} - \mathbf{z}^{(\ell)}$.
    5. Update $\mathbf{S}^{(\ell+1)} = \mathbf{s}^{(\ell+1)} (\mathbf{s}^{(\ell+1)})^H$.
3. Terminate when a convergence criterion is met.