2024-06-10 23:16:57.553947

### System Model
- **Problem Type:** Colocated MIMO radar waveform design for minimum peak sidelobe transmit beampattern
- **Problem Description:** The goal is to design CM waveforms for a colocated MIMO radar system with $L$ transmit antennas to achieve a transmit beampattern with minimum peak sidelobe level while satisfying mainlobe constraints.
- **System Model Parameters:**
    - $L$: Number of transmit antennas
    - $N$: Number of samples of each radar waveform
    - $x_l(n)$: Discrete-time radar waveform radiated by the $l$-th antenna, $n=1,\dots,N$, $l=1,\dots,L$
    - $x(n) = [x_1(n), x_2(n), \dots, x_L(n)]^T \in \mathbb{C}^{L \times 1}$
    - $a(\theta) = [e^{j2\pi f_0 \tau_1(\theta)}, e^{j2\pi f_0 \tau_2(\theta)}, \dots, e^{j2\pi f_0 \tau_L(\theta)}]^T \in \mathbb{C}^{L \times 1}$, where $\tau_l(\theta) = \frac{(l-1)\bar{d}\sin(\theta)}{\bar{v}}$, $\bar{d}$ is the inter-element spacing, $\bar{v}$ is the speed of propagation, and $f_0$ is the carrier frequency.
    - $A(\theta) = I_N \otimes a(\theta) \in \mathbb{C}^{LN \times N}$, where $\otimes$ denotes the Kronecker product.

- **System Model Formulations:**
    - The transmit beampattern at the angular location $\theta$ is given by:
      $$P(\theta) = x^H A(\theta) A^H(\theta) x$$
    - The waveform vector $x$ is subject to the constant modulus (CM) constraints:
      $$|x(\bar{n})| = \xi, \quad \bar{n} = 1, \dots, LN$$
      where $\xi > 0$ is the modulus of the waveform vector $x$.

### Optimization Formulation
- **Optimization Type:** Quadratic fractional programming (QFP)
- **Optimization Parameters:**
    - $\Theta$: Mainlobe angle region, composed of $M$ angle grids $\{\theta_m\}_{m=1}^M$
    - $\Omega$: Sidelobe angle region, composed of $S$ angle grids $\{\vartheta_s\}_{s=1}^S$
- **Optimization Variables:** Waveform vector $x$
- **Objective:** Maximize the ratio of the minimum mainlobe level to the peak sidelobe level
  $$\max_{x} \frac{\min_{\theta_m \in \Theta} \|A^H(\theta_m)x\|_2}{\max_{\vartheta_s \in \Omega} \|A^H(\vartheta_s)x\|_2}$$
- **Constraints:**
    - Constant modulus constraints: $|x(\bar{n})| = \xi, \quad \bar{n} = 1, \dots, LN$

### Optimization Algorithm
- **Algorithm Type:** ADMM-based algorithm
- **Algorithm Parameters:**
    - $\rho$: Step size
    - $T_0$: Maximum number of iterations
    - $\tilde{\iota}$: Iteration stop tolerance
- **Algorithm Steps:**
    1. Initialize $\{y_s^0\}, \{z_m^0\}, \{\lambda_s^0\}, \{\nu_m^0\}$, and $t=0$.
    2. While $|\epsilon^{t+1} - \epsilon^t| > \tilde{\iota}$ and $t \leq T_0$:
        - Obtain $x^{t+1}$ using Algorithm 1 (details provided in the paper).
        - Determine $\eta^{t+1}$ and $\{y_s^{t+1}\}$ using auxiliary variable updates.
        - Determine $\epsilon^{t+1}$ and $\{z_m^{t+1}\}$ using auxiliary variable updates.
        - Update $\{\lambda_s^{t+1}\}$ and $\{\nu_m^{t+1}\}$ using dual variable updates.
        - $t = t + 1$
    3. Output: MIMO radar waveform vector $x$.