2024-06-10 23:16:57.553947

### System Model
- **Problem Type:** Two-dimensional (2-D) simultaneous localization of two static targets using time-of-arrival (TOA) measurements from active sensors.
- **Problem Description:** The problem involves determining the optimal placement of $N$ sensors to localize two targets simultaneously, where $m$ sensors are dedicated to each target, and $n$ sensors are shared between the two targets, such that $N = n + 2m$. The TOA measurements are assumed to be free from multipath and clutter, and the data association problem is resolved.
- **System Model Parameters:**
  - $p_1 = [p_{x1}, p_{y1}]^T$: True position of target 1
  - $p_2 = [p_{x2}, p_{y2}]^T$: True position of target 2
  - $r_i = [r_{xi}, r_{yi}]^T$: Position of the $i$-th sensor
  - $\tilde{t}_{i1}$: Noisy TOA measurement of the $i$-th sensor for target 1
  - $\tilde{t}_{i2}$: Noisy TOA measurement of the $i$-th sensor for target 2
  - $c$: Signal propagation speed (constant)
  - $\eta_{i1} \sim \mathcal{N}(0, \sigma^2_{i1}/c^2)$: Additive Gaussian white noise for the measurement of target 1 by the $i$-th sensor
  - $\eta_{i2} \sim \mathcal{N}(0, \sigma^2_{i2}/c^2)$: Additive Gaussian white noise for the measurement of target 2 by the $i$-th sensor
  - $\theta_{i1}$: Azimuth angle between the $i$-th sensor and target 1
  - $\theta_{i2}$: Azimuth angle between the $i$-th sensor and target 2
- **System Model Formulations:**
  - Noisy TOA measurement model for target 1: $\tilde{t}_{i1} = \frac{2}{c}\Vert p_1 - r_i \Vert + \eta_{i1}$
  - Noisy TOA measurement model for target 2: $\tilde{t}_{i2} = \frac{2}{c}\Vert p_2 - r_i \Vert + \eta_{i2}$
  - Transformed measurement model for target 1: $\tilde{s}_{i1} = 2d_{i1} + c\eta_{i1}$, where $d_{i1} = \Vert p_1 - r_i \Vert$
  - Transformed measurement model for target 2: $\tilde{s}_{i2} = 2d_{i2} + c\eta_{i2}$, where $d_{i2} = \Vert p_2 - r_i \Vert$
  - Jacobian vector of the $i$-th sensor measurement error for target 1: $J_{i1} = \left[\frac{\partial \tilde{s}_{i1}}{\partial p_{x1}}, \frac{\partial \tilde{s}_{i1}}{\partial p_{y1}}, \frac{\partial \tilde{s}_{i1}}{\partial p_{x2}}, \frac{\partial \tilde{s}_{i1}}{\partial p_{y2}}\right]^T_{p_1, p_2} = \left[2\cos\theta_{i1}, 2\sin\theta_{i1}, 0, 0\right]^T$
  - Jacobian vector of the $i$-th sensor measurement error for target 2: $J_{i2} = \left[0, 0, 2\cos\theta_{i2}, 2\sin\theta_{i2}\right]^T$

### Optimization Formulation
- **Optimization Type:** Minimize the trace of the Cramér-Rao lower bound (CRLB), which is equivalent to minimizing the mean-squared error (MSE) of the target location estimates.
- **Optimization Parameters:**
  - $\sigma^2$: Measurement noise variance (assumed to be uniform for all sensors in the large signal-to-noise ratio (SNR) case)
  - $m$: Number of sensors dedicated to each target
  - $n$: Number of shared sensors
  - $N = n + 2m$: Total number of sensors
- **Optimization Variables:** $\{\theta_{k1}, \theta_{k2}, \theta_{j1}, \theta_{j2}\}$, where $k = 1, \ldots, m$ and $j = 1, \ldots, n$ represent the azimuth angles between the sensors and the targets.
- **Objective:** Minimize the trace of the CRLB, denoted as $\text{tr}(\text{CRLB})$.
- **Constraints:**
  - $\sum_{i=1}^{m+n} \cos 2\theta_{i1} = 0$
  - $\sum_{i=1}^{m+n} \cos 2\theta_{i2} = 0$
  - $\sum_{i=1}^{m+n} \sin 2\theta_{i1} = 0$
  - $\sum_{i=1}^{m+n} \sin 2\theta_{i2} = 0$

### Optimization Algorithm
- **Algorithm Type:** Analytical solution based on the derived theoretical CRLB and the proposed optimal sensor placement scheme.
- **Algorithm Parameters:** Not explicitly specified in the paper.
- **Algorithm Steps:**
  1. Determine the optimal sensor placement criterion for a single target localization problem: The azimuth angles $2\theta_i$ should have an equal angular distribution or be symmetrically distributed around the target.
  2. Exploit the invariance property of the FIM/CRLB with respect to rotation or flipping of sensors about the target.
  3. Utilize the independence of the optimal CRLB from the sensor-target range in the large SNR case.
  4. For the two-target localization problem:
     - Step 1: Place the $m$ sensors for target 1 optimally according to the single-target criterion.
     - Step 2: Place the $m$ sensors for target 2 optimally according to the single-target criterion.
     - Step 3: Place the $n$ shared sensors on the middle line between the two targets, with equal angular distribution or symmetrically distributed around the midpoint.
     - Step 4: Optionally, apply rotation, flipping, or range adjustment to the non-shared sensors to obtain additional optimal geometries, exploiting the invariance and range-independence properties.
  5. The resulting sensor placement geometry achieves the minimum $\text{tr}(\text{CRLB}) = \frac{2\sigma^2}{n+m}$.