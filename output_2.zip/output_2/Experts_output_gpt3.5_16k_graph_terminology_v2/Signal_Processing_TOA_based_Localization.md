2024-06-10 23:16:57.553947

### System Model
- **Problem Type:** Time-Difference-of-Arrival (TDOA) Based Source Localization
- **Problem Description:** The problem involves localizing a single source emitting an acoustic or electromagnetic signal using TDOA measurements obtained from an array of sensors. The objective is to infer the source location from the noisy TDOA measurements by optimally placing the sensors.
- **System Model Parameters:**
  - $p \in \mathbb{R}^2$: Location of the source
  - $q = [q_1, q_2, \dots, q_M] \in \mathbb{R}^{2 \times M}$: Locations of $M$ sensors
  - $t_0$: Unspecified event time when the source emits the signal
  - $\nu$: Propagation speed of the signal
  - $d_i(p, q) = \|p - q_i\|$: Distance between the source and the $i^{th}$ sensor
  - $\epsilon_i$: Zero-mean Gaussian noise with variance $\sigma^2$ for the $i^{th}$ sensor's time-of-arrival (TOA) measurement
  - $\hat{t}_i = t_0 + d_i(p, q)/\nu + \epsilon_i$: Noisy TOA measurement for the $i^{th}$ sensor
  - $\hat{t}_{ij} = \hat{t}_i - \hat{t}_j = \frac{1}{\nu}d_{ij}(p, q) + \epsilon_{ij}$: TDOA measurement between sensors $i$ and $j$, where $d_{ij}(p, q) = d_i(p, q) - d_j(p, q)$ and $\epsilon_{ij} = \epsilon_i - \epsilon_j$ is the noise difference with variance $2\sigma^2$
- **System Model Formulations:**
  - $\hat{t}(p, q) = [\hat{t}_{i1}]_{i=2}^{M}$: $(M-1) \times 1$ vector of TDOA measurements with respect to the first sensor
  - $d(p, q) = [d_{i1}]_{i=2}^{M}$: $(M-1) \times 1$ vector of differences in source-sensor distances
  - $\epsilon = [\epsilon_{i1}]_{i=2}^{M}$: $(M-1) \times 1$ vector of noise differences
  - $\bar{t}(p, q) = \mathbb{E}[\hat{t}] = \frac{1}{\nu}d(p, q)$: Mean of $\hat{t}$
  - $Q = \mathbb{E}[(\hat{t} - \bar{t})(\hat{t} - \bar{t})^T] = \sigma^2(I + 11^T)$: $(M-1) \times (M-1)$ covariance matrix of $\hat{t}$, where $1$ is an $(M-1) \times 1$ vector of ones

### Optimization Formulation
- **Optimization Type:** Maximization of the determinant of the Fisher information matrix to achieve optimal sensor placement for source localization.
- **Optimization Parameters:**
  - $F(p, q)$: $(2 \times 2)$ Fisher information matrix associated with the estimation of the source location $p$, given by:
    $$F(p, q) = \frac{1}{\nu^2}G^TQ^{-1}G$$
    where $G = [g_i - g_1]_{i=2}^{M}$ is an $(M-1) \times 2$ matrix, and $g_i = \frac{p - q_i}{\|p - q_i\|}$ is the unit vector pointing from sensor $i$ to the source.
  - $CR(p, q) = F(p, q)^{-1}$: Cramer-Rao lower bound, which is a lower bound on the estimation error covariance of any unbiased estimator of $p$.
- **Optimization Variables:** Sensor locations $q = [q_1, q_2, \dots, q_M]$
- **Objective:** Maximize the determinant of the Fisher information matrix, $\det(F(p, q))$, which is equivalent to minimizing the Cramer-Rao lower bound, $CR(p, q)$.
- **Constraints:**
  - Sensors are confined to a region $D \subseteq \mathbb{R}^2$, typically an annulus or a ring centered at the expected source location.
  - Additional constraints may be imposed on the sensor configurations, such as symmetry or splay configurations (defined as $\theta_j - \theta_i = \frac{2\pi}{N}$ for each $j = i + 1$, where $\theta_i$ is the angle of $q_i$ with respect to the x-axis).

### Optimization Algorithm
- **Algorithm Type:** The paper does not explicitly propose a specific optimization algorithm. Instead, it derives analytical conditions for optimal sensor placement by analyzing the Lagrangian and the Karush-Kuhn-Tucker (KKT) necessary optimality conditions.
- **Algorithm Parameters:** Not applicable, as no specific algorithm is proposed.
- **Algorithm Steps:**
  1. Formulate the optimization problem as maximizing the expected value of $\det(F(p, q))$ over the sensor locations $q$, subject to constraints on the region $D$ and any additional constraints on the sensor configuration.
  2. Derive the Lagrangian function for the constrained optimization problem, incorporating the constraints using Lagrange multipliers.
  3. Compute the gradients of the Lagrangian with respect to the sensor locations $q$ and the Lagrange multipliers.
  4. Apply the KKT necessary optimality conditions to obtain a system of equations that must be satisfied by the optimal sensor locations and the corresponding Lagrange multipliers.
  5. Analyze the resulting system of equations to identify specific sensor configurations that satisfy the optimality conditions, such as symmetric or splay configurations.
  6. Prove that the identified sensor configurations meet the necessary optimality conditions by showing that the gradients of the Lagrangian with respect to the sensor locations and the Lagrange multipliers vanish at the optimal points.