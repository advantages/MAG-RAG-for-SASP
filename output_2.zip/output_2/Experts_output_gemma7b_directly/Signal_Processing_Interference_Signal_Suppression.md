2024-05-07 11:05:44.460778

## Problem Statement

**Given:**

* A uniform linear array of \var{N} array elements with an array spacing of half a wavelength.
* A signal source in space continuously emits a signal at an angle of \var{Theta}.
* \var{P} interference sources continuously emit signals from angles \var{Phi_{p}} (p=1,2,3,...P).

**Objective:**

Maximize the signal-to-interference plus noise ratio (SINR) at the beamform output.

**Problem Type:**

Array signal processing, beamforming

**System Model:**

**Parameters:**

* \var{N}: Number of array elements
* \var{Theta}: Angle of the signal source
* \var{Phi_p}: Angles of the interference sources
* \var{S}: Signal power
* \var{I_p}: Interference power
* \var{N_o}: Noise power
* \var{W}: Array weight vector
* \var{H}: Channel matrix

**Formulations:**

* **Signal model:** $$y = S\cdot W^H\cdot H + \sum_p I_p\cdot W^H\cdot H + N_o$$
* **SINR:** $$SINR = \frac{S\cdot W^H\cdot H\cdot H^H\cdot W}{S\cdot W^H\cdot H\cdot H^H\cdot W + \sum_p I_p\cdot W^H\cdot H\cdot H^H\cdot W + N_o}$$

**Optimization Formulation:**

**Parameters:**

* \var{W}: Array weight vector

**Objective:**

Maximize SINR

**Constraints:**

* $$W^H\cdot W = I$$ (normalization)
* $$0 \leq W_n \leq 1$$ (element bounds)

**Optimization Algorithm:**

**Algorithm Type:** Gradient-based optimization

**Parameters:**

* Learning rate: \eta
* Number of iterations: \num_iter

**Steps:**

1. Initialize the array weight vector W.
2. Repeat for \num_iter iterations:
    * Calculate the SINR using the current weight vector W.
    * Calculate the gradient of the SINR with respect to W.
    * Update W using the gradient and learning rate.

**Optimal Expression for Array Weight Vector:**

The optimal array weight vector W is given by:

$$W_o = \frac{H^H\cdot W_p}{H^H\cdot W_p\cdot H\cdot H^H\cdot W_p + N_o} H$$

where:

* W_o is the optimal weight vector
* W_p is the pseudo-inverse of the channel matrix
* H is the channel matrix
* N_o is the noise power