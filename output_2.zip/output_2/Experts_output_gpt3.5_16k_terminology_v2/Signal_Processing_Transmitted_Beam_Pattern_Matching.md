2024-06-10 23:06:54.275190

## System Model

- **Problem Type:** Beamforming in a uniform linear array.

- **Problem Description:** We want to obtain the transmitted beamforming weights that match the amplitude of an expected radiation beam pattern in various directions in space. We have a uniform linear array with N array elements, where the array spacing is half a wavelength. The expected radiation beam pattern only provides real values without phase information.

- **System Model Parameters:**
  - N: Number of array elements in the uniform linear array.
  - d: Spacing between adjacent array elements (d = λ/2, where λ is the wavelength).
  - θ: Angle of arrival of the radiation beam.
  - w: Transmit beamforming weights.

- **System Model Formulations:** 

The received signal at the ith array element can be represented as:

$$
s_i = x(t-\tau_i) = Ae^{j\phi_i}(t-\tau_i)e^{j2\pi f_ct}, \quad i = 1, 2, ..., N
$$

where:
- $x(t-\tau_i)$ is the transmitted signal delayed by $\tau_i$ (propagation time from the transmit antenna to the ith array element).
- A is the complex amplitude of the transmitted signal.
- $\phi_i$ is the phase shift introduced by the array element.
- t is time.
- f_c is the carrier frequency.

The received signal is weighted by the beamforming weights and summed across all array elements to form the output signal:

$$
y(t) = \sum_{i=1}^{N} w_i s_i
$$

The expected radiation beam pattern without phase information can be represented as:

$$
p(\theta) = \Re(P(\theta))
$$

where:
- p(\theta) is the amplitude of the expected radiation beam pattern at angle \theta.
- P(\theta) is the complex radiation pattern at angle \theta.

## Optimization Formulation

- **Optimization Type:** This problem can be formulated as a optimization problem with constraints.

- **Optimization Parameters:**
  - N: Number of array elements.
  - d: Spacing between array elements.
  - p(\theta): Amplitude of the expected radiation beam pattern at angle \theta.
  - w: Transmit beamforming weights.

- **Optimization Variables:**
  - w_i: Transmit beamforming weight for the ith array element. (i = 1, 2, ..., N)

- **Objective:** The objective is to minimize the difference between the amplitude of the expected radiation beam pattern p(\theta) and the weighted sum of the amplitudes of the received signals at each array element.

$$
\text{minimize} \sum_{i=1}^{N} \left| p(\theta) - w_i |s_i| \right|
$$

- **Constraints:**
  - Array spacing constraint: The spacing between adjacent array elements is equal to half a wavelength.
  - Amplitude constraint: The transmit beamforming weights should have unit magnitude.

$$
|w_i| = 1, \quad \forall i = 1, 2, ..., N
$$

## Optimization Algorithm

- **Algorithm Type:** Since the objective function is non-convex, we can solve this problem using an iterative optimization algorithm like the Successive Alternating Direction Method of Multipliers (S-ADMM).

- **Algorithm Parameters:**
  - $\alpha$: Penalty parameter for the ADMM algorithm.
  - Max iterations: Maximum number of iterations for the algorithm.
  - Tolerance: Convergence threshold for the algorithm.

- **Algorithm Steps:**
  1. Initialize the transmit beamforming weights w.
  2. Initialize the auxiliary variables q and z.
  3. Repeat until convergence or maximum iterations reached:
     - Update q using the formula: q = q + w.
     - Update z using the formula: z = w + q.
     - Update the transmit beamforming weights w using the formula: w = argmin_w \left( \sum_{i=1}^{N} \left| p(\theta) - w_i |s_i| \right| + \frac{\alpha}{2} \left( \sum_{i=1}^{N} (w_i - z_i)^2 \right) \right).
  4. Return the final transmit beamforming weights w.

This algorithm iteratively updates the transmit beamforming weights to minimize the difference between the amplitude of the expected radiation beam pattern and the weighted sum of the amplitudes of the received signals, while also enforcing the amplitude constraint. The algorithm terminates when the convergence criteria (threshold or maximum iterations) is met.