2024-06-10 23:06:54.275190

## System Model
- **Problem Type:** Angle of arrival (AOA) estimation using a uniform linear array (ULA) of sensors.
- **Problem Description:** The problem is to estimate the angle at which a signal source is emitting signals relative to a ULA with N array elements and an array spacing of half a wavelength. The goal is to accurately estimate the angle of the signal source, given sampled signal information.
- **System Model Parameters:**
  - N: Number of array elements in the ULA
  - Array spacing: Half a wavelength
  - Theta: Angle of the signal source relative to the array
  - K: Number of sampled signals
- **System Model Formulations:**
  - The received signal at each array element can be represented as:
    $$x(n) = s(n) + w(n)$$
    where x(n) is the received signal, s(n) is the signal emitted by the source, and w(n) is the noise.
  - The signal emitted by the source at each array element can be represented as:
    $$s(n) = A \cdot \exp \left(i \cdot 2\pi \cdot \frac{d \cdot \sin(\theta)}{\lambda} \cdot n \right)$$
    where A is the amplitude of the emitted signal, d is the array spacing, lambda is the wavelength, n is the index of the array element, and i is the imaginary unit.