2024-05-07 10:40:01.461962

### Optimal Sensor Localization for Time-of-Arrival (TOA) Based Source Localization
### System Model
- **Problem Type:** Sensor array signal processing for TOA based source localization 
- **Problem Description:** The objective is to determine the optimal placement of sensors in a wireless sensor network to minimize the uncertainty in estimating the location of a source emitting signals. The time of arrival (TOA) of the signals at the sensors provides measurements that are utilized for source localization.
- **System Model Parameters:** 
    - $M$: Number of sensors
    - $N$: Dimension of the problem (2 for 2D, 3 for 3D)
    - $s \in \mathbb{R}^N$: Unknown source position
    - $r_i \in \mathbb{R}^N$: Position of the $i$-th sensor, $i=1,\ldots,M$
    - $t_i$: TOA measurement at the $i$-th sensor
    - $c$: Speed of electromagnetic wave propagation
    - $\epsilon_i \sim \mathcal{N}(0, \sigma_i^2)$: TOA measurement noise at the $i$-th sensor
    - $\mathbf{R}_\text{TOA} = \text{diag}(\sigma_1^2, \ldots, \sigma_M^2)$: TOA measurement noise covariance matrix

- **System Model Formulations:** 
    - TOA measurement model: $t_i = \frac{\|s - r_i\|_2}{c} + \epsilon_i, \quad i=1,\ldots,M$

### Optimization Formulation
- **Optimization Type:** Constrained optimization, specifically nonlinear least squares (NLS)
- **Optimization Parameters:** 
    - $K$: Number of grid points $\{s_k\}_{k=1}^K$ sampling the surveillance region
    - $\mathbf{H}_k = [h_{k,1}, \ldots, h_{k,M}]^\top$, where $h_{k,i} = \frac{s_k - r_i}{\|s_k - r_i\|_2}$
- **Optimization Variables:** $r_1, \ldots, r_M$: Sensor positions
- **Objective:** 
    - Minimize the sum of squared residuals: $\min_{r_i \in \mathbf{R}_i} \sum_{k=1}^K \left\| \mathbf{t}_k - \mathbf{H}_k r \right\|_2^2$
- **Constraints:** $r_i \in \mathbf{R}_i, \quad i=1,\ldots,M$: Sensor positions must lie within their respective feasible deployment regions.

### Optimization Algorithm
- **Algorithm Type:** Iterative Gauss-Newton algorithm
- **Algorithm Parameters:** 
    - $\mathbf{J}_k = \frac{\partial \mathbf{t}_k}{\partial r} = \mathbf{H}_k \otimes \mathbf{I}_M$, where $\otimes$ denotes the Kronecker product
    - $\mathbf{W}_k = \mathbf{R}_\text{TOA}^{-1}$
    - Learning rate: $\alpha$
- **Algorithm Steps:**
    1. Initialize sensor positions $r_i^0 \in \mathbf{R}_i$, $i=1,\ldots,M$
    2. For $t=0,1,2,\ldots$
        1. Compute the gradient of the cost function: $\mathbf{g}^t = \sum_{k=1}^K \mathbf{J}_k^\top \mathbf{W}_k \left( \mathbf{t}_k - \mathbf{H}_k r^t \right)$
        2. Compute the Hessian of the cost function: $\mathbf{H}^t = \sum_{k=1}^K \mathbf{J}_k^\top \mathbf{W}_k \mathbf{J}_k$
        3. Update the sensor positions: $r^{t+1} = r^t - \alpha \mathbf{H}^{-1} \mathbf{g}^t$
    3. Until convergence
    4. Return $r_i^*$, $i=1,\ldots,M$