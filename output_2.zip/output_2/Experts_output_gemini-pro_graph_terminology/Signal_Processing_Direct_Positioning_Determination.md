2024-05-07 10:40:01.461962

### System Model
- **Problem Type:** Direction-of-arrival estimation of multiple sources impinging on a uniform linear array (ULA) of sensors in the presence of additive white Gaussian noise.
- **Problem Description:** An array of $M$ sensors is placed in two-dimensional space. Each sensor has a single antenna that receives signals from a signal source located at position (\(x, y\)). The goal is to estimate the position of the source based on the received signal samples.
- **System Model Parameters:**
  - $M$: Number of sensors in the ULA
  - \(x, y\): Coordinates of the signal source
  - $s(t)$: Transmitted signal from the source
  - $h_m(\theta)$: Channel response from the source to the $m$-th sensor
  - $n_m(t)$: Additive white Gaussian noise at the $m$-th sensor
  - $\theta_m$: Angle-of-arrival (AoA) of the signal at the $m$-th sensor
- **System Model Formulations:** The received signal at the $m$-th sensor can be expressed as:

$$r_m(t) = h_m(\theta_m)s(t) + n_m(t)$$

The channel response can be modeled as:

$$h_m(\theta_m) = e^{-j2\pi f_c\frac{d}{\lambda}\sin(\theta_m)}$$


### Optimization Formulation
- **Optimization Type:** Maximum likelihood estimation
- **Optimization Parameters:**
  - $r_1(t), r_2(t), \ldots, r_M(t)$: Received signal samples at the sensors
  - $\theta_1, \theta_2, \ldots, \theta_M$: AoAs of the signal at the sensors
  - $\sigma^2$: Noise variance
- **Optimization Variables:** The position of the signal source $x$ and $y$.
- **Objective:** Minimize the following objective function:

$$J(\theta_1, \theta_2, \ldots, \theta_M, x, y) = \sum_{m=1}^M \left|r_m(t) - h_m(\theta_m)s(t)\right|^2$$
- **Constraints:** $\theta_m \in [-\pi/2, \pi/2]$

### Optimization Algorithm
- **Algorithm Type:** Iterative gradient descent
- **Algorithm Parameters:**
  - Learning rate $\alpha$
- **Algorithm Steps:**
  1. Initialize $\theta_1^{(0)}, \theta_2^{(0)}, \ldots, \theta_M^{(0)}$, $x^{(0)}$, and $y^{(0)}$.
  2. For $k = 0, 1, 2, \ldots$ until convergence:
  3. Calculate the gradient of the objective function:
$$
\nabla J(\theta_1^{(k)}, \theta_2^{(k)}, \ldots, \theta_M^{(k)}, x^{(k)}, y^{(k)}) =  -2\sum_{m=1}^M \left(r_m(t) - h_m(\theta_m^{(k)})s(t)\right) h_m(\theta_m^{(k)}) \frac{df_c d}{\lambda \cos(\theta_m)}
$$
4. Update the parameters:
$$
\theta_m^{(k+1)} = \theta_m^{(k)} - \alpha \frac{\partial J(\theta_1^{(k)}, \theta_2^{(k)}, \ldots, \theta_M^{(k)}, x^{(k)}, y^{(k)})}{\partial \theta_m}
$$
$$
x^{(k+1)} = x^{(k)} - \alpha \frac{\partial J(\theta_1^{(k)}, \theta_2^{(k)}, \ldots, \theta_M^{(k)}, x^{(k)}, y^{(k)})}{\partial x}
$$
$$
y^{(k+1)} = y^{(k)} - \alpha \frac{\partial J(\theta_1^{(k)}, \theta_2^{(k)}, \ldots, \theta_M^{(k)}, x^{(k)}, y^{(k)})}{\partial y}
$$