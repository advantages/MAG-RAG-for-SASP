2024-05-07 10:40:01.461962

### System Model
- **Problem Type:** Uniform linear array beamforming for radiation pattern design
- **Problem Description:** Design an optimal weight vector for a uniform linear array (ULA) to achieve a desired radiation pattern in the far-field.
- **System Model Parameters:**
    - $N$: Number of array elements in the ULA
    - $\lambda$: Wavelength of the electromagnetic wave
    - $d$: Inter-element spacing of the ULA
    - $\theta$: Angle of arrival (AoA) of the desired signal
    - $\mathbf{w}$: Weight vector to be designed
    - $a_n(\theta)$: Steering vector element corresponding to the $n$-th array element
- **System Model Formulations:**
    - Array factor: $F(\theta) = \sum_{n=1}^N w_n e^{-j2\pi(n-1)\frac{d}{\lambda}\sin(\theta)}$
    - Radiation pattern: $P(\theta) = |F(\theta)|^2$

### Optimization Formulation
- **Optimization Type:** Quadratic programming (QP)
- **Optimization Parameters:**
    - $\Theta$: Set of angles where the desired radiation pattern is specified
    - $P_d(\theta)$: Desired radiation pattern values at angles in $\Theta$
- **Optimization Variables:** $\mathbf{w}$
- **Objective:** Minimize the weighted mean squared error (MSE) between the desired and actual radiation patterns:
  $$\min_{\mathbf{w}} \frac{1}{|\Theta|} \sum_{\theta \in \Theta} \Bigl| P(\theta) - P_d(\theta) \Bigr|^2$$
- **Constraints:** None

### Optimization Algorithm
- **Algorithm Type:** CVX, a package for solving convex optimization problems
- **Algorithm Parameters:**
    - Solver: GUROBI
    - Tolerance: $10^{-6}$
    - Maximum iterations: 1000
- **Algorithm Steps:**
    1. Formulate the optimization problem in CVX using the provided objective and constraints.
    2. Initialize the weight vector $\mathbf{w}$ with random values.
    3. Solve the optimization problem using the chosen solver.
    4. Check if the solution satisfies the tolerance and maximum iteration criteria. If not, update $\mathbf{w}$ and repeat step 3.
    5. Obtain the optimal weight vector $\mathbf{w}^\star$ that minimizes the MSE.