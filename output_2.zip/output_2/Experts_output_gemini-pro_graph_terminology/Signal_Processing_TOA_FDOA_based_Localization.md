2024-05-07 10:40:01.461962

### System Model
- **Problem Type:** Source localization using TDOA and FDOA measurements from multiple sensors.
- **Problem Description:** Given $M$ sensors located at different positions $(\var{x_i},\var{y_i})$, each sensor measures the TDOA and FDOA of a signal source. The objective is to estimate the location of the signal source based on these measurements.
- **System Model Parameters:**
  - $M$: Number of sensors
  - $(\var{x_i},\var{y_i})$: Coordinates of the $i$-th sensor
  - $c$: Speed of light
  - $\tau_i$: TDOA measurement at the $i$-th sensor
  - $f_i$: FDOA measurement at the $i$-th sensor
- **System Model Formulations:**
  - **TDOA measurements:** The TDOA measurement $\tau_i$ is the time difference of arrival of the signal at the $i$-th sensor relative to a reference sensor. It can be expressed as:
    $$\tau_i = \frac{1}{c}\left(\|\mathbf{u}_o - \mathbf{s}_i\| - \|\mathbf{u}_o - \mathbf{s}_1\|\right)$$
    where $\mathbf{u}_o = [x_o, y_o]^T$ is the unknown location of the signal source and $\mathbf{s}_i = [x_i, y_i]^T$ is the known location of the $i$-th sensor.
  - **FDOA measurements:** The FDOA measurement $f_i$ is the frequency difference of arrival of the signal at the $i$-th sensor relative to a reference sensor. It can be expressed as:
    $$f_i = \frac{1}{2\pi}\left(\frac{c}{\lambda_o} - \frac{c}{\lambda_i}\right)$$
    where $\lambda_o$ is the wavelength of the signal at the signal source and $\lambda_i$ is the wavelength of the signal at the $i$-th sensor.

### Optimization Formulation
- **Optimization Type:** Joint TDOA and FDOA based source localization.
- **Optimization Parameters:**
  - $\mathbf{u}_o = [x_o, y_o]^T$: Unknown location of the signal source
  - $\lambda_o$: Unknown wavelength of the signal at the source
- **Optimization Variables:**
  - $\mathbf{u}_o$
  - $\lambda_o$
- **Objective:** Minimize the sum of squared errors between the measured TDOA and FDOA values and the estimated values:
  $$J(\mathbf{u}_o, \lambda_o) = \sum_{i=1}^M \left(\tau_i - \frac{1}{c}\left(\|\mathbf{u}_o - \mathbf{s}_i\| - \|\mathbf{u}_o - \mathbf{s}_1\|\right)\right)^2 + \left(f_i - \frac{1}{2\pi}\left(\frac{c}{\lambda_o} - \frac{c}{\lambda_i}\right)\right)^2$$
- **Constraints:** None.

### Optimization Algorithm
- **Algorithm Type:** Nonlinear least squares estimation using the Levenberg-Marquardt algorithm.
- **Algorithm Parameters:**
  - Initial guess for $\mathbf{u}_o$ and $\lambda_o$
  - Step size and damping factor for the Levenberg-Marquardt algorithm
- **Algorithm Steps:**
  1. Initialize $\mathbf{u}_o$ and $\lambda_o$ with initial guesses.
  2. Compute the gradient and Hessian of the objective function.
  3. Update $\mathbf{u}_o$ and $\lambda_o$ using the Levenberg-Marquardt update rule:
    $$\left[\begin{array}{c} \mathbf{u}_o \\\ \lambda_o \end{array}\right] = \left[\begin{array}{c} \mathbf{u}_o \\\ \lambda_o \end{array}\right] - \left[\begin{array}{cc} \mathbf{H}_{11} & \mathbf{H}_{12} \\\ \mathbf{H}_{21} & \mathbf{H}_{22} \end{array}\right]^{-1} \left[\begin{array}{c} \nabla_{u_o} J \\\ \nabla_{\lambda_o} J \end{array}\right]$$
    where $\mathbf{H}$ is the Hessian and $\nabla J$ is the gradient of the objective function.
  4. Repeat steps 2-3 until the objective function converges or a maximum number of iterations is reached.