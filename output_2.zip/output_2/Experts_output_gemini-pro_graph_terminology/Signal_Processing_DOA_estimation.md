2024-05-07 10:40:01.461962

### System Model
- **Problem Type:** Signal parameter estimation (specifically, source localization) in a uniform linear array (ULA) antenna system.
- **Problem Description:** Given a ULA with N antenna elements spaced half a wavelength apart, estimate the direction of arrival (DOA) of a signal source emitting continuously in space relative to the array. The estimation is based on a finite number K of sampled signal measurements.
- **System Model Parameters:**
    - $N$: Number of antenna elements in the ULA
    - $\lambda$: Wavelength of the signal
    - $d$: Spacing between adjacent antenna elements ($d = \lambda/2$)
    - $K$: Number of sampled signal measurements
    - $\theta$: DOA of the signal source (relative to the array broadside)
- **System Model Formulations:**
    - Array steering vector: $\mathbf{a}(\theta) = [1, e^{j2\pi d\sin(\theta)/\lambda}, \ldots, e^{j2\pi (N-1)d\sin(\theta)/\lambda}]^T$
    - Received signal vector: $\mathbf{x} = \mathbf{a}(\theta)\mathbf{s} + \mathbf{n}$
        - $\mathbf{s}$: Transmitted signal vector
        - $\mathbf{n}$: Additive noise vector

### Optimization Formulation
- **Optimization Type:** Nonlinear least squares (NLS) optimization
- **Optimization Parameters:**
    - $\theta$: DOA of the signal source
- **Optimization Variables:**
    - $\theta$
- **Objective:**
    - Minimize the sum of squared errors between the measured signal vector $\mathbf{x}$ and the model-predicted signal vector $\mathbf{a}(\theta)\mathbf{s}$:
    $$f(\theta) = \|\mathbf{x} - \mathbf{a}(\theta)\mathbf{s}\|^2$$
- **Constraints:**
    - None

### Optimization Algorithm
- **Algorithm Type:** Levenberg-Marquardt algorithm
- **Algorithm Parameters:**
    - Initial guess for $\theta$
    - Step size parameter
    - Convergence threshold
- **Algorithm Steps:**
    1. Initialize $\theta$ with an initial guess.
    2. Calculate the gradient and Hessian of the objective function $f(\theta)$.
    3. Update $\theta$ using the Levenberg-Marquardt formula:
    $$\theta_{new} = \theta_{old} - (\mathbf{H} + \mu\mathbf{I})^{-1}\mathbf{g}$$
        - $\mathbf{H}$: Hessian of $f(\theta)$
        - $\mathbf{g}$: Gradient of $f(\theta)$
        - $\mu$: Step size parameter
        - $\mathbf{I}$: Identity matrix
    4. Repeat steps 2-3 until convergence (i.e., until the change in $\theta$ is below the convergence threshold).