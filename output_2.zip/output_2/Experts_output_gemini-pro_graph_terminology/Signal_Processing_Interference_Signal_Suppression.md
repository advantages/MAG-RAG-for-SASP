2024-05-07 10:40:01.461962

### System Model
- **Problem Type:** Uniform linear array signal processing for source localization and interference suppression.
- **Problem Description:** Consider a uniform linear array (ULA) consisting of \(\text{N}\) array elements with a half-wavelength array spacing, denoted by \(\lambda/2\). 
There are \(\text{P}\) interference sources continuously emitting signals from angles \(\lbrace\theta_p, p=1,2,\ldots, P\rbrace\), and one signal source of interest located at some unknown direction \(\theta\).
The ULA receives signals from the target and interference sources and aims to estimate the direction of arrival (DOA) of the target source while suppressing the interference.
- **System Model Parameters:**
    - \(N\): Number of ULA array elements
    - \(\lambda\): Signal wavelength
    - \(\theta\): DOA of the target signal
    - \(\lbrace\theta_p, p=1,2,\ldots, P\rbrace\): DOAs of the interference sources
    - \(d_n\): Position of the \(n^{th}\) array element, given by \(d_n=(n-\frac{N+1}{2})\frac{\lambda}{2}\)
- **System Model Formulations:**
    - The received signal at the \(n^{th}\) array element can be expressed as:
    $$
    r_n(t)=s(t-\tau_n)+\sum_{p=1}^P i_p(t-\tau_{p,n})+w_n(t),
    $$
    where \(s(t)\) is the target signal, \(i_p(t)\) is the interference signal from the \(p^{th}\) source, \(w_n(t)\) is the additive white Gaussian noise (AWGN), and \(\tau_n\) and \(\tau_{p,n}\) are the propagation delays from the target source and the \(p^{th}\) interference source to the \(n^{th}\) array element, respectively.
    - The propagation delays can be calculated as:
    $$
    \tau_n=\frac{d_n\sin(\theta)}{c},
    $$
    $$
    \tau_{p,n}=\frac{d_n\sin(\theta_p)}{c},
    $$
    where \(c\) is the speed of light.
    - The received signal vector is:
    $$
    \mathbf{r}(t)=[r_1(t), r_2(t), \ldots, r_N(t)]^T,
    $$
    and can be expressed in matrix form as:
    $$
    \mathbf{r}(t)=\mathbf{A}(\theta)\mathbf{s}(t)+\mathbf{I}(t)+\mathbf{w}(t),
    $$
    where \(\mathbf{A}(\theta)=[a_1(\theta), a_2(\theta), \ldots, a_N(\theta)]^T\) is the steering vector of the target signal, \(\mathbf{s}(t)\) is the target signal vector, \(\mathbf{I}(t)=[i_1(t), i_2(t), \ldots, i_P(t)]^T\) is the interference signal vector, and \(\mathbf{w}(t)=[w_1(t), w_2(t), \ldots, w_N(t)]^T\) is the noise vector.
    - The steering vector \(\mathbf{A}(\theta)\) is given by:
    $$
    \mathbf{A}(\theta)=[1, e^{-j2\pi\frac{d_1\sin(\theta)}{\lambda}}, \ldots, e^{-j2\pi\frac{d_N\sin(\theta)}{\lambda}}]^T,
    $$

### Optimization Formulation
- **Optimization Type:** Beamforming for signal estimation and interference suppression.
- **Optimization Parameters:**
    - \(\mathbf{w}\): The weight vector of the beamformer, where \(\mathbf{w}\in\mathbb{C}^N\)
- **Optimization Variables:**
    - The beamformer weights \(\mathbf{w}\)
- **Objective:**
    - Maximize the signal-to-interference-plus-noise ratio (SINR) at the beamformer output:
    $$
    \max_{\mathbf{w}}\text{SINR}=\frac{\mathbf{w}^H \mathbf{R}_s\mathbf{w}}{\mathbf{w}^H (\mathbf{R}_I+\mathbf{R}_w)\mathbf{w}},
    $$
    where \(\mathbf{R}_s\) is the covariance matrix of the target signal, \(\mathbf{R}_I\) is the covariance matrix of the interference signals, and \(\mathbf{R}_w\) is the covariance matrix of the noise.
- **Constraints:**
    - The beamformer weights have unit norm: \(\mathbf{w}^H\mathbf{w}=1\)

### Optimization Algorithm
- **Algorithm Type:** Adaptive beamforming using the sample matrix inversion (SMI) algorithm.
- **Algorithm Parameters:**
    - \(\mu\): The step size of the SMI algorithm
- **Algorithm Steps:**
    1. Initialize the weight vector \(\mathbf{w}\).
    2. Calculate the covariance matrix of the received signal:
    $$
    \mathbf{R}=\frac{1}{L}\sum_{l=1}^L\mathbf{r}(l)\mathbf{r}^H(l),
    $$
    where L is the number of samples.
    3. Compute the beamforming weights using the SMI algorithm:
    $$
    \mathbf{w}=( \mathbf{R}_I+\mu \mathbf{I})^{-1}\mathbf{R}_s\mathbf{w}.
    $$
    4. Normalize the beamforming weights: \(\mathbf{w}=\mathbf{w}/\|\mathbf{w}\|\).
    5. Repeat steps 2-4 until convergence.