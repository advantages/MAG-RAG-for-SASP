2024-05-07 10:40:01.461962

### System Model
- **Problem Type:** Source localization using bearing angle measurements from multiple sensors.
- **Problem Description:** Given an array of \(M\) sensors located at positions \((\text{x}_i,  \text{y}_i)\), $i = 1, 2, . . . , M$, each sensor measures the bearing angle of a signal source, possibly with some additive Gaussian noise. The measured angle of sensor \(i\) is \(\theta_i\). The goal is to estimate the location of the signal source.
- **System Model Parameters:**
  - \(M\): Number of sensors
  - \((\text{x}_i, \text{y}_i)\): Location of the $i$-th sensor
  - \(\theta_i\): Measured bearing angle at the $i$-th sensor
  - $$\sigma^2$$: Variance of the additive Gaussian noise
- **System Model Formulations:**
  - The relationship between the sensor locations, source location, and measured bearing angles can be expressed as:
    $$ \tan \theta_i = \frac{\text{y}_s - \text{y}_i}{\text{x}_s - \text{x}_i} + \varepsilon_i$$
    where \((\text{x}_s, \text{y}_s)\) is the location of the signal source and \( \varepsilon_i \sim \mathcal{N}(0, \sigma^2)\) is the additive Gaussian noise.

### Optimization Formulation
- **Optimization Type:** Non-linear least squares (NLS)
- **Optimization Parameters:**
  - \((x_s, y_s)\): Coordinates of the signal source
  - \(\sigma^2\): Variance of the additive Gaussian noise
- **Optimization Variables:**
  - \((x_s, y_s)\)
- **Objective:**
  - Minimize the sum of squared residuals:
    $$ J(x_s, y_s) = \sum_{i=1}^M \left( \tan \theta_i - \frac{y_s - y_i}{x_s - x_i} \right)^2$$
- **Constraints:**
  - None

### Optimization Algorithm
- **Algorithm Type:** Gauss-Newton method
- **Algorithm Parameters:**
  - Initial guess: \((x_s^0, y_s^0)\)
  - Step size: \(\alpha\)
  - Convergence threshold: \(\epsilon\)
- **Algorithm Steps:**
  1. Initialize the algorithm with $$(x_s^0, y_s^0)$$.
  2. Iteratively update the estimates using the Gauss-Newton update rule:
    $$ (x_s^{k+1}, y_s^{k+1}) = (x_s^k, y_s^k) - \alpha \nabla J(x_s^k, y_s^k)$$
    where \(\nabla J(x_s, y_s)\) is the gradient of the objective function.
  3. Repeat step 2 until convergence is reached, i.e., \(\Vert (x_s^{k+1}, y_s^{k+1}) - (x_s^k, y_s^k) \Vert < \epsilon\).