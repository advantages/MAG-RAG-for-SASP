2024-05-03 23:31:43.763457

#### Terminological Description: 
Distributed antenna array, primary signals, signal sensing, QPSK modulation, bandwidth limitation.

#### Relevant Examples:
1. Example: "An Overview of Signal Processing Techniques for Joint Communication and Radar Sensing"
2. Example: "Wideband MIMO Radar Waveform Design"
3. Example: "Modified Subspace Algorithms for DoA Estimation With Large Arrays"