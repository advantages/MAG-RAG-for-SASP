2024-05-03 23:31:43.763457

# System Model

- **Problem Type:** Direction of Arrival (DOA) estimation problem in a uniform linear array (ULA) of sensors.
- **Problem Description:** The problem involves estimating the directions of arrival of coherent signals impinging on a ULA of sensors. The goal is to maximize the signal-to-interference plus noise ratio (SINR) at the beamform output by adjusting the array weight vector.
- **System Model Parameters:**
  - $N$: Number of elements in the ULA.
  - $\lambda$: Wavelength of the signal.
  - $\Theta$: Angle of the signal source.
  - $P$: Number of interference sources.
  - $\Phi_p$ (for $p=1,2,\ldots,P$): Angle of the $p$-th interference source.
- **System Model Formulations:**

The received signal at the ULA can be modeled as follows:

$$
\mathbf{y} = \mathbf{A} \mathbf{x} + \mathbf{n}
$$

where:
- $\mathbf{y}$ is the received signal vector of size $N \times 1$,
- $\mathbf{A}$ is the array response matrix of size $N \times N$,
- $\mathbf{x}$ is the source signal vector of size $N \times 1$,
- $\mathbf{n}$ is the additive noise vector of size $N \times 1$.

The array response matrix $\mathbf{A}$ can be expressed as:

$$
\mathbf{A} = \begin{bmatrix} 1 & e^{-j\frac{2\pi}{\lambda}d\sin(\Theta)} & e^{-j\frac{4\pi}{\lambda}d\sin(\Theta)} & \ldots & e^{-j\frac{2\pi(N-1)}{\lambda}d\sin(\Theta)} \end{bmatrix}
$$

where:
- $d$ is the spacing between the array elements.

The source signal vector $\mathbf{x}$ can be expressed as:

$$
\mathbf{x} = \begin{bmatrix} s \\ 0 \\ 0 \\ \ldots \\ 0 \end{bmatrix}
$$

where:
- $s$ is the amplitude of the source signal.

The noise vector $\mathbf{n}$ can be modeled as an additive white Gaussian noise with zero mean and variance $\sigma^2$.

Let's denote the interference signals as $\mathbf{x}_p$ for $p=1,2,\ldots,P$. The interference signals can be expressed as:

$$
\mathbf{x}_p = \begin{bmatrix} a_{1p} \\ 0 \\ 0 \\ \ldots \\ 0 \end{bmatrix}
$$

where:
- $a_{1p}$ is the amplitude of the $p$-th interference signal.

The received signal vector can then be written as:

$$
\mathbf{y} = \mathbf{A} \mathbf{x} + \sum_{p=1}^P \mathbf{A} \mathbf{x}_p + \mathbf{n}
$$

Now, our goal is to maximize the SINR at the beamform output. The SINR can be defined as:

$$
\text{SINR} = \frac{\|\mathbf{w}^H \mathbf{A} \mathbf{x}\|^2}{\sum_{p=1}^P \|\mathbf{w}^H \mathbf{A} \mathbf{x}_p\|^2 + \sigma^2 \|\mathbf{w}\|^2}
$$

where:
- $\mathbf{w}$ is the array weight vector of size $N \times 1$.

To maximize the SINR, we need to find the optimal array weight vector that maximizes the numerator and minimizes the denominator.