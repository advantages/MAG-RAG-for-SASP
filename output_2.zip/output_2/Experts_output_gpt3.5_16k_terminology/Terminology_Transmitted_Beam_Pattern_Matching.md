2024-05-03 23:31:43.763457

#### Terminological Description: 
The problem involves the design of transmitted beamforming weights that match the amplitude of an expected radiation beam pattern. The goal is to obtain the optimal weights for a uniform linear array with N array elements and a half-wavelength spacing, such that the transmitted beam pattern aligns with the desired amplitude values given in the expected radiation beam pattern.

#### Relevant Examples:
1. Colocated MIMO Radar Waveform Design for Transmit Beampattern Formation
2. Spectrally Constrained MIMO Radar Waveform Design Based on Mutual Information
3. Wideband MIMO Radar Waveform Design