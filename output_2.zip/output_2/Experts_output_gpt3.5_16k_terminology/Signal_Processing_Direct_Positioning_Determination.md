2024-05-03 23:31:43.763457

### System Model
- **Problem Type:** Direction-of-Arrival (DOA) estimation
- **Problem Description:** The fusion center needs to estimate the position of a signal source in space based on the signals received from multiple sensors. The sensors are equipped with one antenna each and are located at different positions in two-dimensional space. The signal source continuously emits signals.
- **System Model Parameters:** 
   - $M$: Number of sensors
   - $(x_i, y_i)$: Position of sensor $i$
   - $(x, y)$: Position of the signal source
   - $s(t)$: Signal emitted by the source
   - $r_i(t)$: Signal received at sensor $i$
   - $\mathbf{r}(t) = [r_1(t), r_2(t), \ldots, r_M(t)]^T$: Vector of received signals at all sensors
   - $\mathbf{\theta} = (\theta_1, \theta_2, \ldots, \theta_L)^T$: Vector of DOA angles to be estimated ($L$ is the number of sources)
   - $\mathbf{a}(\theta)$: Array response vector with respect to DOA angle $\theta$
   - $\mathbf{A}(\mathbf{\theta}) = [\mathbf{a}(\theta_1), \mathbf{a}(\theta_2), \ldots, \mathbf{a}(\theta_L)]$: Steering matrix
   - $\mathbf{S}(t) = [\mathbf{s}_1(t), \mathbf{s}_2(t), \ldots, \mathbf{s}_L(t)]$: Matrix of signal waveforms emitted by the sources
   - $\mathbf{N}(t) = [\mathbf{n}_1(t), \mathbf{n}_2(t), \ldots, \mathbf{n}_M(t)]$: Matrix of additive white Gaussian noise waveforms at the sensors
   - $\mathbf{X}(t) = \mathbf{A}(\mathbf{\theta})\mathbf{S}(t)$: Matrix of received signals at all sensors (without noise) 
   - $\mathbf{R} = E\{\mathbf{XX}^H\}$: Covariance matrix of the received signals (without noise)
- **System Model Formulations:**
   - $\mathbf{r}_i(t) = \mathbf{a}(\theta_i)s(t) + \mathbf{n}_i(t)$, where $i = 1, 2, \ldots, M$
   - $\mathbf{r}(t) = \mathbf{A}(\mathbf{\theta})\mathbf{s}(t) + \mathbf{n}(t)$, where $\mathbf{n}(t)$ is the vectorized form of $\mathbf{N}(t)$
   - $\mathbf{X}(t) = \mathbf{A}(\mathbf{\theta})\mathbf{S}(t) + \mathbf{N}(t)$
   - $\mathbf{R} = E\{\mathbf{XX}^H\}$

### Optimization Formulation
- **Optimization Type:** Estimation problem
- **Optimization Parameters:** 
   - $\mathbf{R}$: Covariance matrix of the received signals
   - $\mathbf{A}(\mathbf{\theta})$: Steering matrix
- **Optimization Variables:** 
   - $\mathbf{\theta}$: Vector of DOA angles to be estimated
- **Objective:** 
   - Minimize the estimation error between the actual DOA angles and the estimated DOA angles.
- **Constraints:**
   - None

### Optimization Algorithm
- **Algorithm Type:** ESPRIT algorithm (Estimation of Signal Parameters via Rotational Invariance Techniques)
- **Algorithm Parameters:** None
- **Algorithm Steps:**
   1. Construct the spatial covariance matrix: $\mathbf{R} = E\{\mathbf{XX}^H\}$
   2. Perform eigenvalue decomposition of $\mathbf{R}$: $\mathbf{R} = \mathbf{U\Lambda U}^H$
   3. Use the eigen-decomposition to estimate the signal subspace and noise subspace:
      - Signal subspace: $\mathbf{U}_s = \mathbf{U(:,1:L)}$, where $L$ is the number of sources
      - Noise subspace: $\mathbf{U}_n = \mathbf{U(:,L+1:M)}$
   4. Compute the matrix $\mathbf{T} = \mathbf{U}_n^H\mathbf{U}_s$
   5. Perform eigenvalue decomposition of $\mathbf{T}$: $\mathbf{T} = \mathbf{V\Lambda}_T\mathbf{V}^H$
   6. Extract the DOA angles from the eigenvalues of $\mathbf{T}$: $\mathbf{\theta} = \arcsin\left(\frac{{\mathrm{Im}\{\Lambda_T\}}}{{\sqrt{M - L}}}\right)$

This algorithm is suitable for DOA estimation problems in the presence of coherent signals. It utilizes the structure of the covariance matrix and eigenvalue decomposition to estimate the DOA angles accurately.