2024-05-03 23:31:43.763457

# System Model

- **Problem Type:** Localization of a signal source using time of arrival (TOA) measurements from a sensor array.

- **Problem Description:** The problem involves estimating the directions of arrival (DOAs) of signals using the TOA measurements taken by a group of sensors. The goal is to determine the location of the signal source based on the TOA measurements obtained from multiple sensors at different positions.

- **System Model Parameters:**
  - $M$: Number of sensors in the array ($M \geq 2$).
  - $(x_i, y_i)$: Position coordinates of sensor $i$, where $i = 1, 2, ..., M$.
  - $t_i$: Time of arrival measured by sensor $i$, where $i = 1, 2, ..., M$.

- **System Model Formulations:** Let $x$ and $y$ represent the coordinates of the source signal. The distance between the source signal and sensor $i$ can be calculated using the Euclidean distance formula:

  $$d_i = \sqrt{(x - x_i)^2 + (y - y_i)^2}$$

  The time it takes for the signal to travel from the source to sensor $i$ can be calculated as:

  $$t_i = \frac{d_i}{c}$$

  where $c$ is the speed of light.

  By rearranging the equation, we can express the positions of the source signal in terms of the TOA measurements as:

  $$(x - x_i)^2 + (y - y_i)^2 = c^2t_i^2$$

  This equation represents a circle centered at $(x_i, y_i)$ with a radius of $c|t_i|$. The intersection points of these circles can be used to estimate the location of the source signal $(x, y)$.

# Optimization Formulation

- **Optimization Type:** Non-linear optimization problem. The objective is to find the values of $x$ and $y$ that minimize the error between the observed TOA measurements and the calculated TOA values based on the estimated source location.

- **Optimization Parameters:**
  - $M$: Number of sensors in the array.
  - $(x_i, y_i)$: Position coordinates of sensor $i$, where $i = 1, 2, ..., M$.
  - $t_i$: Observed TOA measurement by sensor $i$, where $i = 1, 2, ..., M$.

- **Optimization Variables:**
  - $x$: x-coordinate of the estimated source location.
  - $y$: y-coordinate of the estimated source location.

- **Objective:** Minimize the error between the observed TOA measurements and the calculated TOA values based on the estimated source location. The objective function can be defined as the sum of squared errors:

  $$\text{minimize} \quad J(x, y) = \sum_{i=1}^{M} \left((x - x_i)^2 + (y - y_i)^2 - c^2t_i^2\right)^2$$

- **Constraints:** None.

# Optimization Algorithm

- **Algorithm Type:** Non-linear least squares optimization algorithm. The problem can be tackled using a numerical optimization algorithm such as Levenberg-Marquardt algorithm.

- **Algorithm Parameters:** The algorithm may require setting an initial guess for the source location, as well as parameters related to the convergence criteria such as maximum number of iterations or tolerance level.

- **Algorithm Steps:**
  
  1. Initialize the source location estimate $x$ and $y$ with an initial guess.
  2. Calculate the TOA values using the current estimated source location.
  3. Compute the error between the observed TOA measurements and the calculated TOA values.
  4. Update the estimated source location using the optimization algorithm.
  5. Repeat steps 2-4 until convergence criteria are met (e.g., the error is below a certain tolerance level or the maximum number of iterations is reached).

The above algorithm iteratively refines the estimated source location by minimizing the error between the observed and calculated TOA values. By following this algorithm, the signal source localization problem based on TOA measurements can be effectively solved.