2024-05-04 00:23:51.437077

#### Terminological Description: 

- Time of arrival (TOA)
- Localization
- Source localization
- Multiple sensors
- Signal processing

#### Relevant Examples:
1. [**Paper_2: An Improved ESPRIT-Like Algorithm for Coherent Signals DOA Estimation**](#Paper_2: An Improved ESPRIT-Like Algorithm for Coherent Signals DOA Estimation)
2. [**Paper_7: DOA Estimation Using Compressed Sparse Array**](#Paper_7: DOA Estimation Using Compressed Sparse Array)
3. [**Paper_16: MUSIC-Like DOA Estimation Without Estimating the Number of Sources**](#Paper_16: MUSIC-Like DOA Estimation Without Estimating the Number of Sources)