2024-05-04 00:23:51.437077

#### Terminological Description: 

- Uniform linear array (ULA)
- Beamforming
- Radiation beam pattern

#### Relevant Examples:
1.  **An ESPRIT-Like Algorithm for Coherent DOA Estimation**

2. **An Improved ESPRIT-Like Algorithm for Coherent Signals DOA Estimation**

3. **MUSIC-Like DOA Estimation Without Estimating the Number of Sources**