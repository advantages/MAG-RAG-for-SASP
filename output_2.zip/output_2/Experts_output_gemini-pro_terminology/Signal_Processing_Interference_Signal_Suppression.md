2024-05-04 00:23:51.437077

### System Model
- **Problem Type:** Direction of arrival (DOA) estimation and beamforming
- **Problem Description:** Uniform linear array (ULA) with N array elements and half-wavelength spacing. A signal source emits a signal at an angle of θ. There are P interference sources emitting signals from angles φp (p = 1, 2, 3, ... P). The objective is to maximize the signal-to-interference plus noise ratio (SINR) at the beamform output.
- **System Model Parameters:**
   - \(N\): number of array elements
   - \(\lambda\): wavelength of the signal
   - \(d\): array spacing (d = \(\lambda/2\))
   - \(\theta\): DOA of the signal source
   - \(\Phi_{p}\): DOAs of the interference sources
   - \(s(t)\): signal waveform
   - \(i_{p}(t)\): interference waveforms
   - \(n(t)\): noise waveform
- **System Model Formulations:**
   - Array steering vector:
   $$a(\theta) = [1, e^{-j2\pi d/\lambda \sin\theta}, e^{-j4\pi d/\lambda \sin\theta}, ..., e^{-j2\pi(N-1)d/\lambda \sin\theta}]^T$$
   - Received signal:
   $$x(t) = s(t)a(\theta) + \sum_{p=1}^{P} i_{p}(t)a(\phi_{p}) + n(t)$$
   - Beamformed output:
   $$y(t) = w^H x(t)$$
   - SINR:
   $$SINR = \frac{\lvert w^H a(\theta) \rvert^2}{w^H R_I w + w^H R_n w}$$
   where \(R_I\) is the interference covariance matrix and \(R_n\) is the noise covariance matrix.

### Optimization Formulation
- **Optimization Type:** Constrained optimization
- **Optimization Parameters:**
   - \(w\): beamformer weight vector
- **Optimization Variables:**
   - \(w\): beamformer weight vector
- **Objective:**
   - Maximize SINR
- **Constraints:**
   - \(w^H w = 1\) (unit norm constraint)

### Optimization Algorithm
- **Algorithm Type:** Lagrangian multiplier method
- **Algorithm Parameters:**
   - \(\lambda\): Lagrangian multiplier
- **Algorithm Steps:**
   1. Form the Lagrangian:
   $$L(w, \lambda) = -\frac{\lvert w^H a(\theta) \rvert^2}{w^H R_I w + w^H R_n w} + \lambda(w^H w - 1)$$
   2. Solve for the optimal weight vector:
   $$\frac{\partial L}{\partial w} = 0 \Rightarrow w = \frac{R_I^{-1} a(\theta)}{\lvert R_I^{-1} a(\theta) \rvert^2 + \lambda}$$
   3. Solve for \(\lambda\) by applying the unit norm constraint:
   $$w^H w = 1 \Rightarrow \lambda = \frac{1 - \lvert R_I^{-1} a(\theta) \rvert^2}{\lvert R_I^{-1} a(\theta) \rvert^2}$$
   4. The optimal beamformer weight vector is given by:
   $$w = \frac{R_I^{-1} a(\theta)}{\lvert R_I^{-1} a(\theta) \rvert^2 + \frac{1 - \lvert R_I^{-1} a(\theta) \rvert^2}{\lvert R_I^{-1} a(\theta) \rvert^2}} = \frac{R_I^{-1} a(\theta)}{\sqrt{\lvert R_I^{-1} a(\theta) \rvert^2}}$$