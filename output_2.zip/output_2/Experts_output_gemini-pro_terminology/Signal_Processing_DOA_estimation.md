2024-05-04 00:23:51.437077

## System Model
### Problem Type:
Direction-of-Arrival (DOA) Estimation

### Problem Description:
Estimate the angle of arrival (\( \theta \)) of a signal impinging on a uniform linear array (ULA) of \( N \) sensors, given \( K \) samples of the received signal.

### System Model Parameters:
- \( N \): Number of array elements
- \( d \): Array spacing (half a wavelength)
- \( \theta \): Angle of arrival of the signal
- \( f \): Signal frequency
- \( v \): Speed of propagation
- \( K \): Number of sampled signals

### System Model Formulations:
- The received signal at the \( n \)-th array element is:
$$ x_n(t) = s(t - \frac{n d \sin(\theta)}{v}) + w_n(t) $$
- where \( s(t) \) is the transmitted signal, and \( w_n(t) \) is the additive white Gaussian noise.
- The array steering vector is:
$$ a(\theta) = [1, e^{-j2\pi f d \sin(\theta)/v}, \dots, e^{-j2\pi f d (N-1) \sin(\theta)/v}]^T $$
- The covariance matrix of the received signal is:
$$ R = \sigma_s^2 a(\theta) a(\theta)^H + \sigma_w^2 I $$
- where \( \sigma_s^2 \) is the signal power, \( \sigma_w^2 \) is the noise power, and \( I \) is the identity matrix.

## Optimization Formulation
### Optimization Type:
Maximum Likelihood Estimation

### Optimization Parameters:
- \( \hat{\theta} \): Estimated angle of arrival
- \( R \): Covariance matrix of the received signal

### Optimization Variables:
- \( \theta \)

### Objective:
$$\hat{\theta} = \arg \max_{\theta} L(\theta)$$
where \( L(\theta) \) is the log-likelihood function:
$$ L(\theta) = \log \frac{1}{\det(R)} - a(\theta)^H R^{-1} a(\theta)$$

### Constraints:
- $0 \leq \theta \leq 2\pi$

## Optimization Algorithm
### Algorithm Type:
Gradient Descent

### Algorithm Parameters:
- Gradient step size: \( \alpha \)
- Convergence threshold: \( \epsilon \)

### Algorithm Steps:
1. Initialize \( \theta_0 \)
2. Repeat until convergence:
    - \( \theta_{t+1} = \theta_t - \alpha \nabla L(\theta_t) \)
    - where \( \nabla L(\theta) \) is the gradient of the log-likelihood function
3. Set \( \hat{\theta} = \theta_t \)

## Implementation
```python
import numpy as np
import scipy.linalg as la

# Generate data
N = 10  # number of array elements
d = 0.5  # array spacing (half a wavelength)
f = 100  # signal frequency
v = 3e8  # speed of propagation
theta_true = np.pi/4  # true angle of arrival
K = 1000  # number of sampled signals
sigma_s = 1  # signal power
sigma_w = 0.1  # noise power

# Generate received signal
s = np.exp(1j * 2 * np.pi * f * t)
w = np.random.randn(N, K) + 1j * np.random.randn(N, K)
X = s * np.exp(-1j * 2 * np.pi * f * d * np.arange(N)[:, None] * np.sin(theta_true) / v) + w

# Estimate DOA using gradient descent
theta_init = np.pi/2
alpha = 0.01
epsilon = 1e-6
theta_est = theta_init
while True:
    R = np.cov(X)
    a = np.exp(-1j * 2 * np.pi * f * d * np.arange(N)[:, None] * np.sin(theta_est) / v)
    gradient = -a.T @ np.linalg.solve(R, a)
    theta_est -= alpha * gradient
    if np.abs(theta_est - theta_init) < epsilon:
        break
    theta_init = theta_est

# Print results
print("True DOA:", theta_true)
print("Estimated DOA:", theta_est)
```