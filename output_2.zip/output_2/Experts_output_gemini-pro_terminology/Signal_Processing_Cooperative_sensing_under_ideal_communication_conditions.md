2024-05-04 00:23:51.437077

### System Model
- **Problem Type:** Sensor array signal detection
- **Problem Description:** Distributed antenna arrays are tasked with detecting the presence of primary signals continuously broadcasted by a signal emitter. The transmitted signal properties include limited bandwidth and segmental information encapsulation, e.g., QPSK modulation. It is crucial to devise an efficient strategy to maximize signal sensing utility using the distributed antenna array.
- **System Model Parameters:**
    - $p$: Number of distributed antennas
    - $s(t)$: Transmitted primary signal
    - $x_i(t)$: Received signal at antenna $i$
    - $h_i$: Channel coefficient from the emitter to antenna $i$
    - $n_i(t)$: Additive white Gaussian noise at antenna $i$
- **System Model Formulations:**
    - Signal received at antenna $i$:
    $$x_i(t) = h_i s(t) + n_i(t)$$

### Optimization Formulation
- **Optimization Type:** Signal detection
- **Optimization Parameters:**
    - $x_i(t)$: Received signals at all antennas
    - $H$: Channel matrix containing $h_i$
    - $\theta$: Signal direction of arrival (DOA)
- **Optimization Variables:**
    - $\hat{\theta}$: Estimated DOA
- **Objective:** Maximize signal-to-noise ratio (SNR):
    $$SNR = \frac{\Vert H \hat{s}(\hat{\theta})\Vert^2}{\Vert x(t) - H \hat{s}(\hat{\theta})\Vert^2}$$
- **Constraints:**
    - The estimated DOA is within the range of possible DOAs.

### Optimization Algorithm
- **Algorithm Type:** Multiple Signal Classification (MUSIC)
- **Algorithm Parameters:**
    - Number of sources: $K$
    - Eigenvalue threshold: $\lambda_{th}$
- **Algorithm Steps:**
    1. Compute the covariance matrix of the received signals:
    $$R_x = \frac{1}{N} \sum_{t=1}^N x(t)x(t)^H$$
    2. Perform eigenvalue decomposition on $R_x$:
    $$R_x = V \Lambda V^H$$
    3. Construct the noise subspace by selecting the eigenvectors corresponding to the $p-K$ smallest eigenvalues:
    $$E_n = \text{span}\lbrace v_{p-K+1}, \dots, v_p \rbrace$$
    4. Estimate the DOA as the angle that minimizes the MUSIC spectrum:
    $$\hat{\theta} = \arg \max_{\theta} \frac{1}{\Vert E_n^H a(\theta)\Vert^2}$$
    where $a(\theta)$ is the steering vector.