2024-05-04 00:23:51.437077

### System Model
- **Problem Type:** Source Localization
- **Problem Description:** Given M sensors at different positions (x_i, y_i), i=1,2,...,M, each of which can measure the time of arrival (TOA) of a signal source, the goal is to determine the location of the signal source using these TOA measurements.
- **System Model Parameters:**
 - Number of sensors, M
 - Sensor positions, (x_i, y_i), i=1,2,...,M
 - Measured TOAs, t_i, i=1,2,...,M
 - Signal source location, (x_s, y_s)
- **System Model Formulations:**
  
Accoding to the definition of TOA, the time difference between the transmitting time and the receiving time is 

$$t_i=\sqrt{(x_s-x_i)^2+(y_s-y_i)^2}/c$$

where c is the propagation speed of the signal. $$(1)$$

### Optimization Formulation
- **Optimization Type:** Nonlinear least squares optimization
- **Optimization Parameters:**
  - Sensor positions, (x_i, y_i), i=1,2,...,M
  - Measured TOAs, t_i, i=1,2,...,M
- **Optimization Variables:**
  - Signal source location, (x_s, y_s)
- **Objective:**
  - Minimize the sum of squared errors between the measured TOAs and the TOAs predicted by the model, i.e.
  
  $$min_{x_s,y_s}\sum_{i=1}^M(t_i-\sqrt{(x_s-x_i)^2+(y_s-y_i)^2}/c)^2$$   
  
- **Constraints:**
  - None

### Optimization Algorithm
- **Algorithm Type:** Levenberg-Marquardt algorithm
- **Algorithm Parameters:**
  - Initial guess for the signal source location
  - Step size
  - Convergence threshold
- **Algorithm Steps:**
  1. Initialize the signal source location with an initial guess
  2. Calculate the Jacobian matrix of the objective function
  3. Solve the linear least squares problem to find the update to the signal source location
  4. Update the signal source location
  5. Repeat steps 2-4 until convergence