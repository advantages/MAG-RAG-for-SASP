2024-05-04 00:23:51.437077

### System Model

- **Problem Type:** Signal source localization using Time Difference of Arrival (TDOA) and Frequency Difference of Arrival (FDOA) measurements.
- **Problem Description:** Given the TDOA and FDOA measurements from a set of sensors, estimate the position and velocity of the signal source.
- **System Model Parameters:**
    - $M$: Number of sensors
    - $x_i, y_i$: Position coordinates of the $i$-th sensor
    - $t_i$: Time of arrival of the signal at the $i$-th sensor
    - $f_i$: Frequency of arrival of the signal at the $i$-th sensor
    - $x_s, y_s$: Position coordinates of the signal source
    - $v_x, v_y$: Velocity components of the signal source
- **System Model Formulations:**
    - **TDOA equations:** $$t_i - t_j = \frac{1}{c} \sqrt{(x_i - x_s)^2 + (y_i - y_s)^2}$$
    - **FDOA equations:** $$f_i - f_j = \frac{1}{c} \frac{v_x(x_i - x_j) + v_y(y_i - y_j)}{\sqrt{(x_i - x_s)^2 + (y_i - y_s)^2}}$$

### Optimization Formulation

- **Optimization Type:** Non-linear least squares optimization
- **Optimization Parameters:**
    - $x_s, y_s$: Position coordinates of the signal source
    - $v_x, v_y$: Velocity components of the signal source
- **Optimization Variables:**
    - $x_s, y_s, v_x, v_y$
- **Objective:** Minimize the sum of squared errors between the measured and estimated TDOA and FDOA values:
    $$J(x_s, y_s, v_x, v_y) = \sum_{i=1}^{M-1} \sum_{j=i+1}^{M} (t_i - t_j - \hat{t}_{i,j})^2 + (f_i - f_j - \hat{f}_{i,j})^2$$
    where $\hat{t}_{i,j}$ and $\hat{f}_{i,j}$ are the estimated TDOA and FDOA values for the $i$-th and $j$-th sensors.
- **Constraints:** None

### Optimization Algorithm

- **Algorithm Type:** Gauss-Newton algorithm
- **Algorithm Parameters:**
    - Learning rate: $\alpha$
    - Convergence threshold: $\epsilon$
    - Maximum number of iterations: $N$
- **Algorithm Steps:**
    1. Initialize the source position and velocity estimates: $x_s^{(0)}, y_s^{(0)}, v_x^{(0)}, v_y^{(0)}$.
    2. For $k = 1, 2, \ldots, N$ do:
        - Compute the estimated TDOA and FDOA values: $$\hat{t}_{i, j}^{(k)} = \frac{1}{c} \sqrt{(x_i - x_s^{(k-1)})^2 + (y_i - y_s^{(k-1)})^2}$$
        $$\hat{f}_{i, j}^{(k)} = \frac{1}{c} \frac{v_x^{(k-1)}(x_i - x_j) + v_y^{(k-1)}(y_i - y_j)}{\sqrt{(x_i - x_s^{(k-1)})^2 + (y_i - y_s^{(k-1)})^2}}$$
        - Compute the Jacobian matrix: $$J = \begin{bmatrix} \frac{\partial \hat{t}}{\partial x_s} & \frac{\partial \hat{t}}{\partial y_s} & \frac{\partial \hat{t}}{\partial v_x} & \frac{\partial \hat{t}}{\partial v_y} \\\ \frac{\partial \hat{f}}{\partial x_s} & \frac{\partial \hat{f}}{\partial y_s} & \frac{\partial \hat{f}}{\partial v_x} & \frac{\partial \hat{f}}{\partial v_y} \end{bmatrix}$$
        - Update the source position and velocity estimates:
        $$\begin{bmatrix} x_s^{(k)} \\\ y_s^{(k)} \\\ v_x^{(k)} \\\ v_y^{(k)} \end{bmatrix} = \begin{bmatrix} x_s^{(k-1)} \\\ y_s^{(k-1)} \\\ v_x^{(k-1)} \\\ v_y^{(k-1)} \end{bmatrix} - \alpha J^T \begin{bmatrix} t_i - t_j - \hat{t}_{i, j}^{(k)} \\\ f_i - f_j - \hat{f}_{i, j}^{(k)} \end{bmatrix}$$
        3. Until convergence criterion is met: $$\frac{\|x_s^{(k)} - x_s^{(k-1)}\|}{\|x_s^{(k-1)}\|} < \epsilon \quad \text{and} \quad \frac{\|y_s^{(k)} - y_s^{(k-1)}\|}{\|y_s^{(k-1)}\|} < \epsilon \quad \text{and} \quad \frac{\|v_x^{(k)} - v_x^{(k-1)}\|}{\|v_x^{(k-1)}\|} < \epsilon \quad \text{and} \quad \frac{\|v_y^{(k)} - v_y^{(k-1)}\|}{\|v_y^{(k-1)}\|} < \epsilon $$