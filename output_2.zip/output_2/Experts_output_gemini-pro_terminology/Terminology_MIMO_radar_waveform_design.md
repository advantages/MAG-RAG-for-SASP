2024-05-04 00:23:51.437077

#### Terminological Description:
- Colocated narrow band MIMO radar system
- Transmit antennas
- Receive antennas
- Omnidirectional transmission
- Cross-correlation
- Constant modulus constraint
- Similarity constraint
- Transmit waveform
- SINR

#### Relevant Examples:
1. An Improved ESPRIT-Like Algorithm for Coherent Signals DOA Estimation
2. An Improved ESPRIT-Like Algorithm for Coherent Signals DOA Estimation
3. Minimax Robust MIMO Radar Waveform Design