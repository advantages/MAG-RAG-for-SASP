2024-05-04 00:23:51.437077

### System Model
- **Problem Type:** Angle of Arrival (AoA) Estimation
- **Problem Description:** Estimating the direction of a signal source based on bearing angle measurements from multiple sensors. Each sensor measures the bearing angle of the signal source with possible additive Gaussian noise. The objective is to determine the location of the signal source based on these noisy angle measurements.
- **System Model Parameters:**
    - $M$: Number of sensors
    - $(\var{x_i},\var{y_i})$: Coordinates of the $i$th sensor
    - $\theta_i$: Bearing angle measured by the $i$th sensor
    - $\sigma^2$: Variance of the additive Gaussian noise
- **System Model Formulations:**
    - The bearing angle measured by the $i$th sensor is given by:
    $$\theta_i = \arctan\left(\frac{y_s-y_i}{x_s-x_i}\right) + \epsilon_i$$
    - where $(x_s,y_s)$ is the location of the signal source and $\epsilon_i \sim \mathcal{N}(0,\sigma^2)$ is the additive Gaussian noise.

### Optimization Formulation
- **Optimization Type:** Maximum Likelihood Estimation (MLE)
- **Optimization Parameters:**
    - $\theta_1, \theta_2, ..., \theta_M$: Measured bearing angles
    - $(x_s,y_s)$: Unknown location of the signal source
- **Optimization Variables:**
    - $(x_s,y_s)$
- **Objective:**
    - Maximize the likelihood function:
    $$L(\theta_1, \theta_2, ..., \theta_M | x_s, y_s) = \prod_{i=1}^M \frac{1}{\sqrt{2\pi\sigma^2}} \exp\left(-\frac{(\theta_i - \arctan\left(\frac{y_s-y_i}{x_s-x_i}\right))^2}{2\sigma^2}\right)$$
- **Constraints:**
    - None

### Optimization Algorithm
- **Algorithm Type:** Gradient Descent
- **Algorithm Parameters:**
    - Learning rate: $\alpha$
    - Number of iterations: $N$
- **Algorithm Steps:**
    - Initialize $(x_s^0,y_s^0)$
    - For $n = 1$ to $N$
        - Compute the gradient:
        $$\nabla L(x_s^n, y_s^n) = \sum_{i=1}^M \frac{\partial L(\theta_1, \theta_2, ..., \theta_M | x_s, y_s)}{\partial x_s}\bigg|_{(x_s^n, y_s^n)} \hat{x} + \frac{\partial L(\theta_1, \theta_2, ..., \theta_M | x_s, y_s)}{\partial y_s}\bigg|_{(x_s^n, y_s^n)} \hat{y}$$
        - Update the estimate:
        $$(x_s^{n+1}, y_s^{n+1}) = (x_s^n, y_s^n) - \alpha \nabla L(x_s^n, y_s^n)$$
    - End For