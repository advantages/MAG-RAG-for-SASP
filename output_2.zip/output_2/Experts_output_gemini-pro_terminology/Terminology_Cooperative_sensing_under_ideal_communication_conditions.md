2024-05-04 00:23:51.437077

#### Terminological Description: 
In the problem context, the primary signals that are continuously broadcasted by the signal emitter are assumed to be QPSK modulated signals with limited bandwidth. The distributed antenna array is utilized for the detection of these primary signals with the aim of maximizing the utility of the antennas for signal sensing.

#### Relevant Examples:
1. **Paper Title:** An ESPRIT-Like Algorithm for Coherent DOA Estimation
2. **Paper Title:** An Improved ESPRIT-Like Algorithm for Coherent Signals DOA Estimation
3. **Paper Title:** MUSIC-Like DOA Estimation Without Estimating the Number of Sources