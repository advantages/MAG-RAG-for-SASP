2024-05-07 10:56:38.963827

In the optimization algorithm, the objective function should be maximized or minimized as specified in the problem description. The objective function should be expressed in a mathematical form that clearly defines the desired outcome.